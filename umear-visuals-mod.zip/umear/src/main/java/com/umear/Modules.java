package com.umear;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.*;
import java.util.*;

public final class Modules {
    public static final List<Module> ALL = new ArrayList<>();
    public static final String[] CATS = {"Combat", "Visuals", "Misc"};
    public static Module HITSOUND, CPS, COMBO, HITCOLOR, TRAILS, PARTICLES, HAT, TIME, BLUR, ANIM, THEME;

    public static long ticks;
    public static int combo;
    public static long lastHit;
    private static final ArrayDeque<Long> CLICKS = new ArrayDeque<>();

    private static Module add(Module m) { ALL.add(m); return m; }
    private static final String[] POS = {"Сверху слева", "Сверху справа", "Снизу слева", "Снизу справа", "Под прицелом"};

    public static void init() {
        HITSOUND = add(new Module("Combat", "Hit Sound", "Звук при попадании", true,
                Setting.mode("snd", "Звук", 0, "Click", "Pop", "Bell", "Ding"),
                Setting.slider("vol", "Громкость", 0, 100, 1, 60, "%"),
                Setting.slider("pitch", "Тон", 50, 200, 5, 100, "%")));
        CPS = add(new Module("Combat", "CPS Display", "Клики в секунду", true,
                Setting.mode("pos", "Позиция", 0, POS),
                Setting.slider("size", "Размер", 50, 200, 10, 100, "%"),
                Setting.color("col", "Цвет", 0xA78BFA),
                Setting.bool("bg", "Фон", true)));
        COMBO = add(new Module("Combat", "Combo Counter", "Серия ударов", true,
                Setting.mode("pos", "Позиция", 0, POS),
                Setting.slider("to", "Сброс через", 1, 10, 1, 3, " с"),
                Setting.color("col", "Цвет", 0xF472B6),
                Setting.bool("rst", "Сброс при уроне", true),
                Setting.slider("size", "Размер", 50, 200, 10, 100, "%"),
                Setting.bool("bg", "Фон", true)));
        HITCOLOR = add(new Module("Visuals", "Hit Color", "Цвет при попадании", true,
                Setting.color("col", "Цвет", 0xFF3B5C),
                Setting.slider("op", "Прозрачность", 0, 100, 5, 70, "%")));
        TRAILS = add(new Module("Visuals", "Trails", "Следы за игроком", true,
                Setting.mode("st", "Стиль", 1, "Линия", "Лента", "Стена"),
                Setting.color("col", "Цвет", 0x7C3AED),
                Setting.slider("len", "Длина", 5, 60, 1, 25, ""),
                Setting.bool("rb", "Радуга", false)));
        PARTICLES = add(new Module("Visuals", "Particles", "Частицы вокруг игрока", false,
                Setting.mode("type", "Тип", 0, "Огонь", "Сердца", "Звёзды", "Криты"),
                Setting.slider("n", "Количество", 1, 40, 1, 10, ""),
                Setting.slider("r", "Радиус", 0.3, 2, 0.1, 0.8, "")));
        HAT = add(new Module("Visuals", "China Hat", "Шляпа над игроком", true,
                Setting.color("col", "Цвет", 0xFBBF24),
                Setting.slider("size", "Размер", 50, 200, 5, 100, "%"),
                Setting.slider("h", "Высота", 0, 100, 5, 20, "%"),
                Setting.bool("rb", "Радуга", false)));
        TIME = add(new Module("Visuals", "Time Changer", "Время суток", false,
                Setting.slider("t", "Время", 0, 24000, 250, 6000, ""),
                Setting.bool("fr", "Заморозить", true)));
        BLUR = add(new Module("Misc", "GUI Blur", "Размытие фона меню", true,
                Setting.slider("dim", "Затемнение", 0, 100, 5, 40, "%")));
        ANIM = add(new Module("Misc", "GUI Animation", "Анимации меню", true,
                Setting.slider("spd", "Скорость", 1, 20, 1, 10, "")));
        THEME = add(new Module("Misc", "Custom Theme", "Цвет и форма меню", true,
                Setting.color("accent", "Акцент", 0x7C3AED),
                Setting.slider("round", "Скругление", 0, 10, 1, 6, " px"),
                Setting.bool("wm", "Ватермарк", true)));
        load();
    }

    public static List<Module> of(String cat) {
        List<Module> l = new ArrayList<>();
        for (Module m : ALL) if (m.cat.equals(cat)) l.add(m);
        return l;
    }

    public static int accent() { return 0xFF000000 | (THEME.enabled ? THEME.col("accent") : 0x7C3AED); }
    public static int radius() { return THEME.enabled ? (int) THEME.num("round") : 6; }

    public static long timeValue() {
        long t = (long) TIME.num("t");
        return TIME.bool("fr") ? t : t + ticks;
    }

    public static void click() { CLICKS.addLast(System.currentTimeMillis()); }
    public static int cps() {
        long now = System.currentTimeMillis();
        while (!CLICKS.isEmpty() && now - CLICKS.peekFirst() > 1000) CLICKS.pollFirst();
        return CLICKS.size();
    }

    private static Path path() { return FabricLoader.getInstance().getConfigDir().resolve("umear_visuals.json"); }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            for (Module m : ALL) {
                o.addProperty(m.name + ".on", m.enabled);
                for (Setting s : m.settings) {
                    String k = m.name + "." + s.key;
                    switch (s.type) {
                        case SLIDER -> o.addProperty(k, s.val);
                        case COLOR -> o.addProperty(k, s.color);
                        case MODE -> o.addProperty(k, s.mode);
                        case BOOL -> o.addProperty(k, s.bool);
                    }
                }
            }
            Files.writeString(path(), new GsonBuilder().setPrettyPrinting().create().toJson(o));
        } catch (Exception ignored) {}
    }

    private static void load() {
        try {
            if (!Files.exists(path())) return;
            JsonObject o = JsonParser.parseString(Files.readString(path())).getAsJsonObject();
            for (Module m : ALL) {
                if (o.has(m.name + ".on")) { m.enabled = o.get(m.name + ".on").getAsBoolean(); m.tog = m.enabled ? 1 : 0; }
                for (Setting s : m.settings) {
                    String k = m.name + "." + s.key;
                    if (!o.has(k)) continue;
                    JsonElement e = o.get(k);
                    switch (s.type) {
                        case SLIDER -> s.val = e.getAsDouble();
                        case COLOR -> s.color = e.getAsInt();
                        case MODE -> s.mode = Math.max(0, Math.min(s.modes.length - 1, e.getAsInt()));
                        case BOOL -> s.bool = e.getAsBoolean();
                    }
                }
            }
        } catch (Exception ignored) {}
    }
}
