package com.umear;

public class Setting {
    public enum Type { SLIDER, COLOR, MODE, BOOL }

    public final String key, label, unit;
    public final Type type;
    public double min, max, step = 1, val;
    public int color, mode;
    public String[] modes;
    public boolean bool;

    private Setting(String key, String label, Type type, String unit) {
        this.key = key; this.label = label; this.type = type; this.unit = unit;
    }

    public static Setting slider(String key, String label, double min, double max, double step, double def, String unit) {
        Setting s = new Setting(key, label, Type.SLIDER, unit);
        s.min = min; s.max = max; s.step = step; s.val = def;
        return s;
    }
    public static Setting color(String key, String label, int def) {
        Setting s = new Setting(key, label, Type.COLOR, ""); s.color = def; return s;
    }
    public static Setting mode(String key, String label, int def, String... modes) {
        Setting s = new Setting(key, label, Type.MODE, ""); s.mode = def; s.modes = modes; return s;
    }
    public static Setting bool(String key, String label, boolean def) {
        Setting s = new Setting(key, label, Type.BOOL, ""); s.bool = def; return s;
    }

    public double frac() { return (val - min) / (max - min); }

    public void setFromFrac(double f) {
        f = Math.max(0, Math.min(1, f));
        double v = min + f * (max - min);
        v = Math.round(v / step) * step;
        val = Math.max(min, Math.min(max, v));
    }

    public String shown() {
        return (step < 1 ? String.format("%.1f", val) : String.valueOf((int) Math.round(val))) + unit;
    }
}
