package com.umear;

import java.util.List;

public class Module {
    public final String cat, name, desc;
    public boolean enabled, open;
    public float exp, tog;
    public final List<Setting> settings;

    public Module(String cat, String name, String desc, boolean on, Setting... s) {
        this.cat = cat; this.name = name; this.desc = desc;
        this.enabled = on; this.tog = on ? 1 : 0;
        this.settings = List.of(s);
    }

    public Setting get(String k) {
        for (Setting s : settings) if (s.key.equals(k)) return s;
        throw new IllegalArgumentException(name + ": " + k);
    }
    public double num(String k) { return get(k).val; }
    public int col(String k) { return get(k).color; }
    public boolean bool(String k) { return get(k).bool; }
    public int mode(String k) { return get(k).mode; }

    public int bodyH() {
        int h = 6;
        for (Setting s : settings) h += s.type == Setting.Type.COLOR ? 40 : 20;
        return h;
    }
}
