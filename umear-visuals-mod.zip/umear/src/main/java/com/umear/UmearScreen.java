package com.umear;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class UmearScreen extends Screen {
    private record Hit(int x, int y, int w, int h, int kind, Module m, Setting s, int arg) {
        boolean in(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }
    // kinds: 0 tab, 1 toggle, 2 expand, 3 slider, 4 hue bar, 5 swatch, 6 mode, 7 bool, 8 close
    private static final int[] SW = {0xFF3B5C, 0xF97316, 0xFBBF24, 0x22C55E, 0x06B6D4, 0x3B82F6, 0x7C3AED, 0xEC4899, 0xFFFFFF, 0x9CA3AF};
    private static final int NW = 96;
    private static int tab = 1;

    private final List<Hit> hits = new ArrayList<>();
    private Hit drag;
    private float open, scroll, target, maxScroll;
    private long last = System.nanoTime();
    private int contentTop, contentH;

    public UmearScreen() { super(Text.literal("Umear Visuals")); }

    @Override public boolean shouldPause() { return false; }
    @Override public void removed() { Modules.save(); }

    // ---------- helpers ----------
    private static void rr(DrawContext c, int x, int y, int w, int h, int r, int col) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { c.fill(x, y, x + w, y + h, col); return; }
        c.fill(x, y + r, x + w, y + h - r, col);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int in = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            c.fill(x + in, y + i, x + w - in, y + i + 1, col);
            c.fill(x + in, y + h - i - 1, x + w - in, y + h - i, col);
        }
    }
    private static int mix(int a, int b, float t) {
        int r = 0;
        for (int sh = 0; sh < 32; sh += 8) {
            int x = (a >> sh) & 255, y = (b >> sh) & 255;
            r |= ((int) (x + (y - x) * t) & 255) << sh;
        }
        return r;
    }
    private static float step(float cur, float to, float rate) {
        float d = to - cur;
        return Math.abs(d) < 0.005f ? to : cur + d * Math.min(1f, rate);
    }
    private void txt(DrawContext c, String s, int x, int y, int col) { c.drawText(textRenderer, s, x, y, col, false); }
    private int tw(String s) { return textRenderer.getWidth(s); }

    // ---------- render ----------
    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(.1f, (now - last) / 1e9f);
        last = now;
        boolean an = Modules.ANIM.enabled;
        float spd = (float) Modules.ANIM.num("spd");
        open = an ? Math.min(1f, open + dt * spd * .35f) : 1f;
        float e = 1f - (float) Math.pow(1f - open, 3);

        if (Modules.BLUR.enabled) super.renderBackground(c, mx, my, delta);
        c.fill(0, 0, width, height, ((int) (Modules.BLUR.num("dim") * 2.55 * e)) << 24);

        hits.clear();
        int ac = Modules.accent(), rad = Modules.radius();
        if (Modules.THEME.bool("wm")) Tex.wm(c, (width - 180) / 2, 6, 180);

        int W = Math.min(width - 12, 500), H = Math.min(height - 60, 300);
        int x0 = (width - W) / 2, y0 = 40 + Math.max(0, (height - 60 - H) / 2);
        c.getMatrices().push();
        c.getMatrices().translate(0f, (1f - e) * 14f, 0f);

        rr(c, x0 - 1, y0 - 1, W + 2, H + 2, rad + 2, (ac & 0xFFFFFF) | 0x70000000);
        rr(c, x0, y0, W, H, rad + 1, 0xF40F0B18);

        // nav card
        rr(c, x0 + 6, y0 + 6, NW - 8, H - 12, rad, 0xFF0B0812);
        int lh = Tex.logo(c, x0 + 6 + (NW - 8 - 64) / 2, y0 + 12, 64);
        String[] names = Modules.CATS;
        int ty0 = y0 + 12 + lh + 10;
        for (int i = 0; i < names.length; i++) {
            int tx = x0 + 12, ty = ty0 + i * 26, tw = NW - 20;
            boolean sel = i == tab, hov = mx >= tx && mx < tx + tw && my >= ty && my < ty + 22;
            if (sel) rr(c, tx, ty, tw, 22, rad, ac);
            else if (hov) rr(c, tx, ty, tw, 22, rad, 0x22FFFFFF);
            txt(c, names[i], tx + (tw - tw(names[i])) / 2, ty + 7, sel ? 0xFFFFFFFF : 0xFF9A92B3);
            hits.add(new Hit(tx, ty, tw, 22, 0, null, null, i));
        }
        txt(c, "X", x0 + W - 14, y0 + 8, 0xFF9A92B3);
        hits.add(new Hit(x0 + W - 18, y0 + 4, 16, 16, 8, null, null, 0));

        // content
        int cx = x0 + NW + 8, cw = W - NW - 18;
        contentTop = y0 + 30; contentH = H - 38;
        String title = names[tab];
        c.drawText(textRenderer, Text.literal(title).formatted(Formatting.BOLD), cx + 2, y0 + 11, 0xFFFFFFFF, false);
        c.fill(cx + 2, y0 + 23, cx + 2 + tw(title) + 2, y0 + 25, ac);

        List<Module> list = Modules.of(names[tab]);
        scroll += (target - scroll) * Math.min(1f, dt * (an ? 18f : 100f));
        int y = contentTop - Math.round(scroll), total = 0;
        c.enableScissor(cx, contentTop, cx + cw, contentTop + contentH);
        for (Module m : list) {
            m.exp = step(m.exp, m.open ? 1 : 0, dt * spd * (an ? 1f : 100f));
            m.tog = step(m.tog, m.enabled ? 1 : 0, dt * spd * 1.5f * (an ? 1f : 100f));
            int bh = Math.round(m.bodyH() * m.exp), h = 26 + bh;
            rr(c, cx, y, cw, h, rad, 0xFF15111E);
            if (m.exp > .02f) rr(c, cx, y, cw, h, rad, (ac & 0xFFFFFF) | 0x1C000000);
            txt(c, m.name, cx + 10, y + 9, 0xFFF1EEFB);
            int nw = tw(m.name);
            if (cw - nw > 170) txt(c, m.desc, cx + nw + 18, y + 9, 0xFF6F6785);
            int tx = cx + cw - 34, ty = y + 7;
            rr(c, tx, ty, 24, 12, 6, mix(0xFF3A3447, ac, m.tog));
            rr(c, tx + 2 + Math.round(10 * m.tog), ty + 2, 8, 8, 4, 0xFFFFFFFF);
            hits.add(new Hit(cx, y, cw - 40, 26, 2, m, null, 0));
            hits.add(new Hit(tx - 2, ty - 2, 28, 16, 1, m, null, 0));

            if (m.exp > .02f) {
                c.enableScissor(cx, y + 26, cx + cw, y + h);
                boolean live = m.exp > .9f;
                int by = y + 28;
                for (Setting s : m.settings) {
                    txt(c, s.label, cx + 10, by + 6, 0xFFC9C2DC);
                    switch (s.type) {
                        case SLIDER -> {
                            int bx = cx + (int) (cw * .45f), bw = cx + cw - 54 - bx;
                            int kx = bx + (int) (bw * s.frac());
                            rr(c, bx, by + 8, bw, 4, 2, 0xFF2E2840);
                            rr(c, bx, by + 8, Math.max(4, kx - bx), 4, 2, ac);
                            rr(c, kx - 3, by + 6, 7, 8, 3, 0xFFFFFFFF);
                            String v = s.shown();
                            txt(c, v, cx + cw - 10 - tw(v), by + 6, 0xFF8C84A3);
                            if (live) hits.add(new Hit(bx, by + 2, bw, 16, 3, m, s, 0));
                        }
                        case MODE -> {
                            String v = s.modes[s.mode];
                            int vw = tw(v) + 12;
                            rr(c, cx + cw - 10 - vw, by + 3, vw, 14, 4, 0xFF241E33);
                            txt(c, v, cx + cw - 4 - vw, by + 6, 0xFFF1EEFB);
                            if (live) hits.add(new Hit(cx + cw - 10 - vw, by + 3, vw, 14, 6, m, s, 0));
                        }
                        case BOOL -> {
                            int bx = cx + cw - 32;
                            rr(c, bx, by + 5, 22, 10, 5, s.bool ? ac : 0xFF3A3447);
                            rr(c, bx + (s.bool ? 13 : 2), by + 7, 6, 6, 3, 0xFFFFFFFF);
                            if (live) hits.add(new Hit(bx, by + 3, 22, 14, 7, m, s, 0));
                        }
                        case COLOR -> {
                            rr(c, cx + cw - 26, by + 5, 14, 10, 3, 0xFF000000 | s.color);
                            int bx = cx + 10, bw = cw - 20;
                            for (int i = 0; i < bw; i += 2)
                                c.fill(bx + i, by + 18, bx + Math.min(i + 2, bw), by + 26, 0xFF000000 | (Color.HSBtoRGB(i / (float) bw, .85f, 1f) & 0xFFFFFF));
                            float hue = Color.RGBtoHSB((s.color >> 16) & 255, (s.color >> 8) & 255, s.color & 255, null)[0];
                            int kx = bx + (int) (bw * hue);
                            c.fill(kx - 1, by + 16, kx + 1, by + 28, 0xFFFFFFFF);
                            for (int i = 0; i < SW.length; i++) {
                                int sx = bx + i * 15, sy = by + 29;
                                if (SW[i] == s.color) c.fill(sx - 1, sy - 1, sx + 12, sy + 10, 0xFFFFFFFF);
                                c.fill(sx, sy, sx + 11, sy + 9, 0xFF000000 | SW[i]);
                                if (live) hits.add(new Hit(sx, sy, 11, 9, 5, m, s, SW[i]));
                            }
                            if (live) hits.add(new Hit(bx, by + 15, bw, 13, 4, m, s, 0));
                        }
                    }
                    by += s.type == Setting.Type.COLOR ? 40 : 20;
                }
                c.disableScissor();
            }
            y += h + 6;
            total += h + 6;
        }
        c.disableScissor();
        maxScroll = Math.max(0, total - contentH);
        target = Math.max(0, Math.min(maxScroll, target));

        txt(c, "Right Shift — закрыть", x0 + 12, y0 + H - 16, 0xFF5A5272);
        c.getMatrices().pop();
    }

    // ---------- input ----------
    private void drag(double mx) {
        if (drag == null) return;
        double f = (mx - drag.x()) / (double) drag.w();
        f = Math.max(0, Math.min(1, f));
        if (drag.kind() == 3) drag.s().setFromFrac(f);
        else drag.s().color = Color.HSBtoRGB((float) f, .85f, 1f) & 0xFFFFFF;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (!h.in(mx, my)) continue;
                if (h.kind() >= 1 && h.kind() <= 7 && (my < contentTop || my >= contentTop + contentH)) continue;
                switch (h.kind()) {
                    case 0 -> { tab = h.arg(); scroll = target = 0; }
                    case 1 -> h.m().enabled = !h.m().enabled;
                    case 2 -> h.m().open = !h.m().open;
                    case 3, 4 -> { drag = h; drag(mx); }
                    case 5 -> h.s().color = h.arg();
                    case 6 -> { h.s().mode = (h.s().mode + 1) % h.s().modes.length; if (h.m() == Modules.HITSOUND) Fx.playHit(); }
                    case 7 -> h.s().bool = !h.s().bool;
                    case 8 -> close();
                    default -> {}
                }
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (drag != null) { drag(mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (drag != null && drag.m() == Modules.HITSOUND) Fx.playHit();
        drag = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        target = (float) Math.max(0, Math.min(maxScroll, target - v * 24));
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
