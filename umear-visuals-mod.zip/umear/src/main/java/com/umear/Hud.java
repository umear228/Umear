package com.umear;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;

public final class Hud {
    public static void render(DrawContext c, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null || mc.currentScreen instanceof UmearScreen) return;
        if (Modules.THEME.bool("wm")) Tex.wm(c, (c.getScaledWindowWidth() - 110) / 2, 2, 110);
        Module cps = Modules.CPS, cb = Modules.COMBO;
        if (cps.enabled) line(c, "CPS: " + Modules.cps(), cps, 0);
        if (cb.enabled && Modules.combo > 0) {
            int row = cps.enabled && cps.mode("pos") == cb.mode("pos") ? 1 : 0;
            line(c, "Combo x" + Modules.combo, cb, row);
        }
    }

    private static void line(DrawContext c, String s, Module m, int row) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        float sc = (float) m.num("size") / 100f;
        int tw = tr.getWidth(s);
        float w = (tw + 8) * sc, h = 13 * sc;
        int sw = c.getScaledWindowWidth(), sh = c.getScaledWindowHeight();
        float off = row * (h + 3);
        float x, y;
        switch (m.mode("pos")) {
            case 0 -> { x = 6; y = 6 + off; }
            case 1 -> { x = sw - 6 - w; y = 6 + off; }
            case 2 -> { x = 6; y = sh - 6 - h - off; }
            case 3 -> { x = sw - 6 - w; y = sh - 6 - h - off; }
            default -> { x = (sw - w) / 2f; y = sh / 2f + 16 + off; }
        }
        MatrixStack ms = c.getMatrices();
        ms.push();
        ms.translate(x, y, 0f);
        ms.scale(sc, sc, 1f);
        if (m.bool("bg")) c.fill(0, 0, tw + 8, 13, 0x90000000);
        c.fill(0, 12, tw + 8, 13, Modules.accent());
        c.drawText(tr, s, 4, 2, 0xFF000000 | m.col("col"), true);
        ms.pop();
    }
}
