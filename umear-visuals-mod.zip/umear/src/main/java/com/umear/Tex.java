package com.umear;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;

public final class Tex {
    static final Identifier LOGO = Identifier.of("umear", "textures/gui/logo.png");
    static final Identifier WM = Identifier.of("umear", "textures/gui/watermark.png");
    static final int LW = 256, LH = 172, WW = 640, WH = 92;

    private static void draw(DrawContext c, Identifier id, int x, int y, int w, int h, int tw, int th) {
        c.drawTexture(RenderLayer::getGuiTextured, id, x, y, 0f, 0f, w, h, tw, th, tw, th);
    }
    public static int logo(DrawContext c, int x, int y, int w) { int h = w * LH / LW; draw(c, LOGO, x, y, w, h, LW, LH); return h; }
    public static int wm(DrawContext c, int x, int y, int w) { int h = w * WH / WW; draw(c, WM, x, y, w, h, WW, WH); return h; }
}
