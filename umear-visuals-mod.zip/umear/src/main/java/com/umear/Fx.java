package com.umear;

import com.umear.mixin.OverlayTextureAccessor;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public final class Fx {
    private static final Random RND = new Random();
    private static final ArrayDeque<Vec3d> TRAIL = new ArrayDeque<>();
    private static Vec3d lastPos;
    private static int prevHurt;
    private static int lastOverlay = 0xB2FF0000;
    private static final String[] SND = {"ui.button.click", "entity.experience_orb.pickup", "block.note_block.bell", "entity.arrow.hit_player"};

    // ---------- tick ----------
    public static void tick(MinecraftClient mc) {
        Modules.ticks++;
        while (UmearClient.OPEN.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new UmearScreen());
        }
        overlay(mc);
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) { TRAIL.clear(); lastPos = null; return; }

        Module cb = Modules.COMBO;
        if (Modules.combo > 0) {
            boolean timeout = System.currentTimeMillis() - Modules.lastHit > cb.num("to") * 1000;
            boolean hurt = cb.bool("rst") && p.hurtTime > 0 && prevHurt == 0;
            if (timeout || hurt) Modules.combo = 0;
        }
        prevHurt = p.hurtTime;
        trail(p);
        particles(mc, p);
    }

    public static void onHit() {
        if (Modules.COMBO.enabled) { Modules.combo++; Modules.lastHit = System.currentTimeMillis(); }
        if (Modules.HITSOUND.enabled) playHit();
    }

    public static void playHit() {
        Module h = Modules.HITSOUND;
        SoundEvent se = SoundEvent.of(Identifier.ofVanilla(SND[h.mode("snd")]));
        float pitch = (float) (h.num("pitch") / 100.0), vol = (float) (h.num("vol") / 100.0);
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(se, pitch, vol));
    }

    // ---------- hit color: rewrites the red "hurt" rows of the overlay texture ----------
    private static void overlay(MinecraftClient mc) {
        if (mc.gameRenderer == null) return;
        Module m = Modules.HITCOLOR;
        int want = m.enabled ? (((int) (m.num("op") * 2.55)) << 24) | (m.col("col") & 0xFFFFFF) : 0xB2FF0000;
        if (want == lastOverlay) return;
        OverlayTexture ot = mc.gameRenderer.getOverlayTexture();
        NativeImageBackedTexture tex = ((OverlayTextureAccessor) ot).umear$getTexture();
        NativeImage img = tex.getImage();
        if (img == null) return;
        for (int y = 0; y < 8; y++) for (int x = 0; x < 16; x++) img.setColorArgb(x, y, want);
        tex.upload();
        lastOverlay = want;
    }

    // ---------- trails ----------
    private static void trail(ClientPlayerEntity p) {
        Module t = Modules.TRAILS;
        if (!t.enabled) { TRAIL.clear(); lastPos = null; return; }
        Vec3d pos = p.getPos();
        if (lastPos == null || pos.squaredDistanceTo(lastPos) > 0.0016) { TRAIL.addLast(pos); lastPos = pos; }
        else if (!TRAIL.isEmpty() && (Modules.ticks & 1) == 0) TRAIL.removeFirst();
        int max = (int) t.num("len");
        while (TRAIL.size() > max) TRAIL.removeFirst();
    }

    // ---------- particles ----------
    private static void particles(MinecraftClient mc, ClientPlayerEntity p) {
        Module m = Modules.PARTICLES;
        if (!m.enabled) return;
        double chance = m.num("n") / 10.0;
        int cnt = (int) chance;
        if (RND.nextDouble() < chance - cnt) cnt++;
        ParticleEffect e = switch (m.mode("type")) {
            case 0 -> ParticleTypes.FLAME;
            case 1 -> ParticleTypes.HEART;
            case 2 -> ParticleTypes.END_ROD;
            default -> ParticleTypes.CRIT;
        };
        for (int i = 0; i < cnt; i++) {
            double a = RND.nextDouble() * Math.PI * 2, r = m.num("r");
            mc.world.addParticle(e, p.getX() + Math.cos(a) * r, p.getY() + RND.nextDouble() * p.getHeight(),
                    p.getZ() + Math.sin(a) * r, 0, 0.02, 0);
        }
    }

    // ---------- world rendering: trail ribbon and china hat ----------
    public static void renderWorld(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        MatrixStack ms = ctx.matrixStack();
        VertexConsumerProvider vp = ctx.consumers();
        if (p == null || ms == null || vp == null) return;
        boolean tr = Modules.TRAILS.enabled && !TRAIL.isEmpty();
        boolean hat = Modules.HAT.enabled && !mc.options.getPerspective().isFirstPerson();
        if (!tr && !hat) return;

        Vec3d cam = ctx.camera().getPos();
        float td = mc.getRenderTickCounter().getTickDelta(false);
        Vec3d pp = p.getLerpedPos(td);
        VertexConsumer b = vp.getBuffer(RenderLayer.getDebugQuads());
        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f m = ms.peek().getPositionMatrix();
        if (tr) drawTrail(b, m, pp);
        if (hat) drawHat(b, m, p, pp);
        ms.pop();
        if (vp instanceof VertexConsumerProvider.Immediate imm) imm.draw(RenderLayer.getDebugQuads());
    }

    private static int hsv(float h) { return Color.HSBtoRGB(h % 1f, .8f, 1f) & 0xFFFFFF; }

    private static void drawTrail(VertexConsumer b, Matrix4f m, Vec3d cur) {
        Module t = Modules.TRAILS;
        int style = t.mode("st");
        float h = style == 1 ? .4f : 1.2f;
        List<Vec3d> pts = new ArrayList<>(TRAIL);
        pts.add(cur);
        int n = pts.size();
        for (int i = 0; i < n - 1; i++) {
            Vec3d a = pts.get(i), c = pts.get(i + 1);
            int rgb = t.bool("rb") ? hsv(i * 0.04f + Modules.ticks * 0.01f) : (t.col("col") & 0xFFFFFF);
            int c0 = ((int) (200f * i / (n - 1)) << 24) | rgb, c1 = ((int) (200f * (i + 1) / (n - 1)) << 24) | rgb;
            float ax = (float) a.x, ay = (float) a.y + .05f, az = (float) a.z, cx = (float) c.x, cy = (float) c.y + .05f, cz = (float) c.z;
            if (style == 0) {
                float dx = cx - ax, dz = cz - az, len = (float) Math.sqrt(dx * dx + dz * dz);
                if (len < 1e-4f) continue;
                float px = -dz / len * .07f, pz = dx / len * .07f;
                quad(b, m, ax - px, ay, az - pz, c0, ax + px, ay, az + pz, c0, cx + px, cy, cz + pz, c1, cx - px, cy, cz - pz, c1);
            } else {
                quad(b, m, ax, ay, az, c0, ax, ay + h, az, c0, cx, cy + h, cz, c1, cx, cy, cz, c1);
            }
        }
    }

    private static void drawHat(VertexConsumer b, Matrix4f m, ClientPlayerEntity p, Vec3d pp) {
        Module hm = Modules.HAT;
        float s = (float) hm.num("size") / 100f, r = .55f * s, hh = .32f * s;
        float cx = (float) pp.x, cz = (float) pp.z;
        float cy = (float) pp.y + p.getHeight() + (float) hm.num("h") / 100f * .4f;
        int segs = 32;
        for (int i = 0; i < segs; i++) {
            double a0 = Math.PI * 2 * i / segs, a1 = Math.PI * 2 * (i + 1) / segs;
            float x0 = cx + (float) Math.cos(a0) * r, z0 = cz + (float) Math.sin(a0) * r;
            float x1 = cx + (float) Math.cos(a1) * r, z1 = cz + (float) Math.sin(a1) * r;
            int rgb = hm.bool("rb") ? hsv(i / (float) segs + Modules.ticks * 0.01f) : (hm.col("col") & 0xFFFFFF);
            int top = 0xFF000000 | rgb, base = 0xD2000000 | rgb, under = 0x6E000000 | rgb;
            quad(b, m, cx, cy + hh, cz, top, cx, cy + hh, cz, top, x1, cy, z1, base, x0, cy, z0, base);
            quad(b, m, cx, cy, cz, under, cx, cy, cz, under, x0, cy, z0, under, x1, cy, z1, under);
        }
    }

    /** Draws a quad twice (both windings) so it is visible from either side. */
    private static void quad(VertexConsumer b, Matrix4f m,
                             float x1, float y1, float z1, int c1, float x2, float y2, float z2, int c2,
                             float x3, float y3, float z3, int c3, float x4, float y4, float z4, int c4) {
        b.vertex(m, x1, y1, z1).color(c1); b.vertex(m, x2, y2, z2).color(c2);
        b.vertex(m, x3, y3, z3).color(c3); b.vertex(m, x4, y4, z4).color(c4);
        b.vertex(m, x4, y4, z4).color(c4); b.vertex(m, x3, y3, z3).color(c3);
        b.vertex(m, x2, y2, z2).color(c2); b.vertex(m, x1, y1, z1).color(c1);
    }
}
