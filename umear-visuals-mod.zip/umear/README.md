# Umear Visuals (Fabric 1.21.4)

Открыть меню в игре: Right Shift (можно поменять в настройках управления).

## Что внутри
- Combat: Hit Sound, CPS Display, Combo Counter
- Visuals: Hit Color, Trails, Particles, China Hat, Time Changer
- Misc: GUI Blur, GUI Animation, Custom Theme (акцент, скругление, ватермарк)
Настройки сохраняются в config/umear_visuals.json.

## Как собрать .jar
1. Установите JDK 21 и Gradle 8.12 (или IntelliJ IDEA, он всё подтянет сам).
2. В папке проекта выполните один раз:  gradle wrapper --gradle-version 8.12
3. Сборка:  ./gradlew build   (Windows: gradlew.bat build)
4. Готовый мод: build/libs/umear-visuals-1.0.0.jar (файл без -sources).
5. Положите его в папку mods вместе с Fabric API 0.119.4+1.21.4 (Fabric Loader 0.16.10 или новее).

Запуск прямо из проекта для проверки:  ./gradlew runClient

Если сборка выдаёт ошибку, пришлите текст ошибки целиком, я исправлю код.
