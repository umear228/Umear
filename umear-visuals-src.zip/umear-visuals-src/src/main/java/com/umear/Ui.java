package com.umear;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.HashMap;

public final class Ui {
    public static float alpha = 1f;
    public static float dt = 0.016f;
    public static boolean menuFont;
    private static long last = System.nanoTime();

    private static final HashMap<String, Text> PLAIN = new HashMap<>();
    private static final HashMap<String, Text> FONTED = new HashMap<>();
    private static int fontMode = -1;
    private static final Identifier[] FONTS = {
        Identifier.of("minecraft", "default"), Identifier.of("minecraft", "uniform"), Identifier.of("minecraft", "alt")
    };

    public static void frame() {
        long n = System.nanoTime();
        dt = Math.min(0.1f, (n - last) / 1e9f);
        last = n;
    }

    // ---------- цвет ----------
    public static int a(int c) {
        int al = Math.round((c >>> 24) * alpha);
        return (al << 24) | (c & 0xFFFFFF);
    }

    public static int withA(int rgb, int al) {
        return (Math.max(0, Math.min(255, al)) << 24) | (rgb & 0xFFFFFF);
    }

    public static int mix(int c1, int c2, float t) {
        t = Math.max(0, Math.min(1, t));
        int a = (int) ((c1 >>> 24) + ((c2 >>> 24) - (c1 >>> 24)) * t);
        int r = (int) (((c1 >> 16) & 255) + (((c2 >> 16) & 255) - ((c1 >> 16) & 255)) * t);
        int g = (int) (((c1 >> 8) & 255) + (((c2 >> 8) & 255) - ((c1 >> 8) & 255)) * t);
        int b = (int) ((c1 & 255) + ((c2 & 255) - (c1 & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** HSV -> 0xFFRRGGBB (без java.awt, он недоступен на Android). */
    public static int hsv(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        float c = v * s, x = c * (1 - Math.abs((h * 6) % 2 - 1)), m = v - c;
        float r, g, b;
        int i = (int) (h * 6);
        switch (i) {
            case 0: r = c; g = x; b = 0; break;
            case 1: r = x; g = c; b = 0; break;
            case 2: r = 0; g = c; b = x; break;
            case 3: r = 0; g = x; b = c; break;
            case 4: r = x; g = 0; b = c; break;
            default: r = c; g = 0; b = x; break;
        }
        return 0xFF000000 | (Math.round((r + m) * 255) << 16) | (Math.round((g + m) * 255) << 8) | Math.round((b + m) * 255);
    }

    public static void rgb2hsv(int rgb, float[] o) {
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b)), d = mx - mn, h;
        if (d == 0) h = 0;
        else if (mx == r) h = ((g - b) / d % 6) / 6f;
        else if (mx == g) h = ((b - r) / d + 2) / 6f;
        else h = ((r - g) / d + 4) / 6f;
        if (h < 0) h += 1;
        o[0] = h; o[1] = mx == 0 ? 0 : d / mx; o[2] = mx;
    }

    // ---------- easing ----------
    public static float ease(float t) {
        t = Math.max(0, Math.min(1, t));
        float u = 1 - t;
        return 1 - u * u * u;
    }

    public static float back(float t) {
        t = Math.max(0, Math.min(1, t));
        float c1 = 1.70158f, c3 = c1 + 1, u = t - 1;
        return 1 + c3 * u * u * u + c1 * u * u;
    }

    // ---------- примитивы ----------
    public static void fill(DrawContext g, int x, int y, int x2, int y2, int c) {
        g.fill(x, y, x2, y2, a(c));
    }

    public static void round(DrawContext g, int x, int y, int w, int h, int r, int c) {
        c = a(c);
        if ((c >>> 24) == 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 1) { g.fill(x, y, x + w, y + h, c); return; }
        g.fill(x + r, y, x + w - r, y + h, c);
        g.fill(x, y + r, x + r, y + h - r, c);
        g.fill(x + w - r, y + r, x + w, y + h - r, c);
        for (int i = 0; i < r; i++) {
            double d = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - d * d));
            g.fill(x + inset, y + i, x + r, y + i + 1, c);
            g.fill(x + w - r, y + i, x + w - inset, y + i + 1, c);
            g.fill(x + inset, y + h - i - 1, x + r, y + h - i, c);
            g.fill(x + w - r, y + h - i - 1, x + w - inset, y + h - i, c);
        }
    }

    /** Текстура с ЯВНЫМ ARGB-цветом (белый, альфа = Ui.alpha) — фикс прозрачного watermark. */
    public static void tex(DrawContext g, Identifier id, int x, int y, int w, int h) {
        int col = (Math.round(255 * alpha) << 24) | 0xFFFFFF;
        g.drawTexture(RenderLayer::getGuiTextured, id, x, y, 0f, 0f, w, h, w, h, col);
    }

    // ---------- текст ----------
    private static boolean fontOn() {
        Module f = Modules.FONT;
        return f != null && f.enabled && (menuFont ? f.bool("menu") : f.bool("hud"));
    }

    public static Text txt(String s) {
        boolean on = fontOn();
        if (on) {
            int m = Modules.FONT.mode("font");
            if (m != fontMode) { fontMode = m; FONTED.clear(); }
        }
        HashMap<String, Text> map = on ? FONTED : PLAIN;
        Text t = map.get(s);
        if (t == null) {
            if (map.size() > 600) map.clear();
            Style st = on ? Style.EMPTY.withFont(FONTS[Math.min(fontMode, 2)]) : Style.EMPTY;
            t = Text.literal(s).setStyle(st);
            map.put(s, t);
        }
        return t;
    }

    public static int tw(String s) {
        return MinecraftClient.getInstance().textRenderer.getWidth(txt(s));
    }

    public static void text(DrawContext g, String s, int x, int y, int c) { text(g, s, x, y, c, true); }

    public static void text(DrawContext g, String s, int x, int y, int c, boolean shadow) {
        c = a(c);
        if ((c >>> 24) < 6) return;
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        g.drawText(tr, txt(s), x, y, c, shadow);
    }

    public static void textS(DrawContext g, String s, int x, int y, int c, float sc) {
        var ms = g.getMatrices();
        ms.push();
        ms.translate(x, y, 0);
        ms.scale(sc, sc, 1f);
        text(g, s, 0, 0, c, false);
        ms.pop();
    }

    public static void ctext(DrawContext g, String s, int cx, int y, int c) {
        text(g, s, cx - tw(s) / 2, y, c);
    }
}
