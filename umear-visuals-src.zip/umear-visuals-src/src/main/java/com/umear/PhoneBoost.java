package com.umear;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.particle.ParticlesMode;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Phone Boost: модуль оптимизации под телефон (Zalith / Pojav / Amethyst).
 * Включается в меню Misc. При выключении возвращает ВСЕ настройки игрока как были.
 */
public final class PhoneBoost {
    public static final Module MODULE = new Module("Misc", "Phone Boost",
            "Оптимизация под телефон: дальность, частицы, облака, FPS-лимит, лёгкий режим эффектов",
            false,
            Setting.mode("preset", "Пресет", 1, "Мягкий", "Сильный", "Ультра"),
            Setting.slider("fps", "Лимит FPS", 20, 120, 60, 5, ""),
            Setting.bool("adaptive", "Авто-дальность по FPS", true),
            Setting.slider("minView", "Мин. дальность", 2, 12, 4, 1, " ч."),
            Setting.bool("lite", "Выключать тяжёлые эффекты Umear", true),
            Setting.bool("noBob", "Без покачивания камеры", false)
    );

    //                          view  sim  entScale  blend mip
    private static final int[]    VIEW  = {8, 6, 4};
    private static final int[]    SIM   = {6, 5, 4};
    private static final double[] ENT   = {0.75, 0.6, 0.5};
    private static final int[]    BLEND = {1, 0, 0};
    private static final int[]    MIP   = {2, 1, 0};

    // Тяжёлые модули Umear, которые отключаются в «лёгком» режиме
    private static Module[] heavy() {
        return new Module[]{Modules.BLUR, Modules.TRAILS, Modules.PARTICLES, Modules.GLOW,
                Modules.BURST, Modules.HAT, Modules.SLASH, Modules.ANIM};
    }

    private static boolean applied;
    private static int lastPreset = -1;
    private static int tick, curView, goodStreak;
    private static final Map<Module, Boolean> prevMods = new LinkedHashMap<>();

    // снимок оригинальных настроек
    private static int oView, oSim, oBlend, oMip, oFps;
    private static double oEnt;
    private static ParticlesMode oPart;
    private static GraphicsMode oGfx;
    private static CloudRenderMode oCloud;
    private static boolean oAo, oShadows, oVsync, oBob;

    private PhoneBoost() {}

    /** Что писать в конфиг: настоящее состояние модуля, а не временно выключенное «лёгким» режимом. */
    public static boolean persisted(Module m) {
        Boolean b = prevMods.get(m);
        return b != null ? b : m.enabled;
    }

    public static void tick(MinecraftClient mc) {
        if (mc == null || mc.options == null) return;
        boolean on = MODULE.enabled;
        if (on && !applied) {
            snapshot(mc.options);
            applied = true;
            lastPreset = -1;
        } else if (!on && applied) {
            restore(mc.options);
            applied = false;
            return;
        }
        if (!on) return;

        GameOptions o = mc.options;
        int preset = MODULE.mode("preset");
        if (preset != lastPreset) {
            lastPreset = preset;
            applyPreset(o, preset);
            curView = VIEW[preset];
        }
        // лимит FPS + выключенный vsync (vsync на телефоне даёт просадки до 30)
        o.getMaxFps().setValue((int) MODULE.num("fps"));
        o.getEnableVsync().setValue(false);
        o.getBobView().setValue(!MODULE.bool("noBob") && oBob);

        if (MODULE.bool("lite")) liteOn(); else liteOff();

        // Авто-подстройка дальности каждые ~2 секунды
        if (MODULE.bool("adaptive") && ++tick % 40 == 0 && mc.world != null) {
            int target = (int) MODULE.num("fps");
            int fps = mc.getCurrentFps();
            int min = (int) MODULE.num("minView");
            int max = VIEW[preset];
            if (fps < target - 8 && curView > min) {
                curView--;
                goodStreak = 0;
            } else if (fps > target + 20 && curView < max) {
                if (++goodStreak >= 3) { curView++; goodStreak = 0; }
            } else {
                goodStreak = 0;
            }
            o.getViewDistance().setValue(curView);
        }
    }

    private static void applyPreset(GameOptions o, int p) {
        o.getViewDistance().setValue(VIEW[p]);
        o.getSimulationDistance().setValue(SIM[p]);
        o.getEntityDistanceScaling().setValue(ENT[p]);
        o.getBiomeBlendRadius().setValue(BLEND[p]);
        o.getMipmapLevels().setValue(MIP[p]);
        o.getParticles().setValue(p == 0 ? ParticlesMode.DECREASED : ParticlesMode.MINIMAL);
        o.getGraphicsMode().setValue(GraphicsMode.FAST);
        o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        o.getAo().setValue(p == 0);
        o.getEntityShadows().setValue(false);
    }

    private static void snapshot(GameOptions o) {
        oView = o.getViewDistance().getValue();
        oSim = o.getSimulationDistance().getValue();
        oEnt = o.getEntityDistanceScaling().getValue();
        oBlend = o.getBiomeBlendRadius().getValue();
        oMip = o.getMipmapLevels().getValue();
        oFps = o.getMaxFps().getValue();
        oPart = o.getParticles().getValue();
        oGfx = o.getGraphicsMode().getValue();
        oCloud = o.getCloudRenderMode().getValue();
        oAo = o.getAo().getValue();
        oShadows = o.getEntityShadows().getValue();
        oVsync = o.getEnableVsync().getValue();
        oBob = o.getBobView().getValue();
    }

    private static void restore(GameOptions o) {
        o.getViewDistance().setValue(oView);
        o.getSimulationDistance().setValue(oSim);
        o.getEntityDistanceScaling().setValue(oEnt);
        o.getBiomeBlendRadius().setValue(oBlend);
        o.getMipmapLevels().setValue(oMip);
        o.getMaxFps().setValue(oFps);
        o.getParticles().setValue(oPart);
        o.getGraphicsMode().setValue(oGfx);
        o.getCloudRenderMode().setValue(oCloud);
        o.getAo().setValue(oAo);
        o.getEntityShadows().setValue(oShadows);
        o.getEnableVsync().setValue(oVsync);
        o.getBobView().setValue(oBob);
        liteOff();
    }

    private static void liteOn() {
        if (!prevMods.isEmpty()) return;
        for (Module m : heavy()) {
            if (m == null) continue;
            prevMods.put(m, m.enabled);
            m.enabled = false;   // без toggle(): не спамим уведомлениями и звуком
        }
    }

    private static void liteOff() {
        if (prevMods.isEmpty()) return;
        for (Map.Entry<Module, Boolean> e : prevMods.entrySet()) {
            e.getKey().enabled = e.getValue();
        }
        prevMods.clear();
    }
}
