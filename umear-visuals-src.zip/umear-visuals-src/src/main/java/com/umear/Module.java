package com.umear;

public final class Module {
    public final String cat, name, desc;
    public boolean enabled;
    public final Setting[] settings;
    public float tog, exp;   // анимации переключателя и раскрытия
    public boolean open;

    public Module(String cat, String name, String desc, boolean on, Setting... s) {
        this.cat = cat; this.name = name; this.desc = desc;
        this.enabled = on; this.tog = on ? 1f : 0f;
        this.settings = s;
    }

    public Setting get(String k) {
        for (Setting s : settings) if (s.key.equals(k)) return s;
        throw new IllegalArgumentException(name + ": " + k);
    }

    public double num(String k) { return get(k).val; }
    /** Цвет всегда с альфой 255 (иначе текст/элементы становились прозрачными). */
    public int col(String k) { return 0xFF000000 | get(k).color; }
    public boolean bool(String k) { return get(k).bool; }
    public int mode(String k) { return get(k).mode; }

    public void toggle() {
        enabled = !enabled;
        Modules.toggled(this);
    }
}
