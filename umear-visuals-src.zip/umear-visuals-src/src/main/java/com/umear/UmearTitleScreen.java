package com.umear;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;

/** Лёгкое пиксельное главное меню в стиле «чибик». Ничего не выделяется на кадр, всё считается один раз. */
public class UmearTitleScreen extends Screen {
    private static final String[] SPR = {
            "....OOOOOOOO....",
            "..OOHHHHHHHHOO..",
            ".OHHHHHHHHHHHHO.",
            "OHHHHHHHHHHHHHHO",
            "OHHHSSSSSSSSHHHO",
            "OHHSSSSSSSSSSHHO",
            "OHHSSSSSSSSSSHHO",
            "OHHSEESSSSEESHHO",
            "OHHSEWSSSSEWSHHO",
            "OHHSEESSSSEESHHO",
            "OHHSBBSSSSBBSHHO",
            ".OHSSSSMMSSSSHO.",
            ".OHHSSSSSSSSHHO.",
            "..OHHHSSSSHHHO..",
            "...OOOHHHHOOO...",
            ".....OOOOOO....."
    };
    private static final String[] LABELS = {"Одиночная игра", "Мультиплеер", "Настройки", "Umear Menu", "Выход"};
    private static final int INK = 0xFF2B2147, SKIN = 0xFFFFE0C8;

    // спрайт заранее разложен на горизонтальные отрезки одного цвета: {x, y, длина, цвет}
    private static final int[] RUNS;

    static {
        java.util.ArrayList<int[]> r = new java.util.ArrayList<>();
        for (int y = 0; y < SPR.length; y++) {
            int x = 0;
            while (x < 16) {
                char c = SPR[y].charAt(x);
                int x2 = x;
                while (x2 < 16 && SPR[y].charAt(x2) == c) x2++;
                int col = color(c);
                if (col != 0) r.add(new int[]{x, y, x2 - x, col});
                x = x2;
            }
        }
        RUNS = new int[r.size() * 4];
        for (int i = 0; i < r.size(); i++) System.arraycopy(r.get(i), 0, RUNS, i * 4, 4);
    }

    private static int color(char c) {
        return switch (c) {
            case 'O' -> INK;
            case 'H' -> 0xFFFF8FC7;
            case 'S' -> SKIN;
            case 'E' -> INK;
            case 'W' -> 0xFFFFFFFF;
            case 'B' -> 0xFFFF9FB0;
            case 'M' -> 0xFFC0506E;
            default -> 0;
        };
    }

    private static final String[] BG_NAMES = {"Сумерки", "Закат", "Ночь", "Синтвейв", "День", "Аврора", "Сакура"};
    // верх, середина, низ, холм, подсветка холма
    private static final int[][] PAL = {
            {0xFF1B1530, 0xFF3B2B66, 0xFF5A3F8C, 0xFF2A1F4A, 0xFF4B3A75},
            {0xFF2B1B4D, 0xFFFF6B6B, 0xFFFFC27A, 0xFF2A1233, 0xFF4A2250},
            {0xFF050A1F, 0xFF101C44, 0xFF1C2B5A, 0xFF0B1230, 0xFF1B2A5C},
            {0xFF14002E, 0xFF2E0A5C, 0xFF4B0A6E, 0xFF12002A, 0xFFFF2BD6},
            {0xFF4FA8FF, 0xFF8CCBFF, 0xFFBFE6FF, 0xFF2E7D32, 0xFF4CAF50},
            {0xFF03101F, 0xFF072436, 0xFF0B2A3C, 0xFFB8D8F0, 0xFFFFFFFF},
            {0xFFFFC8E0, 0xFFFFA9CF, 0xFFFF8FC7, 0xFFB05588, 0xFFE87AB0},
    };
    private static int randomBg = new java.util.Random().nextInt(7);

    /** Текущий фон (0..6): по нему же выбирается музыка. */
    public static int currentBg() {
        int m = Modules.TITLE == null ? 0 : Modules.TITLE.mode("bg");
        return m >= 7 ? randomBg : m;
    }

    private int curBg() { return currentBg(); }

    private void disc(DrawContext g, int cx, int cy, int r, int c) {
        for (int dy = -r; dy < r; dy += 4) {
            double d = r * r - (dy + 2.0) * (dy + 2.0);
            if (d <= 0) continue;
            int dx = ((int) Math.sqrt(d)) / 4 * 4;
            g.fill(cx - dx, cy + dy, cx + dx, cy + dy + 4, c);
        }
    }

    private void drawBg(DrawContext g, long now) {
        int bg = curBg();
        int[] p = PAL[bg];
        int bands = 24;
        for (int i = 0; i < bands; i++) {
            float t = i / (float) (bands - 1);
            int col = t < 0.6f ? Ui.mix(p[0], p[1], t / 0.6f) : Ui.mix(p[1], p[2], (t - 0.6f) / 0.4f);
            g.fill(0, height * i / bands, width, height * (i + 1) / bands + 1, col);
        }
        // звёзды (ночные фоны)
        if (bg == 0 || bg == 2 || bg == 3 || bg == 5) {
            for (int i = 0; i < stars.length; i += 3) {
                int ph = (int) ((now + stars[i + 2]) % 2000);
                int a = ph < 1000 ? 90 + ph * 165 / 1000 : 255 - (ph - 1000) * 165 / 1000;
                g.fill(stars[i], stars[i + 1], stars[i] + 2, stars[i + 1] + 2, Ui.withA(0xFFF0FA, a));
            }
        }
        switch (bg) {
            case 1 -> disc(g, width * 3 / 10, height * 6 / 10, height / 8, 0xFFFFE9A0);
            case 2 -> {
                int mx = width * 72 / 100, my = height * 28 / 100, r = height / 10;
                disc(g, mx, my, r, 0xFFF3F0D0);
                g.fill(mx - r / 2, my - r / 3, mx - r / 2 + 8, my - r / 3 + 8, 0xFFD8D2A8);
                g.fill(mx + r / 4, my + r / 4, mx + r / 4 + 12, my + r / 4 + 12, 0xFFD8D2A8);
                g.fill(mx + r / 3, my - r / 2, mx + r / 3 + 4, my - r / 2 + 4, 0xFFD8D2A8);
            }
            case 3 -> {
                int cx = width / 2, hy = height * 55 / 100, r = height / 6;
                for (int dy = -r; dy < 0; dy += 4) {
                    double d = r * r - (dy + 2.0) * (dy + 2.0);
                    if (d <= 0) continue;
                    if (((dy + r) / 4) % 3 == 2 && dy > -r / 2) continue;       // полосы на солнце
                    int dx = ((int) Math.sqrt(d)) / 4 * 4;
                    g.fill(cx - dx, hy + dy, cx + dx, hy + dy + 4, Ui.mix(0xFFFFE066, 0xFFFF2BD6, (dy + r) / (float) r));
                }
                g.fill(0, hy, width, height, 0xFF12002A);
                int off = (int) (now / 40 % 24);
                for (int k = 0; k < 12; k++) {
                    int yy = hy + 4 + (k * 24 + off) * (k * 24 + off) / 300;
                    if (yy < height) g.fill(0, yy, width, yy + 1, 0xAAFF2BD6);
                }
                for (int i = -7; i <= 7; i++)
                    for (int y = hy; y < height; y += 10)
                        g.fill(cx + i * (y - hy) * 3 / 4, y, cx + i * (y - hy) * 3 / 4 + 1, y + 10, 0x66FF2BD6);
            }
            case 4 -> {
                int span = width + 140;
                for (int i = 0; i < 5; i++) {
                    int x = (int) ((i * span / 5 + now / 30) % span) - 70, y = height * (14 + i * 9) / 100;
                    g.fill(x, y + 8, x + 56, y + 20, 0xFFFFFFFF);
                    g.fill(x + 10, y, x + 40, y + 12, 0xFFFFFFFF);
                    g.fill(x + 4, y + 18, x + 52, y + 22, 0xFFDDEEFF);
                }
                disc(g, width - 60, 52, 24, 0xFFFFF2A0);
            }
            case 5 -> {
                for (int i = 0; i < width; i += 4) {
                    double w1 = Math.sin(i * 0.02 + now / 900.0), w2 = Math.sin(i * 0.013 - now / 1300.0);
                    int y1 = (int) (height * 0.22 + w1 * height * 0.06), y2 = (int) (height * 0.42 + w2 * height * 0.05);
                    g.fill(i, y1, i + 4, y1 + height / 6, 0x5538FFB0);
                    g.fill(i, y2, i + 4, y2 + height / 8, 0x44B060FF);
                }
            }
            case 6 -> {
                for (int i = 0; i < stars.length; i += 3) {
                    if (i / 3 >= 30) break;
                    int y = (int) ((stars[i + 1] + now / (18 + stars[i + 2] % 12)) % (height + 10)) - 5;
                    int x = stars[i] + (int) (Math.sin(now / 700.0 + stars[i + 2]) * 8);
                    g.fill(x, y, x + 4, y + 3, 0xFFFFFFFF);
                    g.fill(x + 1, y + 3, x + 3, y + 4, 0xFFFFD0E8);
                }
            }
            default -> { }
        }
        if (bg != 3) {
            for (int i = 0; i < hill.length; i++) {
                int h = hill[i];
                g.fill(i * 4, height - h, i * 4 + 4, height, p[3]);
                g.fill(i * 4, height - h, i * 4 + 4, height - h + 3, p[4]);
            }
        }
    }

    private final float[] hov = new float[5];
    private int[] stars = new int[0];   // x, y, фаза
    private int[] hill = new int[0];    // высота колонки холма
    private int lastW = -1, lastH = -1;
    private final long t0 = System.currentTimeMillis();
    private int bx, by, bw, bh, gap;

    public UmearTitleScreen() {
        super(Text.literal("Umear"));
        randomBg = new java.util.Random().nextInt(7);
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean shouldPause() { return false; }

    private void layoutCache() {
        if (width == lastW && height == lastH) return;
        lastW = width; lastH = height;
        java.util.Random rnd = new java.util.Random(7);
        stars = new int[48 * 3];
        for (int i = 0; i < 48; i++) {
            stars[i * 3] = rnd.nextInt(Math.max(1, width));
            stars[i * 3 + 1] = rnd.nextInt(Math.max(1, height * 2 / 3));
            stars[i * 3 + 2] = rnd.nextInt(2000);
        }
        int cols = width / 4 + 1;
        hill = new int[cols];
        for (int i = 0; i < cols; i++)
            hill[i] = (int) (height * 0.12 + Math.sin(i * 0.11) * 6 + Math.sin(i * 0.037 + 1) * 10);
    }

    @Override
    public void renderBackground(DrawContext g, int mx, int my, float delta) { }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        Ui.frame();
        Ui.alpha = 1f;
        Ui.menuFont = false;
        layoutCache();
        long now = System.currentTimeMillis() - t0;

        drawBg(g, now);

        // чибик слева
        int S = Math.max(3, Math.min(6, height / 48));
        int sx = Math.max(10, width / 2 - 16 * S - width / 8), sy = height / 2 - 8 * S + (int) (Math.sin(now / 500.0) * 3);
        g.fill(sx + 2 * S, sy + 16 * S + 4, sx + 14 * S, sy + 16 * S + 8, 0x55000000);   // тень
        for (int i = 0; i < RUNS.length; i += 4)
            g.fill(sx + RUNS[i] * S, sy + RUNS[i + 1] * S, sx + (RUNS[i] + RUNS[i + 2]) * S, sy + (RUNS[i + 1] + 1) * S, RUNS[i + 3]);
        if (now % 3200 < 140) {   // моргание
            g.fill(sx + 4 * S, sy + 7 * S, sx + 6 * S, sy + 10 * S, SKIN);
            g.fill(sx + 10 * S, sy + 7 * S, sx + 12 * S, sy + 10 * S, SKIN);
            g.fill(sx + 4 * S, sy + 8 * S, sx + 6 * S, sy + 9 * S, INK);
            g.fill(sx + 10 * S, sy + 8 * S, sx + 12 * S, sy + 9 * S, INK);
        }

        // название
        int tx = sx + 8 * S - Ui.tw("UMEAR") * 3 / 2;
        int ty = Math.max(6, sy - 38);
        Ui.textS(g, "UMEAR", tx + 2, ty + 2, INK, 3f);
        Ui.textS(g, "UMEAR", tx, ty, 0xFFFF8FC7, 3f);
        Ui.ctext(g, "V I S U A L S", sx + 8 * S, ty + 28, 0xFFD9C8FF);

        // кнопки справа
        bw = Math.min(150, width / 2 - 20);
        bh = Math.max(18, Math.min(24, height / 12));
        gap = 6;
        int total = LABELS.length * bh + (LABELS.length - 1) * gap;
        bx = Math.max(width / 2 + 10, width - bw - width / 8);
        by = (height - total) / 2;
        for (int i = 0; i < LABELS.length; i++) {
            int y = by + i * (bh + gap);
            boolean in = mx >= bx && mx < bx + bw && my >= y && my < y + bh;
            hov[i] += ((in ? 1f : 0f) - hov[i]) * Math.min(1f, Ui.dt * 18f);
            button(g, bx + (int) (hov[i] * -3), y, bw, bh, LABELS[i], hov[i]);
        }

        Ui.text(g, "Umear Visuals", 6, height - 12, 0xFFD9C8FF, false);
        // переключатель фона
        String bn = BG_NAMES[curBg()];
        int cxm = width / 2, yb = height - 22;
        button(g, cxm - 70, yb, 18, 16, "<", 0f);
        button(g, cxm + 52, yb, 18, 16, ">", 0f);
        Ui.ctext(g, Modules.TITLE != null && Modules.TITLE.mode("bg") >= 7 ? "Случайный: " + bn : bn, cxm, yb + 4, 0xFFFFFFFF);
    }

    private void button(DrawContext g, int x, int y, int w, int h, String s, float hv) {
        g.fill(x + 2, y + 3, x + w + 2, y + h + 3, 0x66000000);
        g.fill(x, y, x + w, y + h, INK);
        g.fill(x + 2, y + 2, x + w - 2, y + h - 2, Ui.mix(0xFFFFE9F6, 0xFFFF8FC7, hv));
        g.fill(x + 2, y + 2, x + w - 2, y + 3, 0x88FFFFFF);
        g.fill(x + 2, y + h - 4, x + w - 2, y + h - 2, 0x33000000);
        Ui.text(g, s, x + (w - Ui.tw(s)) / 2, y + (h - 8) / 2, Ui.mix(INK, 0xFFFFFFFF, hv), false);
    }

    @Override
    public boolean mouseClicked(double dmx, double dmy, int btn) {
        int mx = (int) dmx, my = (int) dmy;
        int cxm = width / 2, yb = height - 22;
        if (my >= yb && my < yb + 16 && Modules.TITLE != null) {
            Setting bs = Modules.TITLE.get("bg");
            int n = bs.modes.length;
            if (mx >= cxm - 70 && mx < cxm - 52) { bs.mode = (bs.mode + n - 1) % n; Modules.save(); Fx.uiClick(); return true; }
            if (mx >= cxm + 52 && mx < cxm + 70) { bs.mode = (bs.mode + 1) % n; Modules.save(); Fx.uiClick(); return true; }
        }
        for (int i = 0; i < LABELS.length; i++) {
            int y = by + i * (bh + gap);
            if (mx >= bx - 3 && mx < bx + bw && my >= y && my < y + bh) {
                Fx.uiClick();
                switch (i) {
                    case 0 -> client.setScreen(new SelectWorldScreen(this));
                    case 1 -> client.setScreen(new MultiplayerScreen(this));
                    case 2 -> client.setScreen(new OptionsScreen(this, client.options));
                    case 3 -> client.setScreen(new UmearScreen());
                    default -> client.scheduleStop();
                }
                return true;
            }
        }
        return super.mouseClicked(dmx, dmy, btn);
    }
}
