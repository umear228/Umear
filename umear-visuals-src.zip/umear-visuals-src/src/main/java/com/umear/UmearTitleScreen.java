package com.umear;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;

/** Лёгкое пиксельное главное меню в стиле «чибик». Ничего не выделяется на кадр, всё считается один раз. */
public class UmearTitleScreen extends Screen {
    private static final String[] SPR = {
            "....OOOOOOOO....",
            "..OOHHHHHHHHOO..",
            ".OHHHHHHHHHHHHO.",
            "OHHHHHHHHHHHHHHO",
            "OHHHSSSSSSSSHHHO",
            "OHHSSSSSSSSSSHHO",
            "OHHSSSSSSSSSSHHO",
            "OHHSEESSSSEESHHO",
            "OHHSEWSSSSEWSHHO",
            "OHHSEESSSSEESHHO",
            "OHHSBBSSSSBBSHHO",
            ".OHSSSSMMSSSSHO.",
            ".OHHSSSSSSSSHHO.",
            "..OHHHSSSSHHHO..",
            "...OOOHHHHOOO...",
            ".....OOOOOO....."
    };
    private static final String[] LABELS = {"Одиночная игра", "Мультиплеер", "Настройки", "Umear Menu", "Выход"};
    private static final int INK = 0xFF2B2147, SKIN = 0xFFFFE0C8;

    // спрайт заранее разложен на горизонтальные отрезки одного цвета: {x, y, длина, цвет}
    private static final int[] RUNS;

    static {
        java.util.ArrayList<int[]> r = new java.util.ArrayList<>();
        for (int y = 0; y < SPR.length; y++) {
            int x = 0;
            while (x < 16) {
                char c = SPR[y].charAt(x);
                int x2 = x;
                while (x2 < 16 && SPR[y].charAt(x2) == c) x2++;
                int col = color(c);
                if (col != 0) r.add(new int[]{x, y, x2 - x, col});
                x = x2;
            }
        }
        RUNS = new int[r.size() * 4];
        for (int i = 0; i < r.size(); i++) System.arraycopy(r.get(i), 0, RUNS, i * 4, 4);
    }

    private static int color(char c) {
        return switch (c) {
            case 'O' -> INK;
            case 'H' -> 0xFFFF8FC7;
            case 'S' -> SKIN;
            case 'E' -> INK;
            case 'W' -> 0xFFFFFFFF;
            case 'B' -> 0xFFFF9FB0;
            case 'M' -> 0xFFC0506E;
            default -> 0;
        };
    }

    private final float[] hov = new float[5];
    private int[] stars = new int[0];   // x, y, фаза
    private int[] hill = new int[0];    // высота колонки холма
    private int lastW = -1, lastH = -1;
    private final long t0 = System.currentTimeMillis();
    private int bx, by, bw, bh, gap;

    public UmearTitleScreen() {
        super(Text.literal("Umear"));
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean shouldPause() { return false; }

    private void layoutCache() {
        if (width == lastW && height == lastH) return;
        lastW = width; lastH = height;
        java.util.Random rnd = new java.util.Random(7);
        stars = new int[48 * 3];
        for (int i = 0; i < 48; i++) {
            stars[i * 3] = rnd.nextInt(Math.max(1, width));
            stars[i * 3 + 1] = rnd.nextInt(Math.max(1, height * 2 / 3));
            stars[i * 3 + 2] = rnd.nextInt(2000);
        }
        int cols = width / 4 + 1;
        hill = new int[cols];
        for (int i = 0; i < cols; i++)
            hill[i] = (int) (height * 0.12 + Math.sin(i * 0.11) * 6 + Math.sin(i * 0.037 + 1) * 10);
    }

    @Override
    public void renderBackground(DrawContext g, int mx, int my, float delta) { }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        Ui.frame();
        Ui.alpha = 1f;
        Ui.menuFont = false;
        layoutCache();
        long now = System.currentTimeMillis() - t0;

        // небо: 24 полосы
        int bands = 24;
        for (int i = 0; i < bands; i++) {
            int y1 = height * i / bands, y2 = height * (i + 1) / bands;
            g.fill(0, y1, width, y2, Ui.mix(0xFF1B1530, 0xFF5A3F8C, i / (float) (bands - 1)));
        }
        // мерцающие звёзды 2x2
        for (int i = 0; i < stars.length; i += 3) {
            int ph = (int) ((now + stars[i + 2]) % 2000);
            int a = ph < 1000 ? 90 + ph * 165 / 1000 : 255 - (ph - 1000) * 165 / 1000;
            g.fill(stars[i], stars[i + 1], stars[i] + 2, stars[i + 1] + 2, Ui.withA(0xFFF0FA, a));
        }
        // холмы: колонки по 4 px
        for (int i = 0; i < hill.length; i++) {
            int h = hill[i];
            g.fill(i * 4, height - h, i * 4 + 4, height, 0xFF2A1F4A);
            g.fill(i * 4, height - h, i * 4 + 4, height - h + 3, 0xFF4B3A75);
        }

        // чибик слева
        int S = Math.max(3, Math.min(6, height / 48));
        int sx = Math.max(10, width / 2 - 16 * S - width / 8), sy = height / 2 - 8 * S + (int) (Math.sin(now / 500.0) * 3);
        g.fill(sx + 2 * S, sy + 16 * S + 4, sx + 14 * S, sy + 16 * S + 8, 0x55000000);   // тень
        for (int i = 0; i < RUNS.length; i += 4)
            g.fill(sx + RUNS[i] * S, sy + RUNS[i + 1] * S, sx + (RUNS[i] + RUNS[i + 2]) * S, sy + (RUNS[i + 1] + 1) * S, RUNS[i + 3]);
        if (now % 3200 < 140) {   // моргание
            g.fill(sx + 4 * S, sy + 7 * S, sx + 6 * S, sy + 10 * S, SKIN);
            g.fill(sx + 10 * S, sy + 7 * S, sx + 12 * S, sy + 10 * S, SKIN);
            g.fill(sx + 4 * S, sy + 8 * S, sx + 6 * S, sy + 9 * S, INK);
            g.fill(sx + 10 * S, sy + 8 * S, sx + 12 * S, sy + 9 * S, INK);
        }

        // название
        int tx = sx + 8 * S - Ui.tw("UMEAR") * 3 / 2;
        int ty = Math.max(6, sy - 38);
        Ui.textS(g, "UMEAR", tx + 2, ty + 2, INK, 3f);
        Ui.textS(g, "UMEAR", tx, ty, 0xFFFF8FC7, 3f);
        Ui.ctext(g, "V I S U A L S", sx + 8 * S, ty + 28, 0xFFD9C8FF);

        // кнопки справа
        bw = Math.min(150, width / 2 - 20);
        bh = Math.max(18, Math.min(24, height / 12));
        gap = 6;
        int total = LABELS.length * bh + (LABELS.length - 1) * gap;
        bx = Math.max(width / 2 + 10, width - bw - width / 8);
        by = (height - total) / 2;
        for (int i = 0; i < LABELS.length; i++) {
            int y = by + i * (bh + gap);
            boolean in = mx >= bx && mx < bx + bw && my >= y && my < y + bh;
            hov[i] += ((in ? 1f : 0f) - hov[i]) * Math.min(1f, Ui.dt * 18f);
            button(g, bx + (int) (hov[i] * -3), y, bw, bh, LABELS[i], hov[i]);
        }

        Ui.text(g, "Umear Visuals 1.1.0", 6, height - 12, 0xFFD9C8FF, false);
    }

    private void button(DrawContext g, int x, int y, int w, int h, String s, float hv) {
        g.fill(x + 2, y + 3, x + w + 2, y + h + 3, 0x66000000);
        g.fill(x, y, x + w, y + h, INK);
        g.fill(x + 2, y + 2, x + w - 2, y + h - 2, Ui.mix(0xFFFFE9F6, 0xFFFF8FC7, hv));
        g.fill(x + 2, y + 2, x + w - 2, y + 3, 0x88FFFFFF);
        g.fill(x + 2, y + h - 4, x + w - 2, y + h - 2, 0x33000000);
        Ui.text(g, s, x + (w - Ui.tw(s)) / 2, y + (h - 8) / 2, Ui.mix(INK, 0xFFFFFFFF, hv), false);
    }

    @Override
    public boolean mouseClicked(double dmx, double dmy, int btn) {
        int mx = (int) dmx, my = (int) dmy;
        for (int i = 0; i < LABELS.length; i++) {
            int y = by + i * (bh + gap);
            if (mx >= bx - 3 && mx < bx + bw && my >= y && my < y + bh) {
                Fx.uiClick();
                switch (i) {
                    case 0 -> client.setScreen(new SelectWorldScreen(this));
                    case 1 -> client.setScreen(new MultiplayerScreen(this));
                    case 2 -> client.setScreen(new OptionsScreen(this, client.options));
                    case 3 -> client.setScreen(new UmearScreen());
                    default -> client.scheduleStop();
                }
                return true;
            }
        }
        return super.mouseClicked(dmx, dmy, btn);
    }
}
