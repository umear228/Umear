package com.umear.mixin;

import com.umear.Modules;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientWorld.Properties.class)
public class ClientWorldPropertiesMixin {
    @Inject(method = "getTimeOfDay", at = @At("HEAD"), cancellable = true)
    private void umear$time(CallbackInfoReturnable<Long> cir) {
        if (Modules.TIME != null && Modules.TIME.enabled) cir.setReturnValue(Modules.timeValue());
    }
}
