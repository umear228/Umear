package com.umear.mixin;

import com.umear.Fx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public class EntityMixin {
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void umear$look(double dx, double dy, CallbackInfo ci) {
        if (Fx.freelookActive() && (Object) this == MinecraftClient.getInstance().player) {
            Fx.freelookMove(dx, dy);
            ci.cancel();
        }
    }
}
