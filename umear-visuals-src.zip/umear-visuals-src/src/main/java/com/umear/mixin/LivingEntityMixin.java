package com.umear.mixin;

import com.umear.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public class LivingEntityMixin {
    @Inject(method = "getHandSwingDuration", at = @At("RETURN"), cancellable = true)
    private void umear$swingDur(CallbackInfoReturnable<Integer> cir) {
        if (Modules.SWING != null && Modules.SWING.enabled
                && (Object) this == MinecraftClient.getInstance().player)
            cir.setReturnValue((int) Modules.SWING.num("dur"));
    }
}
