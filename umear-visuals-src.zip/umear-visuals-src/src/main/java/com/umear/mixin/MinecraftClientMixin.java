package com.umear.mixin;

import com.umear.Modules;
import com.umear.UmearTitleScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen umear$title(Screen s) {
        if (s instanceof TitleScreen && Modules.TITLE != null && Modules.TITLE.enabled) return new UmearTitleScreen();
        return s;
    }
}
