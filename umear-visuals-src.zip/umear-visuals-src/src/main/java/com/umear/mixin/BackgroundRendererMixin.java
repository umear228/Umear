package com.umear.mixin;

import com.umear.Module;
import com.umear.Modules;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Fog;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BackgroundRenderer.class)
public class BackgroundRendererMixin {
    @Inject(method = "applyFog", at = @At("RETURN"), cancellable = true)
    private static void umear$fog(Camera camera, BackgroundRenderer.FogType fogType, Vector4f color,
                                  float viewDistance, boolean thickFog, float tickProgress,
                                  CallbackInfoReturnable<Fog> cir) {
        Module f = Modules.FOG;
        if (f == null || !f.enabled || fogType != BackgroundRenderer.FogType.FOG_TERRAIN) return;
        Fog o = cir.getReturnValue();
        float start, end;
        switch (f.mode("mode")) {
            case 1 -> { start = 0f; end = Math.max(4f, (float) f.num("end") * 0.35f); }
            case 2 -> { start = 100000f; end = 100001f; }
            default -> {
                start = (float) f.num("start");
                end = Math.max(start + 1f, (float) f.num("end"));
            }
        }
        float r = o.red(), g = o.green(), b = o.blue();
        if (f.bool("cc")) {
            int c = f.get("col").color;
            r = ((c >> 16) & 255) / 255f; g = ((c >> 8) & 255) / 255f; b = (c & 255) / 255f;
        }
        cir.setReturnValue(new Fog(start, end, o.shape(), r, g, b, o.alpha()));
    }
}
