package com.umear.mixin;

import com.umear.Fx;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(Camera.class)
public class CameraMixin {
    @ModifyVariable(method = "setRotation", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private float umear$yaw(float yaw) {
        return Fx.freelookActive() ? Fx.flYaw : yaw;
    }

    @ModifyVariable(method = "setRotation", at = @At("HEAD"), argsOnly = true, ordinal = 1)
    private float umear$pitch(float pitch) {
        return Fx.freelookActive() ? Fx.flPitch : pitch;
    }
}
