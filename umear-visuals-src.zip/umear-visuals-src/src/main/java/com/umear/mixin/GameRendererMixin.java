package com.umear.mixin;

import com.umear.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "getBasicProjectionMatrix", at = @At("RETURN"), cancellable = true)
    private void umear$aspect(float fovDegrees, CallbackInfoReturnable<Matrix4f> cir) {
        if (Modules.ASPECT == null || !Modules.ASPECT.enabled) return;
        var w = MinecraftClient.getInstance().getWindow();
        if (w.getFramebufferHeight() == 0) return;
        float cur = (float) w.getFramebufferWidth() / w.getFramebufferHeight();
        float target = Modules.aspectValue();
        Matrix4f m = cir.getReturnValue();
        m.m00(m.m00() * cur / target);
        cir.setReturnValue(m);
    }
}
