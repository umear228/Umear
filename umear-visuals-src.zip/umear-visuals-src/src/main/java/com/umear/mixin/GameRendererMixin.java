package com.umear.mixin;

import com.umear.Fx;
import com.umear.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "getBasicProjectionMatrix", at = @At("RETURN"), cancellable = true)
    private void umear$projection(float fovDegrees, CallbackInfoReturnable<Matrix4f> cir) {
        Matrix4f m = cir.getReturnValue();
        boolean changed = false;
        if (Modules.ASPECT != null && Modules.ASPECT.enabled) {
            var w = MinecraftClient.getInstance().getWindow();
            if (w.getFramebufferHeight() != 0) {
                float cur = (float) w.getFramebufferWidth() / w.getFramebufferHeight();
                m.m00(m.m00() * cur / Modules.aspectValue());
                changed = true;
            }
        }
        float z = Fx.zoomFactor();
        if (z > 1.001f) {
            m.m00(m.m00() * z);
            m.m11(m.m11() * z);
            changed = true;
        }
        if (changed) cir.setReturnValue(m);
    }
}
