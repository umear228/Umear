package com.umear.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.umear.Modules;
import com.umear.ViewModel;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    @WrapMethod(method = "renderFirstPersonItem")
    private void umear$wrap(AbstractClientPlayerEntity player, float tickProgress, float pitch, Hand hand,
                            float swingProgress, ItemStack item, float equipProgress, MatrixStack matrices,
                            VertexConsumerProvider vertexConsumers, int light, Operation<Void> original) {
        float sp = swingProgress;
        if (Modules.VIEW != null && (Modules.VIEW.enabled || Modules.SWING.enabled))
            sp = ViewModel.apply(matrices, hand, player, swingProgress);
        original.call(player, tickProgress, pitch, hand, sp, item, equipProgress, matrices, vertexConsumers, light);
    }
}
