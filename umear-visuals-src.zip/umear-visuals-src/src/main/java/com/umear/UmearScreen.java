package com.umear;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

public class UmearScreen extends Screen {
    private static final int SW = 84, TOP = 30, CARD = 24, PAD = 8;
    private static final Identifier LOGO = Identifier.of("umear", "textures/gui/logo.png");

    private static final int H_TAB = 0, H_EDIT = 1, H_CARD = 2, H_SWITCH = 3, H_SLIDER = 4,
            H_BOOL = 5, H_MODE = 6, H_COLOR = 7, H_STRIP = 8, H_BTN = 9;

    private static final class Hit {
        int k, x, y, w, h, a;
        Module m;
        Setting s;
    }

    private final Hit[] hits = new Hit[320];
    private int nh;

    private int cat, px, py, pw, ph, lx, ly, lw, lh, contentH;
    private float scroll, scrollT, t, bgE;
    private boolean closing, pendingClose;
    private Setting drag;
    private int dragX, dragW, dragAxis;
    private final float[] hsv = new float[3];

    public UmearScreen() {
        super(Text.literal("Umear Visuals"));
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void close() {
        if (closing) return;
        if (Modules.ANIM.enabled && Modules.ANIM.bool("close")) closing = true;
        else client.setScreen(null);
    }

    @Override
    public void removed() { Modules.save(); }

    @Override
    public void tick() {
        if (pendingClose) client.setScreen(null);
    }

    // ================= фон: blur + затемнение =================
    @Override
    public void renderBackground(DrawContext g, int mx, int my, float delta) {
        Module b = Modules.BLUR;
        float dim = b.enabled ? (float) b.num("dim") / 100f : 0.3f;
        if (b.enabled && client.world != null && b.num("str") >= 1 && bgE > 0.05f) {
            try {
                var opt = client.options.getMenuBackgroundBlurriness();
                int old = opt.getValue();
                opt.setValue((int) Math.round(b.num("str") * bgE));
                client.gameRenderer.renderBlur();
                opt.setValue(old);
            } catch (Throwable ignored) { }
        }
        int al = (int) (dim * 255 * bgE);
        if (al > 0) g.fill(0, 0, width, height, al << 24);
    }

    // ================= рендер =================
    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        Ui.frame();
        Theme.update();
        Ui.menuFont = true;

        boolean anim = Modules.ANIM.enabled;
        float spd = anim ? (float) Modules.ANIM.num("spd") * 3.2f : 1000f;
        t = MathHelper.clamp(t + (closing ? -1f : 1f) * Ui.dt * spd, 0f, 1f);
        if (closing && t <= 0f) { pendingClose = true; return; }
        float e = Ui.ease(t);
        bgE = e;
        renderBackground(g, mx, my, delta);

        pw = Math.min(360, width - 8);
        ph = Math.min(236, height - 8);
        px = (width - pw) / 2;
        py = (height - ph) / 2;

        float s = 1f, ty = 0f, al = e;
        if (anim) {
            switch (Modules.ANIM.mode("mode")) {
                case 1 -> s = 0.88f + 0.12f * e;
                case 2 -> ty = (1f - e) * 26f;
                case 3 -> { s = Math.max(0.01f, Ui.back(t)); al = Math.min(1f, t * 3f); }
                default -> { }
            }
        } else al = 1f;
        Ui.alpha = al;

        MatrixStack ms = g.getMatrices();
        float cx = px + pw / 2f, cy0 = py + ph / 2f;
        ms.push();
        ms.translate(cx, cy0 + ty, 0);
        ms.scale(s, s, 1f);
        ms.translate(-cx, -cy0, 0);

        nh = 0;
        int r = Theme.round + 2;
        Ui.round(g, px, py, pw, ph, r, Theme.panel);
        Ui.round(g, px, py, SW, ph, r, Theme.side);
        Ui.fill(g, px + SW - r, py, px + SW, py + ph, Theme.side);

        if (Theme.neon) {
            int nc = Ui.withA(Theme.accent & 0xFFFFFF, 210), ng = Ui.withA(Theme.accent & 0xFFFFFF, 60);
            Ui.fill(g, px + r, py, px + pw - r, py + 1, nc);
            Ui.fill(g, px + r, py + ph - 1, px + pw - r, py + ph, nc);
            Ui.fill(g, px, py + r, px + 1, py + ph - r, nc);
            Ui.fill(g, px + pw - 1, py + r, px + pw, py + ph - r, nc);
            Ui.fill(g, px + r, py - 1, px + pw - r, py, ng);
            Ui.fill(g, px + r, py + ph, px + pw - r, py + ph + 1, ng);
            Ui.fill(g, px - 1, py + r, px, py + ph - r, ng);
            Ui.fill(g, px + pw, py + r, px + pw + 1, py + ph - r, ng);
        }
        drawSidebar(g, mx, my);
        drawList(g, mx, my);

        ms.pop();
        Ui.alpha = 1f;
    }

    private Hit hit(int k, int x, int y, int w, int h, Module m, Setting s, int a) {
        Hit o = hits[nh];
        if (o == null) o = hits[nh] = new Hit();
        nh++;
        o.k = k; o.x = x; o.y = y; o.w = w; o.h = h; o.m = m; o.s = s; o.a = a;
        return o;
    }

    private static boolean in(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && my >= y && mx < x + w && my < y + h;
    }

    private void drawSidebar(DrawContext g, int mx, int my) {
        Ui.tex(g, LOGO, px + 18, py + 6, 48, 32);
        for (int i = 0; i < Modules.CATS.length; i++) {
            int x = px + 8, y = py + 46 + i * 22, w = SW - 16;
            boolean sel = i == cat, hov = in(mx, my, x, y, w, 18);
            if (sel) Ui.round(g, x, y, w, 18, Theme.round, Ui.withA(Theme.accent, 70));
            else if (hov) Ui.round(g, x, y, w, 18, Theme.round, Theme.card);
            if (sel) Ui.fill(g, x, y + 4, x + 2, y + 14, Theme.accent);
            Ui.text(g, Modules.CATS[i], x + 9, y + 5, sel ? Theme.text : Theme.sub);
            hit(H_TAB, x, y, w, 18, null, null, i);
        }
        int x = px + 8, y = py + ph - 26, w = SW - 16;
        boolean hov = in(mx, my, x, y, w, 18);
        Ui.round(g, x, y, w, 18, Theme.round, hov ? Theme.cardHi : Theme.card);
        Ui.ctext(g, "HUD Editor", x + w / 2, y + 5, Theme.text);
        hit(H_EDIT, x, y, w, 18, null, null, 0);
    }

    private int bodyHeight(Module m) {
        int h = 4;
        for (Setting s : m.settings) h += setH(s);
        return h;
    }

    private static int setH(Setting s) {
        return switch (s.type) {
            case SLIDER -> 26;
            case COLOR -> s.picking ? 56 : 18;
            case BUTTON -> 22;
            default -> 18;
        };
    }

    private void drawList(DrawContext g, int mx, int my) {
        Ui.text(g, Modules.CATS[cat], px + SW + PAD, py + 10, Theme.text);
        String hint = "Right Shift — закрыть";
        Ui.textS(g, hint, px + pw - PAD - (int) (Ui.tw(hint) * 0.8f), py + 11, Theme.sub, 0.8f);

        lx = px + SW + PAD; ly = py + TOP; lw = pw - SW - PAD * 2; lh = ph - TOP - PAD;
        scroll += (scrollT - scroll) * Math.min(1f, Ui.dt * 14f);
        g.enableScissor(lx - 2, ly, lx + lw + 2, ly + lh);

        int y = ly - Math.round(scroll);
        int start = y;
        boolean inList = my >= ly && my < ly + lh;
        for (Module m : Modules.ALL) {
            if (!m.cat.equals(Modules.CATS[cat])) continue;
            m.tog += ((m.enabled ? 1f : 0f) - m.tog) * Math.min(1f, Ui.dt * 16f);
            m.exp += ((m.open ? 1f : 0f) - m.exp) * Math.min(1f, Ui.dt * 14f);
            int body = m.exp > 0.003f ? Math.round(bodyHeight(m) * Ui.ease(m.exp)) : 0;
            int ch = CARD + body;
            if (y + ch >= ly && y <= ly + lh) drawCard(g, m, y, ch, mx, my, inList);
            y += ch + 4;
        }
        contentH = y - start;
        float maxS = Math.max(0, contentH - lh);
        scrollT = MathHelper.clamp(scrollT, 0, maxS);
        g.disableScissor();
    }

    private void drawCard(DrawContext g, Module m, int y, int ch, int mx, int my, boolean inList) {
        boolean hov = inList && in(mx, my, lx, y, lw, CARD);
        Ui.round(g, lx, y, lw, ch, Theme.round, hov ? Theme.cardHi : Theme.card);
        Ui.text(g, m.name, lx + 8, y + 4, Theme.mix2(m.tog));
        Ui.textS(g, m.desc, lx + 8, y + 14, Theme.sub, 0.75f);
        if (m.settings.length > 0) Ui.text(g, m.open ? "-" : "+", lx + lw - 46, y + 8, Theme.sub);
        // переключатель
        int sx = lx + lw - 32, sy = y + 6;
        Ui.round(g, sx, sy, 24, 12, 6, Ui.mix(Theme.track, Theme.accent, m.tog));
        Ui.round(g, sx + 2 + Math.round(m.tog * 12), sy + 2, 8, 8, 4, 0xFFFFFFFF);
        hit(H_CARD, lx, y, lw - 36, CARD, m, null, 0);
        hit(H_SWITCH, sx - 4, y, 36, CARD, m, null, 0);

        if (m.exp > 0.003f) {
            g.enableScissor(lx, y + CARD, lx + lw, y + ch);
            int sy2 = y + CARD + 2;
            for (Setting s : m.settings) sy2 += drawSetting(g, m, s, lx + 8, sy2, lw - 16, mx, my);
            g.disableScissor();
        }
    }

    private int drawSetting(DrawContext g, Module m, Setting s, int x, int y, int w, int mx, int my) {
        switch (s.type) {
            case BOOL -> {
                Ui.text(g, s.label, x, y + 5, Theme.text);
                int sx = x + w - 20;
                Ui.round(g, sx, y + 4, 20, 10, 5, s.bool ? Theme.accent : Theme.track);
                Ui.round(g, sx + (s.bool ? 11 : 2), y + 6, 7, 6, 3, 0xFFFFFFFF);
                hit(H_BOOL, x, y, w, 18, m, s, 0);
            }
            case MODE -> {
                Ui.text(g, s.label, x, y + 5, Theme.text);
                String v = "< " + s.modes[s.mode] + " >";
                Ui.text(g, v, x + w - Ui.tw(v), y + 5, Theme.accent);
                hit(H_MODE, x, y, w, 18, m, s, 0);
            }
            case SLIDER -> {
                Ui.text(g, s.label, x, y + 3, Theme.text);
                String v = s.shown();
                Ui.text(g, v, x + w - Ui.tw(v), y + 3, Theme.sub);
                Ui.round(g, x, y + 16, w, 4, 2, Theme.track);
                int fw = Math.max(2, (int) (w * s.frac()));
                Ui.round(g, x, y + 16, fw, 4, 2, Theme.accent);
                Ui.round(g, x + fw - 3, y + 14, 6, 8, 3, 0xFFFFFFFF);
                hit(H_SLIDER, x, y, w, 26, m, s, 0);
            }
            case COLOR -> {
                Ui.text(g, s.label, x, y + 5, Theme.text);
                Ui.round(g, x + w - 24, y + 3, 24, 12, 3, 0xFF000000 | s.color);
                hit(H_COLOR, x, y, w, 18, m, s, 0);
                if (s.picking) {
                    Ui.rgb2hsv(s.color, hsv);
                    if (drag == s) { hsv[0] = dh[0]; hsv[1] = dh[1]; hsv[2] = dh[2]; }
                    for (int a = 0; a < 3; a++) {
                        int yy = y + 20 + a * 12;
                        strip(g, x, yy, w, a);
                        int kx = x + (int) (w * hsv[a]);
                        Ui.round(g, kx - 2, yy - 1, 4, 10, 2, 0xFFFFFFFF);
                        hit(H_STRIP, x, yy - 1, w, 10, m, s, a);
                    }
                }
            }
            case BUTTON -> {
                boolean hov = in(mx, my, x, y, w, 18);
                Ui.round(g, x, y + 1, w, 18, Theme.round, hov ? Theme.accent : Ui.withA(Theme.accent, 90));
                Ui.ctext(g, s.label, x + w / 2, y + 6, 0xFFFFFFFF);
                hit(H_BTN, x, y, w, 20, m, s, 0);
            }
        }
        return setH(s);
    }

    private final float[] dh = new float[3];

    private void strip(DrawContext g, int x, int y, int w, int axis) {
        int steps = 32;
        for (int i = 0; i < steps; i++) {
            float f = (i + 0.5f) / steps;
            int c = switch (axis) {
                case 0 -> Ui.hsv(f, 1f, 1f);
                case 1 -> Ui.hsv(hsv[0], f, hsv[2]);
                default -> Ui.hsv(hsv[0], hsv[1], f);
            };
            int x1 = x + i * w / steps, x2 = x + (i + 1) * w / steps;
            Ui.fill(g, x1, y, x2, y + 8, c);
        }
    }

    // ================= ввод =================
    @Override
    public boolean mouseClicked(double dmx, double dmy, int btn) {
        if (closing) return true;
        int mx = (int) dmx, my = (int) dmy;
        boolean inList = my >= ly && my < ly + lh && mx >= lx - 2 && mx < lx + lw + 2;
        for (int i = nh - 1; i >= 0; i--) {
            Hit h = hits[i];
            if (!in(mx, my, h.x, h.y, h.w, h.h)) continue;
            if (h.k >= H_CARD && !inList) continue;
            switch (h.k) {
                case H_TAB -> { cat = h.a; scroll = scrollT = 0; }
                case H_EDIT -> client.setScreen(new HudEditorScreen(this));
                case H_CARD -> { if (h.m.settings.length > 0) h.m.open = !h.m.open; }
                case H_SWITCH -> h.m.toggle();
                case H_BOOL -> h.s.bool = !h.s.bool;
                case H_MODE -> {
                    int n = h.s.modes.length;
                    h.s.mode = (h.s.mode + (btn == 1 ? -1 : 1) + n) % n;
                }
                case H_SLIDER -> { drag = h.s; dragAxis = -1; dragX = h.x; dragW = h.w; h.s.setFromFrac((mx - h.x) / (double) h.w); }
                case H_COLOR -> h.s.picking = !h.s.picking;
                case H_STRIP -> {
                    drag = h.s; dragAxis = h.a; dragX = h.x; dragW = h.w;
                    Ui.rgb2hsv(h.s.color, dh);
                    applyStrip(mx);
                }
                case H_BTN -> h.s.run.run();
                default -> { }
            }
            Fx.uiClick();
            return true;
        }
        return super.mouseClicked(dmx, dmy, btn);
    }

    private void applyStrip(int mx) {
        float f = MathHelper.clamp((mx - dragX) / (float) dragW, 0f, 1f);
        dh[dragAxis] = f;
        drag.color = Ui.hsv(dh[0], dh[1], dh[2]) & 0xFFFFFF;
    }

    @Override
    public boolean mouseDragged(double dmx, double dmy, int btn, double dx, double dy) {
        if (drag != null) {
            if (dragAxis < 0) drag.setFromFrac((dmx - dragX) / dragW);
            else applyStrip((int) dmx);
            return true;
        }
        return super.mouseDragged(dmx, dmy, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double dmx, double dmy, int btn) {
        drag = null;
        return super.mouseReleased(dmx, dmy, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hor, double ver) {
        scrollT = MathHelper.clamp(scrollT - (float) ver * 22f, 0, Math.max(0, contentH - lh));
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (UmearClient.OPEN.matchesKey(key, scan)) { close(); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
