package com.umear;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class HudEditorScreen extends Screen {
    private final Screen parent;
    private String drag;
    private double offX, offY;
    private boolean snapX, snapY;

    public HudEditorScreen(Screen parent) {
        super(Text.literal("HUD Editor"));
        this.parent = parent;
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void close() { client.setScreen(parent); }

    @Override
    public void removed() { Modules.save(); }

    @Override
    public void renderBackground(DrawContext g, int mx, int my, float delta) {
        g.fill(0, 0, width, height, 0x66000000);
    }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        Ui.frame();
        Theme.update();
        Ui.alpha = 1f;
        Ui.menuFont = false;
        renderBackground(g, mx, my, delta);

        // направляющие
        if (snapX) g.fill(width / 2, 0, width / 2 + 1, height, Ui.withA(Theme.accent, 160));
        if (snapY) g.fill(0, height / 2, width, height / 2 + 1, Ui.withA(Theme.accent, 160));

        for (int i = 0; i < Hud.IDS.length; i++) {
            String id = Hud.IDS[i];
            Hud.draw(g, id, true);
            int[] s = Hud.size(id);
            int x = Hud.px(id, width, s[0]), y = Hud.py(id, height, s[1]);
            boolean hov = mx >= x && my >= y && mx < x + s[0] && my < y + s[1];
            int c = id.equals(drag) ? Theme.accent : Ui.withA(Theme.accent, hov ? 220 : 110);
            g.fill(x - 1, y - 1, x + s[0] + 1, y, c);
            g.fill(x - 1, y + s[1], x + s[0] + 1, y + s[1] + 1, c);
            g.fill(x - 1, y, x, y + s[1], c);
            g.fill(x + s[0], y, x + s[0] + 1, y + s[1], c);
            Ui.textS(g, Hud.TITLES[i] + " x" + String.format(java.util.Locale.ROOT, "%.1f", Hud.pos(id)[2]),
                    x, y - 9, Theme.text, 0.8f);
        }

        // кнопки
        int bw = 70, by = height - 26, cx = width / 2;
        button(g, cx - bw - 4, by, bw, "Сброс", mx, my);
        button(g, cx + 4, by, bw, "Готово", mx, my);
        Ui.ctext(g, "Тяни элементы. Колёсико — размер", cx, by - 14, Theme.text);
    }

    private void button(DrawContext g, int x, int y, int w, String s, int mx, int my) {
        boolean hov = mx >= x && my >= y && mx < x + w && my < y + 18;
        Ui.round(g, x, y, w, 18, Theme.round, hov ? Theme.accent : Ui.withA(Theme.accent, 140));
        Ui.ctext(g, s, x + w / 2, y + 5, 0xFFFFFFFF);
    }

    @Override
    public boolean mouseClicked(double dmx, double dmy, int btn) {
        int mx = (int) dmx, my = (int) dmy;
        int bw = 70, by = height - 26, cx = width / 2;
        if (my >= by && my < by + 18) {
            if (mx >= cx - bw - 4 && mx < cx - 4) { Hud.reset(); Fx.uiClick(); return true; }
            if (mx >= cx + 4 && mx < cx + 4 + bw) { Fx.uiClick(); close(); return true; }
        }
        for (int i = Hud.IDS.length - 1; i >= 0; i--) {
            String id = Hud.IDS[i];
            int[] s = Hud.size(id);
            int x = Hud.px(id, width, s[0]), y = Hud.py(id, height, s[1]);
            if (mx >= x && my >= y && mx < x + s[0] && my < y + s[1]) {
                drag = id; offX = mx - x; offY = my - y;
                return true;
            }
        }
        return super.mouseClicked(dmx, dmy, btn);
    }

    @Override
    public boolean mouseDragged(double dmx, double dmy, int btn, double dx, double dy) {
        if (drag == null) return super.mouseDragged(dmx, dmy, btn, dx, dy);
        int[] s = Hud.size(drag);
        double freeW = Math.max(1, width - s[0] - 8), freeH = Math.max(1, height - s[1] - 8);
        double x = dmx - offX - 4, y = dmy - offY - 4;
        boolean snap = Modules.HUDEDIT.bool("snap");
        snapX = snapY = false;
        if (snap) {
            double fx = x / freeW, fy = y / freeH;
            if (Math.abs(fx - 0.5) * freeW < 5) { x = freeW * 0.5; snapX = true; }
            else if (Math.abs(fx) * freeW < 5) x = 0;
            else if (Math.abs(fx - 1) * freeW < 5) x = freeW;
            if (Math.abs(fy - 0.5) * freeH < 5) { y = freeH * 0.5; snapY = true; }
            else if (Math.abs(fy) * freeH < 5) y = 0;
            else if (Math.abs(fy - 1) * freeH < 5) y = freeH;
        }
        float[] p = Hud.pos(drag);
        p[0] = (float) Math.max(0, Math.min(1, x / freeW));
        p[1] = (float) Math.max(0, Math.min(1, y / freeH));
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        drag = null; snapX = snapY = false;
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double dmx, double dmy, double hor, double ver) {
        for (String id : Hud.IDS) {
            int[] s = Hud.size(id);
            int x = Hud.px(id, width, s[0]), y = Hud.py(id, height, s[1]);
            if (dmx >= x && dmy >= y && dmx < x + s[0] && dmy < y + s[1]) {
                float[] p = Hud.pos(id);
                p[2] = Math.max(0.5f, Math.min(2.5f, p[2] + (float) ver * 0.1f));
                return true;
            }
        }
        return false;
    }
}
