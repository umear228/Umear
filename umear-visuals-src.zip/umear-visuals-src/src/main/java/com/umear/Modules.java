package com.umear;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

import static com.umear.Setting.*;

public final class Modules {
    public static final String[] CATS = {"Combat", "Visuals", "Misc", "Shortcut"};
    public static final List<Module> ALL = new ArrayList<>();
    public static final String[] SND = {"Click", "Pop", "Bell", "Ding"};

    public static Module INFO, HITSOUND, HITCOLOR, CROSS, TARGETHUD, DMG, BURST,
            MARKER, VIEW, SWING, SLASH, FOG, ASPECT, TRAILS, PARTICLES, GLOW, HAT, TIME,
            CSOUND, FONT, BLUR, ANIM, HUDEDIT, NOTIF, THEME, CLOCK, KEYS, SPRINT, ZOOM, FREELOOK, TITLE, BLOCKOV, FULLBRIGHT;

    public static long ticks;
    public static int combo;
    public static long lastHit;
    public static double reach;
    private static final ArrayDeque<Long> CLICKS = new ArrayDeque<>();
    private static final double[] RATIOS = {0, 4.0 / 3, 16.0 / 9, 21.0 / 9, 1.0, 5.0 / 4};

    private static Module add(Module m) { ALL.add(m); return m; }

    public static void init() {
        // ===== Combat =====
        INFO = add(new Module("Combat", "Info HUD", "FPS, CPS, Reach и Combo в одном блоке", true,
                bool("fps", "FPS", true), bool("cps", "CPS", true),
                bool("reach", "Reach", true), bool("combo", "Combo", true),
                mode("layout", "Расположение", 0, "Колонка", "Строка"),
                slider("bgop", "Прозрачность фона", 0, 100, 55, 5, "%"),
                color("col", "Цвет значений", 0xFFFFFF),
                bool("rst", "Сброс комбо при уроне", true),
                slider("to", "Сброс комбо через", 0.5, 6, 2.5, 0.5, " с")));
        HITSOUND = add(new Module("Combat", "Hit Sound", "Звук при попадании", false,
                mode("snd", "Звук", 0, SND),
                slider("vol", "Громкость", 0, 100, 70, 5, "%"),
                slider("pitch", "Тон", 50, 200, 100, 5, "%")));
        HITCOLOR = add(new Module("Combat", "Hit Color", "Цвет вспышки при попадании", false,
                color("col", "Цвет", 0xFF2D2D),
                slider("op", "Прозрачность", 10, 100, 70, 5, "%")));
        CROSS = add(new Module("Combat", "Dynamic Crosshair", "Прицел меняется при наведении на врага", false,
                mode("style", "Форма", 0, "Плюс", "Точка", "Круг", "X", "Скобки"),
                mode("who", "Цели", 0, "Все", "Игроки", "Мобы"),
                slider("size", "Размер", 2, 14, 5, 1, " px"),
                slider("gap", "Зазор", 0, 10, 2, 1, " px"),
                slider("thick", "Толщина", 1, 3, 1, 1, " px"),
                color("col", "Цвет", 0xFFFFFF),
                color("colt", "Цвет на цели", 0xFF3B3B),
                slider("grow", "Рост на цели", 0, 100, 40, 5, "%"),
                bool("outline", "Обводка", true)));

        TARGETHUD = add(new Module("Combat", "Target HUD", "Плашка с именем и HP цели", false,
                bool("theme", "Цвет темы", true),
                color("col", "Цвет полосы", 0x3DDC84),
                slider("bgop", "Прозрачность фона", 0, 100, 70, 5, "%")));
        DMG = add(new Module("Combat", "Damage Numbers", "Цифры урона над целью", false,
                slider("size", "Размер", 0.6, 2.5, 1.2, 0.1, "x"),
                slider("life", "Время", 0.5, 2.5, 1.1, 0.1, " с"),
                color("col", "Цвет", 0xFFFFFF),
                color("colc", "Цвет крита", 0xFF4D5E),
                slider("crit", "Крит от", 3, 20, 7, 1, "")));
        BURST = add(new Module("Combat", "Hit Burst", "Эффект при попадании", false,
                mode("type", "Эффект", 0, "Искры", "Звёзды", "Кольцо"),
                color("col", "Цвет 1", 0xFFB84D),
                color("col2", "Цвет 2", 0xFF4D5E),
                slider("n", "Количество", 3, 40, 14, 1, ""),
                slider("size", "Размер", 0.05, 0.5, 0.15, 0.01, "")));

        // ===== Visuals =====
        MARKER = add(new Module("Visuals", "Target Marker", "Светящийся маркер на цели", false,
                mode("who", "Цели", 0, "Все", "Игроки", "Мобы"),
                mode("shape", "Форма", 0, "Скобки", "Двойное кольцо", "Квадрат", "Ромб", "Звезда", "Прицел",
                        "Треугольники", "Шестиугольник", "Сердце", "Волна", "Кристаллы", "Орбита"),
                mode("pos", "Позиция", 0, "Грудь", "Голова", "Ноги", "Центр"),
                mode("cm", "Цвет", 0, "Тема", "Статичный", "Радуга", "По HP"),
                color("col", "Цвет", 0xA86BFF),
                slider("size", "Размер", 0.3, 2, 0.9, 0.1, ""),
                slider("op", "Прозрачность", 10, 100, 90, 5, "%"),
                slider("inner", "Прозрачность внутри", 0, 50, 0, 5, "%"),
                slider("thick", "Толщина контура", 0.5, 3, 1, 0.1, "x"),
                slider("lines", "Количество контуров", 1, 3, 1, 1, ""),
                slider("glow", "Свечение", 0, 100, 60, 5, "%"),
                slider("spd", "Скорость", 0, 4, 1, 0.2, "x"),
                bool("rot", "Вращение", true),
                bool("pulse", "Пульсация", true),
                bool("breath", "Дыхание", false),
                bool("flick", "Мерцание", false),
                bool("hit", "Реакция на удар", true),
                bool("scale", "Размер от дистанции", false),
                bool("crystals", "Кристаллы вокруг", false),
                slider("cn", "Кристаллов", 2, 8, 4, 1, ""),
                slider("cs", "Размер кристаллов", 0.05, 0.4, 0.15, 0.01, "")));
        VIEW = add(new Module("Visuals", "View Model", "Редактор положения руки", false,
                mode("hand", "Рука", 0, "Обе", "Правая", "Левая"),
                slider("x", "X", -1, 1, 0, 0.05, ""),
                slider("y", "Y", -1, 1, 0, 0.05, ""),
                slider("z", "Z", -1, 1, 0, 0.05, ""),
                slider("rx", "Поворот X", -180, 180, 0, 5, "°"),
                slider("ry", "Поворот Y", -180, 180, 0, 5, "°"),
                slider("rz", "Поворот Z", -180, 180, 0, 5, "°"),
                slider("sc", "Размер", 0.3, 1.5, 1, 0.05, "x"),
                bool("flat", "Меч горизонтально", false)));
        SWING = add(new Module("Visuals", "Swing Animation", "Анимация руки: старые + как в Plintus", false,
                mode("mode", "Анимация", 1, "Vanilla", "Slash", "Smooth", "Block", "Poke", "Spin", "Chop", "Punch",
                        "Slide", "Wave", "Swank", "Exhibition", "Pulse", "Swipe", "Swipe back", "SwipeD", "Down", "Off"),
                slider("spd", "Скорость анимации", 0.3, 3, 1, 0.1, "x"),
                slider("amp", "Размер анимации", 0.3, 3, 1, 0.1, "x"),
                slider("dur", "Длительность", 2, 20, 6, 1, " тик"),
                mode("curve", "Кривая", 1, "Линейная", "Плавная", "Пружина")));
        SLASH = add(new Module("Visuals", "Slash Trail", "Светящийся след взмаха", false,
                mode("cm", "Цвет", 0, "Тема", "Статичный", "Радуга"),
                color("col", "Цвет", 0x3DB6FF),
                slider("w", "Толщина", 0.02, 0.3, 0.1, 0.01, ""),
                slider("life", "Время жизни", 100, 1000, 350, 25, " мс"),
                slider("glow", "Свечение", 0, 100, 60, 5, "%")));
        BLOCKOV = add(new Module("Visuals", "Block Overlay", "Подсветка блока под прицелом", false,
                mode("mode", "Режим", 0, "Грань", "Блок", "Контур"),
                mode("cm", "Цвет", 1, "Тема", "Статичный", "Радуга"),
                color("col", "Цвет", 0x3DDCC8),
                slider("fill", "Заливка", 0, 100, 35, 5, "%"),
                slider("op", "Контур", 0, 100, 90, 5, "%"),
                slider("thick", "Толщина", 1, 6, 2, 0.5, ""),
                bool("pulse", "Пульсация", false)));
        FULLBRIGHT = add(new Module("Visuals", "Full Bright", "Ночное зрение: всё светло", false));
        FOG = add(new Module("Visuals", "Fog Changer", "Туман: цвет и дальность", false,
                mode("mode", "Режим", 0, "Линейный", "Плотный", "Выкл"),
                slider("start", "Начало", 0, 200, 0, 5, " бл"),
                slider("end", "Конец", 4, 400, 80, 5, " бл"),
                bool("cc", "Свой цвет", false),
                color("col", "Цвет", 0xA0B4D8)));
        ASPECT = add(new Module("Visuals", "Aspect Ratio", "Соотношение сторон картинки", false,
                mode("pre", "Пресет", 0, "Своё", "4:3", "16:9", "21:9", "1:1", "5:4"),
                slider("ratio", "Соотношение", 0.5, 3, 1.78, 0.01, "")));
        TRAILS = add(new Module("Visuals", "Trails", "Следы за игроком", false,
                mode("st", "Стиль", 0, "Линия", "Лента", "Стена"),
                slider("len", "Длина", 5, 80, 30, 1, ""),
                color("col", "Цвет", 0xA86BFF),
                slider("op", "Прозрачность", 10, 100, 70, 5, "%"),
                bool("rb", "Радуга", false)));
        PARTICLES = add(new Module("Visuals", "Particles", "Частицы вокруг игрока", false,
                mode("src", "Источник", 1, "Ванильные", "Свои"),
                mode("type", "Ванильный тип", 0, "Огонь", "Сердца", "Звёзды", "Криты", "Снег"),
                mode("shape", "Форма (свои)", 1, "Круг", "Звезда", "Сердце", "Снежинка"),
                color("col", "Цвет (свои)", 0xFF8AD8),
                slider("size", "Размер", 0.05, 0.6, 0.2, 0.05, ""),
                slider("spd", "Скорость", 0.2, 3, 1, 0.1, "x"),
                slider("life", "Время жизни", 10, 80, 35, 5, " тик"),
                slider("n", "Количество", 1, 10, 3, 1, ""),
                slider("r", "Радиус", 0.3, 2.5, 1, 0.1, ""),
                bool("rb", "Радуга", false)));
        GLOW = add(new Module("Visuals", "Glow Particles", "Неоновые светящиеся частицы", false,
                mode("mode", "Режим", 0, "Орбита", "Вверх", "Спираль", "Всплеск"),
                color("col", "Цвет 1", 0xA86BFF),
                color("col2", "Цвет 2", 0xFF4FD8),
                slider("size", "Размер", 0.05, 0.5, 0.18, 0.01, ""),
                slider("life", "Время жизни", 8, 60, 24, 2, " тик"),
                slider("n", "Количество", 1, 8, 2, 1, ""),
                slider("r", "Радиус", 0.3, 2.5, 0.9, 0.1, "")));
        HAT = add(new Module("Visuals", "China Hat", "Шляпа над игроком", false,
                slider("h", "Высота", 0.1, 1, 0.35, 0.05, ""),
                slider("r", "Радиус", 0.2, 1.2, 0.6, 0.05, ""),
                color("col", "Цвет", 0xFF6BD6),
                slider("op", "Прозрачность", 10, 100, 60, 5, "%"),
                bool("rb", "Радуга", true)));
        TIME = add(new Module("Visuals", "Time Changer", "Время суток", false,
                slider("t", "Время", 0, 24000, 6000, 500, ""),
                bool("fr", "Заморозить", true)));

        // ===== Misc =====
        CSOUND = add(new Module("Misc", "Client Sounds", "Звуки клиента", true,
                mode("snd", "Звук", 0, SND),
                slider("vol", "Громкость", 0, 100, 60, 5, "%"),
                bool("tog", "При вкл/выкл модулей", true),
                bool("ui", "Клики по меню", true)));
        FONT = add(new Module("Misc", "Custom Font", "Шрифт меню и HUD", false,
                mode("font", "Шрифт", 1, "Default", "Uniform", "Runic"),
                bool("hud", "Для HUD", true),
                bool("menu", "Для меню", true)));
        BLUR = add(new Module("Misc", "GUI Blur", "Размытие фона меню", true,
                slider("str", "Сила размытия", 0, 10, 5, 1, ""),
                slider("dim", "Затемнение", 0, 80, 30, 5, "%")));
        ANIM = add(new Module("Misc", "GUI Animation", "Анимация открытия и закрытия меню", true,
                mode("mode", "Анимация", 1, "Fade", "Scale", "Slide", "Bounce"),
                slider("spd", "Скорость", 0.5, 3, 1.4, 0.1, "x"),
                bool("close", "Анимация закрытия", true)));
        HUDEDIT = add(new Module("Misc", "HUD Editor", "Перетаскивание элементов HUD", true,
                bool("snap", "Привязка к центру и краям", true),
                button("open", "Открыть редактор", () -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.setScreen(new HudEditorScreen(mc.currentScreen));
                }),
                button("reset", "Сбросить позиции", Hud::reset)));
        NOTIF = add(new Module("Misc", "Notifications", "Уведомления о модулях", true,
                mode("style", "Стиль", 0, "Плашка", "Минимал", "Акцент"),
                slider("dur", "Длительность", 1, 6, 2.5, 0.5, " с"),
                bool("mods", "Для модулей", true),
                bool("snd", "Со звуком", false)));
        THEME = add(new Module("Misc", "Custom Theme", "Тема меню и HUD", true,
                mode("preset", "Пресет", 0, "Purple", "Blue", "Red", "Green", "Dark", "Light", "Custom", "Neon Cyan", "Neon Pink", "Chibi Pixel"),
                color("accent", "Акцент (Custom)", 0xA86BFF),
                slider("round", "Скругление", 0, 10, 4, 1, " px"),
                bool("wm", "Ватермарк", true)));
        CLOCK = add(new Module("Misc", "Clock Bar", "Время, пинг, координаты", false,
                bool("time", "Время", true),
                bool("ping", "Пинг", false),
                bool("xyz", "Координаты", false),
                slider("bgop", "Прозрачность фона", 0, 100, 70, 5, "%")));
        KEYS = add(new Module("Misc", "Keystrokes", "WASD, мышь и CPS", false,
                bool("mouse", "Мышь + CPS", true),
                bool("space", "Пробел", false),
                slider("bgop", "Прозрачность фона", 0, 100, 55, 5, "%")));
        SPRINT = add(new Module("Misc", "Toggle Sprint", "Авто-спринт (кнопка: Управление → Umear)", false,
                mode("mode", "Режим", 0, "Всегда", "По кнопке"),
                bool("hud", "Надпись на экране", true)));
        TITLE = add(new Module("Misc", "Main Menu", "Пиксельное главное меню «чибик»", true,
                mode("bg", "Фон", 0, "Сумерки", "Закат", "Ночь", "Синтвейв", "День", "Аврора", "Сакура", "Случайный")));
        ZOOM = add(new Module("Shortcut", "Zoom", "Приближение (клавиша: Управление → Umear)", false,
                mode("kmode", "Клавиша", 0, "Удержание", "Переключение"),
                slider("lvl", "Приближение", 1.5, 10, 4, 0.5, "x"),
                bool("smooth", "Плавность", true),
                bool("wheel", "Колёсико меняет зум", true),
                bool("cine", "Кинокамера", true)));
        FREELOOK = add(new Module("Shortcut", "Freelook", "Свободный обзор (клавиша: Управление → Umear)", false,
                mode("kmode", "Клавиша", 0, "Удержание", "Переключение"),
                bool("third", "Третье лицо", true),
                slider("sens", "Чувствительность", 0.3, 2, 1, 0.1, "x")));
        load();
    }

    // ---------- хуки ----------
    public static void toggled(Module m) {
        Hud.notify(m.name, m.enabled);
        if (CSOUND != null && CSOUND.enabled && CSOUND.bool("tog"))
            Fx.play(CSOUND.mode("snd"), (float) CSOUND.num("vol") / 100f, m.enabled ? 1.15f : 0.85f);
        save();
    }

    public static void click() {
        CLICKS.addLast(System.currentTimeMillis());
    }

    public static int cps() {
        long now = System.currentTimeMillis();
        while (!CLICKS.isEmpty() && now - CLICKS.peekFirst() > 1000) CLICKS.pollFirst();
        return CLICKS.size();
    }

    public static long timeValue() {
        long t = (long) TIME.num("t");
        return TIME.bool("fr") ? t : (t + ticks) % 24000L;
    }

    public static float aspectValue() {
        int p = ASPECT.mode("pre");
        return p == 0 ? (float) ASPECT.num("ratio") : (float) RATIOS[p];
    }

    // ---------- конфиг ----------
    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("umear_visuals.json");
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            for (Module m : ALL) {
                o.addProperty(m.name + ".on", m.enabled);
                for (Setting s : m.settings) {
                    String k = m.name + "." + s.key;
                    switch (s.type) {
                        case SLIDER -> o.addProperty(k, s.val);
                        case COLOR -> o.addProperty(k, s.color);
                        case MODE -> o.addProperty(k, s.mode);
                        case BOOL -> o.addProperty(k, s.bool);
                        default -> { }
                    }
                }
            }
            o.add("hud", Hud.toJson());
            Files.writeString(path(), new GsonBuilder().setPrettyPrinting().create().toJson(o));
        } catch (Exception ignored) { }
    }

    private static void load() {
        try {
            if (!Files.exists(path())) return;
            JsonObject o = JsonParser.parseString(Files.readString(path())).getAsJsonObject();
            for (Module m : ALL) {
                try {
                    if (o.has(m.name + ".on")) { m.enabled = o.get(m.name + ".on").getAsBoolean(); m.tog = m.enabled ? 1f : 0f; }
                } catch (Exception ignored) { }
                for (Setting s : m.settings) {
                    String k = m.name + "." + s.key;
                    if (!o.has(k)) continue;
                    try {
                        switch (s.type) {
                            case SLIDER -> s.val = Math.max(s.min, Math.min(s.max, o.get(k).getAsDouble()));
                            case COLOR -> s.color = o.get(k).getAsInt() & 0xFFFFFF;
                            case MODE -> s.mode = Math.max(0, Math.min(s.modes.length - 1, o.get(k).getAsInt()));
                            case BOOL -> s.bool = o.get(k).getAsBoolean();
                            default -> { }
                        }
                    } catch (Exception ignored) { }
                }
            }
            if (o.has("hud")) Hud.fromJson(o.getAsJsonObject("hud"));
        } catch (Exception ignored) { }
    }
}
