package com.umear;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

import static com.umear.Setting.*;

public final class Modules {
    public static final String[] CATS = {"Combat", "Visuals", "Misc"};
    public static final List<Module> ALL = new ArrayList<>();
    public static final String[] SND = {"Click", "Pop", "Bell", "Ding"};

    public static Module INFO, HITSOUND, HITCOLOR, CROSS,
            ESP, VIEW, SWING, FOG, ASPECT, TRAILS, PARTICLES, HAT, TIME,
            CSOUND, FONT, BLUR, ANIM, HUDEDIT, NOTIF, THEME;

    public static long ticks;
    public static int combo;
    public static long lastHit;
    public static double reach;
    private static final ArrayDeque<Long> CLICKS = new ArrayDeque<>();
    private static final double[] RATIOS = {0, 4.0 / 3, 16.0 / 9, 21.0 / 9, 1.0, 5.0 / 4};

    private static Module add(Module m) { ALL.add(m); return m; }

    public static void init() {
        // ===== Combat =====
        INFO = add(new Module("Combat", "Info HUD", "FPS, CPS, Reach и Combo в одном блоке", true,
                bool("fps", "FPS", true), bool("cps", "CPS", true),
                bool("reach", "Reach", true), bool("combo", "Combo", true),
                mode("layout", "Расположение", 0, "Колонка", "Строка"),
                slider("bgop", "Прозрачность фона", 0, 100, 55, 5, "%"),
                color("col", "Цвет значений", 0xFFFFFF),
                bool("rst", "Сброс комбо при уроне", true),
                slider("to", "Сброс комбо через", 0.5, 6, 2.5, 0.5, " с")));
        HITSOUND = add(new Module("Combat", "Hit Sound", "Звук при попадании", false,
                mode("snd", "Звук", 0, SND),
                slider("vol", "Громкость", 0, 100, 70, 5, "%"),
                slider("pitch", "Тон", 50, 200, 100, 5, "%")));
        HITCOLOR = add(new Module("Combat", "Hit Color", "Цвет вспышки при попадании", false,
                color("col", "Цвет", 0xFF2D2D),
                slider("op", "Прозрачность", 10, 100, 70, 5, "%")));
        CROSS = add(new Module("Combat", "Dynamic Crosshair", "Прицел меняется при наведении на врага", false,
                mode("style", "Форма", 0, "Плюс", "Точка", "Круг", "X", "Скобки"),
                mode("who", "Цели", 0, "Все", "Игроки", "Мобы"),
                slider("size", "Размер", 2, 14, 5, 1, " px"),
                slider("gap", "Зазор", 0, 10, 2, 1, " px"),
                slider("thick", "Толщина", 1, 3, 1, 1, " px"),
                color("col", "Цвет", 0xFFFFFF),
                color("colt", "Цвет на цели", 0xFF3B3B),
                slider("grow", "Рост на цели", 0, 100, 40, 5, "%"),
                bool("outline", "Обводка", true)));

        // ===== Visuals =====
        ESP = add(new Module("Visuals", "Target ESP", "Подсветка цели", false,
                mode("mode", "Режим", 0, "Box", "Outline", "Circle", "Ring", "Halo"),
                mode("who", "Цели", 0, "Все", "Игроки", "Мобы"),
                mode("cm", "Цвет", 1, "Статичный", "Радуга", "Градиент"),
                color("col", "Цвет 1", 0xA86BFF),
                color("col2", "Цвет 2", 0x3DD6FF),
                slider("thick", "Толщина", 1, 8, 3, 0.5, ""),
                slider("op", "Прозрачность", 10, 100, 80, 5, "%"),
                slider("fill", "Заливка", 0, 100, 25, 5, "%"),
                slider("spd", "Скорость", 0.2, 4, 1, 0.2, "x")));
        VIEW = add(new Module("Visuals", "View Model", "Редактор положения руки", false,
                mode("hand", "Рука", 0, "Обе", "Правая", "Левая"),
                slider("x", "X", -1, 1, 0, 0.05, ""),
                slider("y", "Y", -1, 1, 0, 0.05, ""),
                slider("z", "Z", -1, 1, 0, 0.05, ""),
                slider("rx", "Поворот X", -180, 180, 0, 5, "°"),
                slider("ry", "Поворот Y", -180, 180, 0, 5, "°"),
                slider("rz", "Поворот Z", -180, 180, 0, 5, "°"),
                slider("sc", "Размер", 0.3, 1.5, 1, 0.05, "x")));
        SWING = add(new Module("Visuals", "Swing Animation", "Анимация удара", false,
                mode("mode", "Анимация", 1, "Vanilla", "Slash", "Smooth", "Block", "Poke"),
                slider("spd", "Скорость", 0.3, 3, 1, 0.1, "x"),
                slider("dur", "Длительность", 2, 20, 6, 1, " тик")));
        FOG = add(new Module("Visuals", "Fog Changer", "Туман: цвет и дальность", false,
                mode("mode", "Режим", 0, "Линейный", "Плотный", "Выкл"),
                slider("start", "Начало", 0, 200, 0, 5, " бл"),
                slider("end", "Конец", 4, 400, 80, 5, " бл"),
                bool("cc", "Свой цвет", false),
                color("col", "Цвет", 0xA0B4D8)));
        ASPECT = add(new Module("Visuals", "Aspect Ratio", "Соотношение сторон картинки", false,
                mode("pre", "Пресет", 0, "Своё", "4:3", "16:9", "21:9", "1:1", "5:4"),
                slider("ratio", "Соотношение", 0.5, 3, 1.78, 0.01, "")));
        TRAILS = add(new Module("Visuals", "Trails", "Следы за игроком", false,
                mode("st", "Стиль", 0, "Линия", "Лента", "Стена"),
                slider("len", "Длина", 5, 80, 30, 1, ""),
                color("col", "Цвет", 0xA86BFF),
                slider("op", "Прозрачность", 10, 100, 70, 5, "%"),
                bool("rb", "Радуга", false)));
        PARTICLES = add(new Module("Visuals", "Particles", "Частицы вокруг игрока", false,
                mode("src", "Источник", 1, "Ванильные", "Свои"),
                mode("type", "Ванильный тип", 0, "Огонь", "Сердца", "Звёзды", "Криты", "Снег"),
                mode("shape", "Форма (свои)", 1, "Круг", "Звезда", "Сердце", "Снежинка"),
                color("col", "Цвет (свои)", 0xFF8AD8),
                slider("size", "Размер", 0.05, 0.6, 0.2, 0.05, ""),
                slider("spd", "Скорость", 0.2, 3, 1, 0.1, "x"),
                slider("life", "Время жизни", 10, 80, 35, 5, " тик"),
                slider("n", "Количество", 1, 10, 3, 1, ""),
                slider("r", "Радиус", 0.3, 2.5, 1, 0.1, ""),
                bool("rb", "Радуга", false)));
        HAT = add(new Module("Visuals", "China Hat", "Шляпа над игроком", false,
                slider("h", "Высота", 0.1, 1, 0.35, 0.05, ""),
                slider("r", "Радиус", 0.2, 1.2, 0.6, 0.05, ""),
                color("col", "Цвет", 0xFF6BD6),
                slider("op", "Прозрачность", 10, 100, 60, 5, "%"),
                bool("rb", "Радуга", true)));
        TIME = add(new Module("Visuals", "Time Changer", "Время суток", false,
                slider("t", "Время", 0, 24000, 6000, 500, ""),
                bool("fr", "Заморозить", true)));

        // ===== Misc =====
        CSOUND = add(new Module("Misc", "Client Sounds", "Звуки клиента", true,
                mode("snd", "Звук", 0, SND),
                slider("vol", "Громкость", 0, 100, 60, 5, "%"),
                bool("tog", "При вкл/выкл модулей", true),
                bool("ui", "Клики по меню", true)));
        FONT = add(new Module("Misc", "Custom Font", "Шрифт меню и HUD", false,
                mode("font", "Шрифт", 1, "Default", "Uniform", "Runic"),
                bool("hud", "Для HUD", true),
                bool("menu", "Для меню", true)));
        BLUR = add(new Module("Misc", "GUI Blur", "Размытие фона меню", true,
                slider("str", "Сила размытия", 0, 10, 5, 1, ""),
                slider("dim", "Затемнение", 0, 80, 30, 5, "%")));
        ANIM = add(new Module("Misc", "GUI Animation", "Анимация открытия и закрытия меню", true,
                mode("mode", "Анимация", 1, "Fade", "Scale", "Slide", "Bounce"),
                slider("spd", "Скорость", 0.5, 3, 1.4, 0.1, "x"),
                bool("close", "Анимация закрытия", true)));
        HUDEDIT = add(new Module("Misc", "HUD Editor", "Перетаскивание элементов HUD", true,
                bool("snap", "Привязка к центру и краям", true),
                button("open", "Открыть редактор", () -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.setScreen(new HudEditorScreen(mc.currentScreen));
                }),
                button("reset", "Сбросить позиции", Hud::reset)));
        NOTIF = add(new Module("Misc", "Notifications", "Уведомления о модулях", true,
                mode("style", "Стиль", 0, "Плашка", "Минимал", "Акцент"),
                slider("dur", "Длительность", 1, 6, 2.5, 0.5, " с"),
                bool("mods", "Для модулей", true),
                bool("snd", "Со звуком", false)));
        THEME = add(new Module("Misc", "Custom Theme", "Тема меню и HUD", true,
                mode("preset", "Пресет", 0, "Purple", "Blue", "Red", "Green", "Dark", "Light", "Custom"),
                color("accent", "Акцент (Custom)", 0xA86BFF),
                slider("round", "Скругление", 0, 10, 4, 1, " px"),
                bool("wm", "Ватермарк", true)));
        load();
    }

    // ---------- хуки ----------
    public static void toggled(Module m) {
        Hud.notify(m.name, m.enabled);
        if (CSOUND != null && CSOUND.enabled && CSOUND.bool("tog"))
            Fx.play(CSOUND.mode("snd"), (float) CSOUND.num("vol") / 100f, m.enabled ? 1.15f : 0.85f);
        save();
    }

    public static void click() {
        CLICKS.addLast(System.currentTimeMillis());
    }

    public static int cps() {
        long now = System.currentTimeMillis();
        while (!CLICKS.isEmpty() && now - CLICKS.peekFirst() > 1000) CLICKS.pollFirst();
        return CLICKS.size();
    }

    public static long timeValue() {
        long t = (long) TIME.num("t");
        return TIME.bool("fr") ? t : (t + ticks) % 24000L;
    }

    public static float aspectValue() {
        int p = ASPECT.mode("pre");
        return p == 0 ? (float) ASPECT.num("ratio") : (float) RATIOS[p];
    }

    // ---------- конфиг ----------
    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("umear_visuals.json");
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            for (Module m : ALL) {
                o.addProperty(m.name + ".on", m.enabled);
                for (Setting s : m.settings) {
                    String k = m.name + "." + s.key;
                    switch (s.type) {
                        case SLIDER -> o.addProperty(k, s.val);
                        case COLOR -> o.addProperty(k, s.color);
                        case MODE -> o.addProperty(k, s.mode);
                        case BOOL -> o.addProperty(k, s.bool);
                        default -> { }
                    }
                }
            }
            o.add("hud", Hud.toJson());
            Files.writeString(path(), new GsonBuilder().setPrettyPrinting().create().toJson(o));
        } catch (Exception ignored) { }
    }

    private static void load() {
        try {
            if (!Files.exists(path())) return;
            JsonObject o = JsonParser.parseString(Files.readString(path())).getAsJsonObject();
            for (Module m : ALL) {
                try {
                    if (o.has(m.name + ".on")) { m.enabled = o.get(m.name + ".on").getAsBoolean(); m.tog = m.enabled ? 1f : 0f; }
                } catch (Exception ignored) { }
                for (Setting s : m.settings) {
                    String k = m.name + "." + s.key;
                    if (!o.has(k)) continue;
                    try {
                        switch (s.type) {
                            case SLIDER -> s.val = Math.max(s.min, Math.min(s.max, o.get(k).getAsDouble()));
                            case COLOR -> s.color = o.get(k).getAsInt() & 0xFFFFFF;
                            case MODE -> s.mode = Math.max(0, Math.min(s.modes.length - 1, o.get(k).getAsInt()));
                            case BOOL -> s.bool = o.get(k).getAsBoolean();
                            default -> { }
                        }
                    } catch (Exception ignored) { }
                }
            }
            if (o.has("hud")) Hud.fromJson(o.getAsJsonObject("hud"));
        } catch (Exception ignored) { }
    }
}
