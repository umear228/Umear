package com.umear;

import java.util.Locale;

public final class Setting {
    public enum Type { SLIDER, COLOR, MODE, BOOL, BUTTON }

    public final String key, label, unit;
    public final Type type;
    public double min, max, step, val;
    public int color;
    public int mode;
    public String[] modes;
    public boolean bool;
    public Runnable run;
    public boolean picking;

    private String cache = "";
    private double cacheVal = Double.NaN;

    private Setting(String key, String label, Type type, String unit) {
        this.key = key; this.label = label; this.type = type; this.unit = unit;
    }

    public static Setting slider(String key, String label, double min, double max, double def, double step, String unit) {
        Setting s = new Setting(key, label, Type.SLIDER, unit);
        s.min = min; s.max = max; s.val = def; s.step = step;
        return s;
    }

    public static Setting color(String key, String label, int rgb) {
        Setting s = new Setting(key, label, Type.COLOR, "");
        s.color = rgb & 0xFFFFFF;
        return s;
    }

    public static Setting mode(String key, String label, int def, String... modes) {
        Setting s = new Setting(key, label, Type.MODE, "");
        s.mode = def; s.modes = modes;
        return s;
    }

    public static Setting bool(String key, String label, boolean def) {
        Setting s = new Setting(key, label, Type.BOOL, "");
        s.bool = def;
        return s;
    }

    public static Setting button(String key, String label, Runnable r) {
        Setting s = new Setting(key, label, Type.BUTTON, "");
        s.run = r;
        return s;
    }

    public double frac() { return (val - min) / (max - min); }

    public void setFromFrac(double f) {
        f = Math.max(0, Math.min(1, f));
        double v = min + f * (max - min);
        if (step > 0) v = Math.round(v / step) * step;
        val = Math.max(min, Math.min(max, v));
    }

    public String shown() {
        if (val != cacheVal) {
            cacheVal = val;
            String f = step >= 1 ? "%.0f" : step >= 0.1 ? "%.1f" : "%.2f";
            cache = String.format(Locale.ROOT, f, val) + unit;
        }
        return cache;
    }
}
