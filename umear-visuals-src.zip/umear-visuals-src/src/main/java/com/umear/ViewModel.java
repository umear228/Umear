package com.umear;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;

public final class ViewModel {
    /** Применяет View Model и возвращает прогресс удара, который нужно отдать ваниле (0 при кастомной анимации). */
    public static float apply(MatrixStack ms, Hand hand, PlayerEntity pl, float swing) {
        boolean right = (hand == Hand.MAIN_HAND) == (pl.getMainArm() == Arm.RIGHT);
        float side = right ? 1f : -1f;
        Module v = Modules.VIEW;
        if (v.enabled) {
            int h = v.mode("hand");
            if (h == 0 || (h == 1 && right) || (h == 2 && !right)) {
                ms.translate(side * (float) v.num("x"), (float) v.num("y"), (float) v.num("z"));
                ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) v.num("rx")));
                ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * (float) v.num("ry")));
                ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * (float) v.num("rz")));
                float s = (float) v.num("sc");
                ms.scale(s, s, s);
            }
        }
        Module sw = Modules.SWING;
        if (!sw.enabled) return swing;
        float q = Math.min(1f, swing * (float) sw.num("spd"));
        int mode = sw.mode("mode");
        if (mode == 0 || q <= 0f) return q;
        float e = (float) Math.sin(q * Math.PI);
        switch (mode) {
            case 1 -> { // Slash
                ms.translate(0, -0.05f * e, -0.25f * e);
                ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * -45f * e));
                ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-35f * e));
            }
            case 2 -> { // Smooth
                ms.translate(0, -0.08f * e, -0.12f * e);
                ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-30f * e));
                ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 8f * e));
            }
            case 3 -> { // Block
                ms.translate(side * -0.1f * e, -0.05f * e, 0);
                ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-20f * e));
                ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * -40f * e));
                ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * -15f * e));
            }
            default -> ms.translate(0, 0.03f * e, -0.65f * e); // Poke
        }
        return 0f; // ванильный взмах заменён кастомным
    }
}
