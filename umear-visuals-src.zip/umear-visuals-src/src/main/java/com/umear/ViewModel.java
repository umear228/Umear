package com.umear;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;

public final class ViewModel {
    /** Применяет View Model и возвращает прогресс удара, который нужно отдать ваниле (0 при кастомной анимации). */
    public static float apply(MatrixStack ms, Hand hand, PlayerEntity pl, float swing) {
        boolean right = (hand == Hand.MAIN_HAND) == (pl.getMainArm() == Arm.RIGHT);
        float side = right ? 1f : -1f;
        Module v = Modules.VIEW;
        if (v.enabled) {
            int h = v.mode("hand");
            if (h == 0 || (h == 1 && right) || (h == 2 && !right)) {
                ms.translate(side * (float) v.num("x"), (float) v.num("y"), (float) v.num("z"));
                ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) v.num("rx")));
                ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * (float) v.num("ry")));
                ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * (float) v.num("rz")));
                float s = (float) v.num("sc");
                ms.scale(s, s, s);
                if (v.bool("flat")) {
                    ms.translate(side * 0.12f, -0.05f, 0.05f);
                    ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * -80f));
                }
            }
        }
        return swing;
    }
}
