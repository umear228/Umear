package com.umear;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;

public final class ViewModel {
    /** Применяет View Model и возвращает прогресс удара, который нужно отдать ваниле (0 при кастомной анимации). */
    public static float apply(MatrixStack ms, Hand hand, PlayerEntity pl, float swing) {
        boolean right = (hand == Hand.MAIN_HAND) == (pl.getMainArm() == Arm.RIGHT);
        float side = right ? 1f : -1f;
        Module v = Modules.VIEW;
        if (v.enabled) {
            int h = v.mode("hand");
            if (h == 0 || (h == 1 && right) || (h == 2 && !right)) {
                ms.translate(side * (float) v.num("x"), (float) v.num("y"), (float) v.num("z"));
                ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) v.num("rx")));
                ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * (float) v.num("ry")));
                ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * (float) v.num("rz")));
                float s = (float) v.num("sc");
                ms.scale(s, s, s);
            }
        }
        Module sw = Modules.SWING;
        if (!sw.enabled) return swing;
        float q = Math.min(1f, swing * (float) sw.num("spd"));
        int mode = sw.mode("mode");
        if (mode == 0 || q <= 0f) return q;
        float amp = (float) sw.num("amp");
        float qc = switch (sw.mode("curve")) {
            case 1 -> q * q * (3f - 2f * q);
            case 2 -> q + 0.12f * (float) Math.sin(q * Math.PI * 2) * (1f - q);
            default -> q;
        };
        float e = (float) Math.sin(qc * Math.PI) * amp;
        switch (mode) {
            case 1 -> { // Slash
                ms.translate(0, -0.05f * e, -0.25f * e);
                ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * -45f * e));
                ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-35f * e));
            }
            case 2 -> { // Smooth
                ms.translate(0, -0.08f * e, -0.12f * e);
                ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-30f * e));
                ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 8f * e));
            }
            case 3 -> { // Block
                ms.translate(side * -0.1f * e, -0.05f * e, 0);
                ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-20f * e));
                ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * -40f * e));
                ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * -15f * e));
            }
            case 4 -> ms.translate(0, 0.03f * e, -0.65f * e); // Poke
            case 5 -> { // Spin
                ms.translate(0, 0, -0.2f * e);
                ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-360f * qc * amp));
            }
            case 6 -> { // Chop
                ms.translate(0, 0.12f * e, -0.2f * e);
                ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-85f * e));
                ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * 10f * e));
            }
            case 7 -> { // Punch
                ms.translate(0, -0.05f * e, -0.5f * e);
                ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-10f * e));
            }
            case 8 -> { // Slide
                ms.translate(side * -0.5f * e, 0, -0.1f * e);
                ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 30f * e));
            }
            case 9 -> { // Wave
                float w = (float) Math.sin(qc * Math.PI * 3) * (1f - qc) * amp;
                ms.translate(0, 0.05f * e, -0.1f * e);
                ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * 25f * w));
            }
            case 10 -> { // Swank
                ms.translate(side * 0.1f * e, -0.1f * e, -0.3f * e);
                ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-40f * e));
                ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * -30f * e));
            }
            default -> { // Exhibition
                ms.translate(0, -0.1f * e, -0.3f * e);
                ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-45f * e));
                ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * 20f * (float) Math.sin(qc * Math.PI * 2)));
            }
        }
        return 0f; // ванильный взмах заменён кастомным
    }
}
