package com.umear;

public final class Theme {
    public static int accent = 0xFFA86BFF, panel, side, card, cardHi, text, sub, track;
    public static int round = 4;
    private static int last = -1;

    // accent, panel, side, card, cardHi, text, sub
    private static final int[][] P = {
        {0xA86BFF, 0x121019, 0x0C0913, 0x1B1529, 0x261D3A, 0xF1ECFF, 0x9A90B8},
        {0x4C9BFF, 0x0D1119, 0x090D14, 0x151C2A, 0x1D2740, 0xEAF1FF, 0x8D9BB8},
        {0xFF4D63, 0x150C10, 0x0F080B, 0x241218, 0x341A22, 0xFFEEF0, 0xB8909A},
        {0x3DDC84, 0x0B1410, 0x080F0B, 0x12211A, 0x193025, 0xEBFFF3, 0x8FB8A0},
        {0xC8C8D0, 0x101010, 0x0A0A0A, 0x1C1C1C, 0x282828, 0xF0F0F0, 0x9A9A9A},
        {0x6C5CE7, 0xF4F4F8, 0xE6E6EE, 0xFFFFFF, 0xEDEDF5, 0x1B1B26, 0x6A6A80},
    };

    /** Цвет названия модуля: от серого (выкл) к основному (вкл). */
    public static int mix2(float t) { return Ui.mix(sub, text, t); }

    public static void update() {
        Module t = Modules.THEME;
        int preset = t.enabled ? t.mode("preset") : 0;
        int custom = t.enabled ? t.get("accent").color : 0;
        int key = preset * 31 + custom + (t.enabled ? (int) t.num("round") * 7 : 0);
        if (key == last) return;
        last = key;
        int[] p = P[Math.min(preset, 5)];
        accent = 0xFF000000 | (preset == 6 ? custom : p[0]);
        panel = 0xFF000000 | p[1]; side = 0xFF000000 | p[2]; card = 0xFF000000 | p[3];
        cardHi = 0xFF000000 | p[4]; text = 0xFF000000 | p[5]; sub = 0xFF000000 | p[6];
        track = preset == 5 ? 0xFFD8D8E4 : 0xFF2A2A38;
        round = t.enabled ? (int) t.num("round") : 4;
    }
}
