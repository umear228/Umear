package com.umear;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.*;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import com.umear.mixin.OverlayTextureAccessor;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

public final class Fx {
    private static final Random RND = new Random();
    private static LivingEntity lastTarget;
    private static long lastTargetTime;
    private static int prevHurt;
    private static int appliedHit = -1;
    private static final ArrayList<double[]> TRAIL = new ArrayList<>();
    private static final ArrayList<P> PARTS = new ArrayList<>();

    private static final class P {
        double x, y, z, vx, vy, vz;
        int life, max, color, color2 = -1, shape;
        float size, grav, drag = 1f;
        boolean glow;
    }

    public static final class Num {
        public double x, y, z;
        public String s;
        public long born;
        public boolean crit;
    }

    private static final ArrayList<P> GP = new ArrayList<>();              // Glow + Hit Burst
    public static final ArrayList<Num> NUMS = new ArrayList<>();           // Damage Numbers
    private static final ArrayList<double[]> SLASH = new ArrayList<>();    // x,y,z,born,start
    private static final ArrayList<double[]> RINGS = new ArrayList<>();    // x,y,z,born
    private static LivingEntity dmgTarget;
    private static float dmgHp;
    private static long dmgTick;
    private static float lastSwing = -1f;
    private static boolean slashFlip, sprintForced;
    public static boolean sprintToggled;
    private static final Matrix4f VP = new Matrix4f();
    private static long lastHitTime;
    // Shortcut: Zoom / Freelook
    private static boolean zoomActive, zoomToggled, cineSet, cinePrev, flToggled, flPrevSet;
    public static boolean flActive;
    public static float flYaw, flPitch;
    private static float zoomCur = 1f;
    private static long zLast = System.nanoTime();
    private static net.minecraft.client.option.Perspective flPrev;
    private static double camX, camY, camZ;
    private static boolean vpValid;
    private static final float[] PROJ = new float[2];

    // ================= события =================
    public static ActionResult attack(PlayerEntity p, World w, Hand h, Entity e, EntityHitResult hit) {
        if (!w.isClient || !(e instanceof LivingEntity le)) return ActionResult.PASS;
        long now = System.currentTimeMillis();
        Vec3d eye = p.getEyePos();
        Box b = e.getBoundingBox();
        double dx = Math.max(Math.max(b.minX - eye.x, 0), eye.x - b.maxX);
        double dy = Math.max(Math.max(b.minY - eye.y, 0), eye.y - b.maxY);
        double dz = Math.max(Math.max(b.minZ - eye.z, 0), eye.z - b.maxZ);
        Modules.reach = Math.sqrt(dx * dx + dy * dy + dz * dz);
        Modules.combo++;
        Modules.lastHit = now;
        lastTarget = le;
        lastTargetTime = now;
        lastHitTime = now;
        if (Modules.DMG.enabled) { dmgTarget = le; dmgHp = le.getHealth(); dmgTick = Modules.ticks; }
        if (Modules.BURST.enabled) burst(le);
        if (Modules.HITSOUND.enabled)
            play(Modules.HITSOUND.mode("snd"), (float) Modules.HITSOUND.num("vol") / 100f,
                    (float) Modules.HITSOUND.num("pitch") / 100f);
        return ActionResult.PASS;
    }

    public static void tick(MinecraftClient mc) {
        Modules.ticks++;
        while (UmearClient.OPEN.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new UmearScreen());
        }
        while (UmearClient.SPRINT_KEY.wasPressed()) sprintToggled = !sprintToggled;
        syncHitColor(mc);
        tickShortcuts(mc);
        tickMenuMusic(mc);
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) {
            TRAIL.clear(); PARTS.clear(); GP.clear(); SLASH.clear(); RINGS.clear(); NUMS.clear();
            return;
        }

        Module info = Modules.INFO;
        if (Modules.combo > 0) {
            if (System.currentTimeMillis() - Modules.lastHit > info.num("to") * 1000) Modules.combo = 0;
            if (info.bool("rst") && p.hurtTime > prevHurt) Modules.combo = 0;
        }
        prevHurt = p.hurtTime;

        tickTrail(p);
        tickParticles(mc, p);
        tickGlow(p);
        tickDamage();
        tickSprint(mc);
        tickFullBright(p);
    }

    // ================= звук =================
    public static void play(int idx, float vol, float pitch) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getSoundManager() == null) return;
        SoundInstance s = switch (idx) {
            case 1 -> PositionedSoundInstance.master(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, pitch, vol);
            case 2 -> PositionedSoundInstance.master(SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), pitch, vol);
            case 3 -> PositionedSoundInstance.master(SoundEvents.ENTITY_ARROW_HIT_PLAYER, pitch, vol);
            default -> PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK.value(), pitch, vol);
        };
        mc.getSoundManager().play(s);
    }

    public static void uiClick() {
        Module c = Modules.CSOUND;
        if (c.enabled && c.bool("ui")) play(c.mode("snd"), (float) c.num("vol") / 100f, 1f);
    }

    // ================= Hit Color =================
    private static void syncHitColor(MinecraftClient mc) {
        if (mc.gameRenderer == null) return;
        Module m = Modules.HITCOLOR;
        int want = m.enabled ? (((int) (m.num("op") * 2.55) & 255) << 24) | m.get("col").color : 0;
        if (want == appliedHit) return;
        try {
            NativeImageBackedTexture tex = ((OverlayTextureAccessor) mc.gameRenderer.getOverlayTexture()).umear$getTexture();
            NativeImage img = tex.getImage();
            if (img == null) return;
            int argb = want == 0 ? 0xB2FF0000 : want;
            for (int y = 0; y < 8; y++) for (int x = 0; x < 16; x++) img.setColorArgb(x, y, argb);
            tex.upload();
            appliedHit = want;
        } catch (Throwable ignored) { appliedHit = want; }
    }

    // ================= цель =================
    private static boolean okWho(LivingEntity e, int who) {
        return who == 0 || (who == 1) == (e instanceof PlayerEntity);
    }

    /** Враг строго под прицелом (для Dynamic Crosshair). */
    public static boolean crossTarget(MinecraftClient mc, int who) {
        HitResult hr = mc.crosshairTarget;
        return hr instanceof EntityHitResult eh && eh.getEntity() instanceof LivingEntity le
                && le != mc.player && okWho(le, who);
    }

    /** Цель для ESP: под прицелом либо последняя атакованная (3 с). */
    public static LivingEntity target(MinecraftClient mc, int who) {
        long now = System.currentTimeMillis();
        HitResult hr = mc.crosshairTarget;
        if (hr instanceof EntityHitResult eh && eh.getEntity() instanceof LivingEntity le
                && le != mc.player && okWho(le, who)) {
            lastTarget = le; lastTargetTime = now;
            return le;
        }
        if (lastTarget != null && lastTarget.isAlive() && !lastTarget.isRemoved()
                && now - lastTargetTime < 3000 && okWho(lastTarget, who)) return lastTarget;
        return null;
    }

    // ================= следы / частицы =================
    private static void tickTrail(ClientPlayerEntity p) {
        if (!Modules.TRAILS.enabled) { TRAIL.clear(); return; }
        int max = (int) Modules.TRAILS.num("len");
        double[] last = TRAIL.isEmpty() ? null : TRAIL.get(TRAIL.size() - 1);
        if (last == null || p.squaredDistanceTo(last[0], last[1], last[2]) > 0.0004)
            TRAIL.add(new double[]{p.getX(), p.getY(), p.getZ()});
        else if ((Modules.ticks & 1) == 0 && !TRAIL.isEmpty()) TRAIL.remove(0);
        while (TRAIL.size() > max) TRAIL.remove(0);
    }

    private static void tickParticles(MinecraftClient mc, ClientPlayerEntity p) {
        step(PARTS);
        step(GP);
        Module m = Modules.PARTICLES;
        if (!m.enabled) { PARTS.clear(); return; }
        int n = (int) m.num("n");
        double r = m.num("r"), spd = m.num("spd");
        boolean custom = m.mode("src") == 1;
        ParticleEffect type = switch (m.mode("type")) {
            case 1 -> ParticleTypes.HEART;
            case 2 -> ParticleTypes.END_ROD;
            case 3 -> ParticleTypes.CRIT;
            case 4 -> ParticleTypes.SNOWFLAKE;
            default -> ParticleTypes.FLAME;
        };
        for (int i = 0; i < n; i++) {
            double a = RND.nextDouble() * Math.PI * 2, d = Math.sqrt(RND.nextDouble()) * r;
            double x = p.getX() + Math.cos(a) * d, y = p.getY() + RND.nextDouble() * p.getHeight(), z = p.getZ() + Math.sin(a) * d;
            if (custom) {
                if (PARTS.size() > 400) break;
                P q = new P();
                q.x = x; q.y = y; q.z = z;
                q.vx = (RND.nextDouble() - 0.5) * 0.02 * spd;
                q.vy = (0.01 + RND.nextDouble() * 0.02) * spd;
                q.vz = (RND.nextDouble() - 0.5) * 0.02 * spd;
                q.max = q.life = (int) m.num("life");
                q.size = (float) m.num("size");
                q.shape = m.mode("shape");
                q.color = m.bool("rb") ? Ui.hsv(RND.nextFloat(), 0.7f, 1f) & 0xFFFFFF : m.get("col").color;
                PARTS.add(q);
            } else {
                mc.world.addParticle(type, x, y, z, 0, 0.02 * spd, 0);
            }
        }
    }

    // ================= рендер в мире =================
    private static final class G {
        static BufferBuilder b;
        static Matrix4f m;
        static double cx, cy, cz;
        static int n;

        static void v(double x, double y, double z, int c) {
            if (b == null) {
                b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
                n = 0;
            }
            b.vertex(m, (float) (x - cx), (float) (y - cy), (float) (z - cz)).color(c);
            n++;
        }

        static void tri(double x1, double y1, double z1, int c1, double x2, double y2, double z2, int c2,
                        double x3, double y3, double z3, int c3) {
            v(x1, y1, z1, c1); v(x2, y2, z2, c2); v(x3, y3, z3, c3); v(x3, y3, z3, c3);
        }

        static void line(double x1, double y1, double z1, double x2, double y2, double z2, double w, int c1, int c2) {
            double dx = x2 - x1, dy = y2 - y1, dz = z2 - z1;
            double mx = (x1 + x2) / 2 - cx, my = (y1 + y2) / 2 - cy, mz = (z1 + z2) / 2 - cz;
            double sx = dy * mz - dz * my, sy = dz * mx - dx * mz, sz = dx * my - dy * mx;
            double l = Math.sqrt(sx * sx + sy * sy + sz * sz);
            if (l < 1e-9) return;
            double k = w / 2 / l;
            sx *= k; sy *= k; sz *= k;
            v(x1 + sx, y1 + sy, z1 + sz, c1); v(x1 - sx, y1 - sy, z1 - sz, c1);
            v(x2 - sx, y2 - sy, z2 - sz, c2); v(x2 + sx, y2 + sy, z2 + sz, c2);
        }

        static void flush() {
            if (b != null) {
                if (n > 0) BufferRenderer.drawWithGlobalProgram(b.end());
                b = null;
            }
        }

        static void fillBox(Box bb, int c) {
            double x1 = bb.minX, y1 = bb.minY, z1 = bb.minZ, x2 = bb.maxX, y2 = bb.maxY, z2 = bb.maxZ;
            v(x1, y1, z1, c); v(x2, y1, z1, c); v(x2, y1, z2, c); v(x1, y1, z2, c);
            v(x1, y2, z1, c); v(x1, y2, z2, c); v(x2, y2, z2, c); v(x2, y2, z1, c);
            v(x1, y1, z1, c); v(x1, y2, z1, c); v(x2, y2, z1, c); v(x2, y1, z1, c);
            v(x1, y1, z2, c); v(x2, y1, z2, c); v(x2, y2, z2, c); v(x1, y2, z2, c);
            v(x1, y1, z1, c); v(x1, y1, z2, c); v(x1, y2, z2, c); v(x1, y2, z1, c);
            v(x2, y1, z1, c); v(x2, y2, z1, c); v(x2, y2, z2, c); v(x2, y1, z2, c);
        }

        static void edges(Box bb, double w, int c) {
            double x1 = bb.minX, y1 = bb.minY, z1 = bb.minZ, x2 = bb.maxX, y2 = bb.maxY, z2 = bb.maxZ;
            line(x1, y1, z1, x2, y1, z1, w, c, c); line(x1, y1, z2, x2, y1, z2, w, c, c);
            line(x1, y2, z1, x2, y2, z1, w, c, c); line(x1, y2, z2, x2, y2, z2, w, c, c);
            line(x1, y1, z1, x1, y2, z1, w, c, c); line(x2, y1, z1, x2, y2, z1, w, c, c);
            line(x1, y1, z2, x1, y2, z2, w, c, c); line(x2, y1, z2, x2, y2, z2, w, c, c);
            line(x1, y1, z1, x1, y1, z2, w, c, c); line(x2, y1, z1, x2, y1, z2, w, c, c);
            line(x1, y2, z1, x1, y2, z2, w, c, c); line(x2, y2, z1, x2, y2, z2, w, c, c);
        }
    }

    private static final int SEG = 40;

    private static final float[][] SHAPES = {circle(16), star(5, 0.45f), heart(24), star(6, 0.3f)};

    private static float[] circle(int n) {
        float[] o = new float[n * 2];
        for (int i = 0; i < n; i++) { double a = Math.PI * 2 * i / n; o[i * 2] = (float) Math.cos(a); o[i * 2 + 1] = (float) Math.sin(a); }
        return o;
    }

    private static float[] star(int pts, float inner) {
        int n = pts * 2;
        float[] o = new float[n * 2];
        for (int i = 0; i < n; i++) {
            double a = Math.PI / 2 + Math.PI * 2 * i / n;
            float r = (i & 1) == 0 ? 1f : inner;
            o[i * 2] = (float) (Math.cos(a) * r); o[i * 2 + 1] = (float) (Math.sin(a) * r);
        }
        return o;
    }

    private static float[] heart(int n) {
        float[] o = new float[n * 2];
        for (int i = 0; i < n; i++) {
            double t = Math.PI * 2 * i / n;
            o[i * 2] = (float) (16 * Math.pow(Math.sin(t), 3) / 17);
            o[i * 2 + 1] = (float) ((13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)) / 17);
        }
        return o;
    }

    public static void world(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;
        boolean any = Modules.HAT.enabled || Modules.TRAILS.enabled || Modules.MARKER.enabled || Modules.BLOCKOV.enabled
                || Modules.SLASH.enabled || Modules.DMG.enabled || !PARTS.isEmpty() || !GP.isEmpty() || !RINGS.isEmpty();
        if (!any) return;
        var ms = ctx.matrixStack();
        if (ms == null) return;
        Camera cam = ctx.camera();
        float td = ctx.tickCounter().getTickDelta(false);
        Vec3d cp = cam.getPos();
        G.m = ms.peek().getPositionMatrix();
        G.cx = cp.x; G.cy = cp.y; G.cz = cp.z;
        camX = cp.x; camY = cp.y; camZ = cp.z;
        VP.set(ctx.projectionMatrix()).mul(G.m);
        vpValid = true;
        long now = System.currentTimeMillis();
        double time = (System.currentTimeMillis() % 1000000L) / 1000.0;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        Vec3d pos = p.getLerpedPos(td);

        if (Modules.HAT.enabled && cam.isThirdPerson()) hat(p, pos, time);
        G.flush();
        if (Modules.TRAILS.enabled) trail(p, pos, time);
        G.flush();
        drawParts(PARTS, cam, td, time);
        G.flush();
        drawParts(GP, cam, td, time);
        G.flush();
        if (Modules.BLOCKOV.enabled) { blockOverlay(mc, time); G.flush(); }
        if (Modules.SLASH.enabled) slash(p, td, now, time);
        else { SLASH.clear(); lastSwing = -1f; }
        G.flush();
        drawRings(now);
        G.flush();

        RenderSystem.disableDepthTest();
        if (Modules.MARKER.enabled) {
            marker(mc, cam, td, time, now);
            G.flush();
        }

        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    private static void hat(ClientPlayerEntity p, Vec3d pos, double time) {
        Module m = Modules.HAT;
        double top = pos.y + p.getHeight() + 0.02, h = m.num("h"), r = m.num("r");
        int op = (int) (m.num("op") * 2.55);
        int segs = 36;
        for (int i = 0; i < segs; i++) {
            double a1 = Math.PI * 2 * i / segs, a2 = Math.PI * 2 * (i + 1) / segs;
            int col = m.bool("rb") ? Ui.hsv((float) ((double) i / segs + time * 0.2), 0.7f, 1f) & 0xFFFFFF : m.get("col").color;
            int c = Ui.withA(col, op), cs = Ui.withA(col, 255);
            double x1 = pos.x + Math.cos(a1) * r, z1 = pos.z + Math.sin(a1) * r;
            double x2 = pos.x + Math.cos(a2) * r, z2 = pos.z + Math.sin(a2) * r;
            G.tri(pos.x, top + h, pos.z, Ui.withA(col, Math.min(255, op + 60)), x1, top, z1, c, x2, top, z2, c);
            G.line(x1, top, z1, x2, top, z2, 0.025, cs, cs);
        }
    }

    private static void trail(ClientPlayerEntity p, Vec3d pos, double time) {
        Module m = Modules.TRAILS;
        int n = TRAIL.size();
        if (n < 1) return;
        int st = m.mode("st"), op = (int) (m.num("op") * 2.55);
        double h = st == 1 ? 0.6 : st == 2 ? p.getHeight() : 0;
        for (int i = 0; i < n; i++) {
            double[] a = TRAIL.get(i);
            double[] b = i + 1 < n ? TRAIL.get(i + 1) : new double[]{pos.x, pos.y, pos.z};
            int col = m.bool("rb") ? Ui.hsv((float) (i * 0.02 + time * 0.25), 0.7f, 1f) & 0xFFFFFF : m.get("col").color;
            int ca = Ui.withA(col, op * (i + 1) / (n + 1)), cb = Ui.withA(col, op * (i + 2) / (n + 1));
            if (st == 0) {
                G.line(a[0], a[1] + 0.1, a[2], b[0], b[1] + 0.1, b[2], 0.07, ca, cb);
            } else {
                G.v(a[0], a[1] + 0.1, a[2], ca); G.v(a[0], a[1] + 0.1 + h, a[2], ca);
                G.v(b[0], b[1] + 0.1 + h, b[2], cb); G.v(b[0], b[1] + 0.1, b[2], cb);
            }
        }
    }


    // ================= новые эффекты =================
    private static void step(ArrayList<P> list) {
        for (int i = list.size() - 1; i >= 0; i--) {
            P q = list.get(i);
            q.x += q.vx; q.y += q.vy; q.z += q.vz;
            q.vy -= q.grav;
            q.vx *= q.drag; q.vy *= q.drag; q.vz *= q.drag;
            if (--q.life <= 0) list.remove(i);
        }
    }

    private static void tickGlow(ClientPlayerEntity p) {
        Module m = Modules.GLOW;
        if (!m.enabled) return;
        int n = (int) m.num("n"), mode = m.mode("mode");
        double r = m.num("r");
        for (int i = 0; i < n && GP.size() < 300; i++) {
            P q = new P();
            switch (mode) {
                case 0 -> {
                    double a = Modules.ticks * 0.15 + i * Math.PI * 2 / n;
                    q.x = p.getX() + Math.cos(a) * r;
                    q.y = p.getY() + p.getHeight() * 0.5 + Math.sin(Modules.ticks * 0.07 + i) * 0.6;
                    q.z = p.getZ() + Math.sin(a) * r;
                }
                case 1 -> {
                    double a = RND.nextDouble() * Math.PI * 2, d = Math.sqrt(RND.nextDouble()) * r;
                    q.x = p.getX() + Math.cos(a) * d;
                    q.y = p.getY() + RND.nextDouble() * 0.3;
                    q.z = p.getZ() + Math.sin(a) * d;
                    q.vy = 0.03 + RND.nextDouble() * 0.03;
                }
                case 2 -> {
                    double a = Modules.ticks * 0.25 + i * Math.PI * 2 / n;
                    q.x = p.getX() + Math.cos(a) * r * 0.6;
                    q.y = p.getY() + (Modules.ticks % 40) / 40.0 * p.getHeight();
                    q.z = p.getZ() + Math.sin(a) * r * 0.6;
                    q.vy = 0.02;
                }
                default -> {
                    double a = RND.nextDouble() * Math.PI * 2, sp = 0.03 + RND.nextDouble() * 0.04;
                    q.x = p.getX(); q.y = p.getY() + p.getHeight() * 0.5; q.z = p.getZ();
                    q.vx = Math.cos(a) * sp; q.vz = Math.sin(a) * sp;
                    q.vy = (RND.nextDouble() - 0.3) * 0.04;
                }
            }
            q.max = q.life = (int) m.num("life");
            q.color = m.get("col").color;
            q.color2 = m.get("col2").color;
            q.size = (float) m.num("size");
            q.glow = true;
            GP.add(q);
        }
    }

    private static void burst(LivingEntity e) {
        Module m = Modules.BURST;
        int type = m.mode("type"), n = (int) m.num("n");
        double cx = e.getX(), cy = e.getY() + e.getHeight() * 0.6, cz = e.getZ();
        if (type == 2) {
            RINGS.add(new double[]{cx, e.getY() + 0.05, cz, System.currentTimeMillis()});
            if (RINGS.size() > 6) RINGS.remove(0);
            return;
        }
        for (int i = 0; i < n && GP.size() < 300; i++) {
            double a = RND.nextDouble() * Math.PI * 2, sp = 0.05 + RND.nextDouble() * 0.1;
            P q = new P();
            q.x = cx; q.y = cy; q.z = cz;
            q.vx = Math.cos(a) * sp; q.vz = Math.sin(a) * sp;
            q.vy = (RND.nextDouble() * 0.8 - 0.1) * 0.12;
            q.max = q.life = 14 + RND.nextInt(8);
            q.color = m.get("col").color;
            q.color2 = m.get("col2").color;
            q.size = (float) m.num("size");
            q.glow = type == 0;
            q.shape = type == 1 ? 1 : 0;
            q.grav = 0.004f;
            q.drag = 0.92f;
            GP.add(q);
        }
    }

    private static void tickDamage() {
        if (dmgTarget == null) return;
        long dt = Modules.ticks - dmgTick;
        if (dt < 1) return;
        float hp = dmgTarget.getHealth();
        if (hp < dmgHp - 0.01f) {
            double d = dmgHp - hp;
            Num n = new Num();
            n.x = dmgTarget.getX() + (RND.nextDouble() - 0.5) * 0.5;
            n.y = dmgTarget.getY() + dmgTarget.getHeight() + 0.1;
            n.z = dmgTarget.getZ() + (RND.nextDouble() - 0.5) * 0.5;
            n.s = d >= 10 ? String.format(Locale.ROOT, "%.0f", d) : String.format(Locale.ROOT, "%.1f", d);
            n.crit = d >= Modules.DMG.num("crit");
            n.born = System.currentTimeMillis();
            NUMS.add(n);
            if (NUMS.size() > 12) NUMS.remove(0);
            dmgTarget = null;
        } else if (dt > 12) dmgTarget = null;
    }

    private static void tickSprint(MinecraftClient mc) {
        Module m = Modules.SPRINT;
        if (!m.enabled) {
            if (sprintForced) { mc.options.sprintKey.setPressed(false); sprintForced = false; }
            return;
        }
        boolean want = m.mode("mode") == 0 || sprintToggled;
        boolean fwd = mc.options.forwardKey.isPressed();
        if (want && fwd && mc.currentScreen == null) {
            mc.options.sprintKey.setPressed(true);
            sprintForced = true;
        } else if (sprintForced) {
            mc.options.sprintKey.setPressed(false);
            sprintForced = false;
        }
    }

    /** Проекция мировой точки на экран (для Damage Numbers). */
    private static boolean project(double x, double y, double z, int sw, int sh) {
        if (!vpValid) return false;
        org.joml.Vector4f v = new org.joml.Vector4f((float) (x - camX), (float) (y - camY), (float) (z - camZ), 1f);
        VP.transform(v);
        if (v.w <= 0.05f) return false;
        PROJ[0] = (v.x / v.w * 0.5f + 0.5f) * sw;
        PROJ[1] = (1f - (v.y / v.w * 0.5f + 0.5f)) * sh;
        return true;
    }

    public static void drawNums(net.minecraft.client.gui.DrawContext g) {
        if (NUMS.isEmpty()) return;
        Module m = Modules.DMG;
        long now = System.currentTimeMillis();
        float life = (float) m.num("life") * 1000f;
        int sw = g.getScaledWindowWidth(), sh = g.getScaledWindowHeight();
        var ms = g.getMatrices();
        for (int i = NUMS.size() - 1; i >= 0; i--) {
            Num n = NUMS.get(i);
            float age = now - n.born;
            if (age > life) { NUMS.remove(i); continue; }
            float t = age / life;
            if (!project(n.x, n.y + t * 0.9, n.z, sw, sh)) continue;
            float pop = Ui.back(Math.min(1f, age / 180f));
            float sc = (float) m.num("size") * (n.crit ? 1.4f : 1f) * Math.max(0.2f, pop);
            Ui.alpha = 1f - t * t;
            int col = n.crit ? m.col("colc") : m.col("col");
            ms.push();
            ms.translate(PROJ[0], PROJ[1], 0);
            ms.scale(sc, sc, 1f);
            Ui.text(g, n.s, -Ui.tw(n.s) / 2, -4, col);
            ms.pop();
        }
        Ui.alpha = 1f;
    }

    private static final float[] LOW = circle(10);

    private static void polyFan(double cx, double cy, double cz, Vector3f right, Vector3f up, float[] sh, float s, int c) {
        int n = sh.length / 2;
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            double ax = (right.x * sh[i * 2] + up.x * sh[i * 2 + 1]) * s, ay = (right.y * sh[i * 2] + up.y * sh[i * 2 + 1]) * s, az = (right.z * sh[i * 2] + up.z * sh[i * 2 + 1]) * s;
            double bx = (right.x * sh[j * 2] + up.x * sh[j * 2 + 1]) * s, by = (right.y * sh[j * 2] + up.y * sh[j * 2 + 1]) * s, bz = (right.z * sh[j * 2] + up.z * sh[j * 2 + 1]) * s;
            G.tri(cx, cy, cz, c, cx + ax, cy + ay, cz + az, c, cx + bx, cy + by, cz + bz, c);
        }
    }

    private static void drawParts(ArrayList<P> list, Camera cam, float td, double time) {
        if (list.isEmpty()) return;
        Quaternionf rot = cam.getRotation();
        Vector3f right = new Vector3f(1, 0, 0).rotate(rot), up = new Vector3f(0, 1, 0).rotate(rot);
        for (P q : list) {
            float lf = q.life / (float) q.max;
            float fade = Math.min(1f, lf / 0.4f);
            int col = q.color2 >= 0 ? Ui.mix(0xFF000000 | q.color, 0xFF000000 | q.color2, 1f - lf) & 0xFFFFFF : q.color;
            float s = q.size * (0.6f + 0.4f * fade);
            double cx = q.x + q.vx * td, cy = q.y + q.vy * td, cz = q.z + q.vz * td;
            if (q.glow) {
                float fl = fade * (0.85f + 0.15f * (float) Math.sin(time * 18 + q.x * 13));
                polyFan(cx, cy, cz, right, up, LOW, s * 0.55f, Ui.withA(col, (int) (255 * fl)));
                polyFan(cx, cy, cz, right, up, LOW, s * 1.1f, Ui.withA(col, (int) (90 * fl)));
                polyFan(cx, cy, cz, right, up, LOW, s * 2.0f, Ui.withA(col, (int) (34 * fl)));
            } else {
                polyFan(cx, cy, cz, right, up, SHAPES[Math.min(q.shape, 3)], s, Ui.withA(col, (int) (255 * fade)));
            }
        }
    }

    private static void drawRings(long now) {
        RINGS.removeIf(d -> now - (long) d[3] > 600);
        if (RINGS.isEmpty()) return;
        Module m = Modules.BURST;
        for (double[] d : RINGS) {
            double t = (now - d[3]) / 600.0;
            double rad = 0.2 + t * 1.6, w = 0.02 + 0.07 * (1 - t);
            int c1 = Ui.withA(m.get("col").color, (int) (255 * (1 - t)));
            int c2 = Ui.withA(m.get("col2").color, (int) (255 * (1 - t)));
            for (int i = 0; i < SEG; i++) {
                double a1 = Math.PI * 2 * i / SEG, a2 = Math.PI * 2 * (i + 1) / SEG;
                G.line(d[0] + Math.cos(a1) * rad, d[1], d[2] + Math.sin(a1) * rad,
                        d[0] + Math.cos(a2) * rad, d[1], d[2] + Math.sin(a2) * rad, w, i % 2 == 0 ? c1 : c2, i % 2 == 0 ? c2 : c1);
            }
        }
    }

    private static int accentColor(Module m, double time, double off) {
        int cm = m.mode("cm");
        if (cm == 0) return Theme.accent & 0xFFFFFF;
        if (cm == 1) return m.get("col").color;
        return Ui.hsv((float) (time * 0.25 + off), 0.75f, 1f) & 0xFFFFFF;
    }

    private static void slash(ClientPlayerEntity p, float td, long now, double time) {
        Module m = Modules.SLASH;
        final double life = m.num("life");
        SLASH.removeIf(d -> now - (long) d[3] > life);
        if (p.handSwinging) {
            float s = p.getHandSwingProgress(td);
            if (s > 0f && s != lastSwing) {
                boolean start = lastSwing < 0f || s < lastSwing;
                if (start) slashFlip = !slashFlip;
                lastSwing = s;
                Vec3d eye = p.getCameraPosVec(td), f = p.getRotationVec(td);
                Vec3d right = new Vec3d(-f.z, 0, f.x).normalize();
                Vec3d up = right.crossProduct(f);
                double sg = slashFlip ? 1 : -1;
                double a = (-0.95 + 1.9 * s) * sg, tilt = 0.5 * sg;
                double x = Math.sin(a) * 1.1, y = Math.cos(a) * 0.45 - 0.35;
                double xr = x * Math.cos(tilt) - y * Math.sin(tilt), yr = x * Math.sin(tilt) + y * Math.cos(tilt);
                Vec3d pt = eye.add(f.multiply(1.7)).add(right.multiply(xr)).add(up.multiply(yr));
                SLASH.add(new double[]{pt.x, pt.y, pt.z, now, start ? 1 : 0});
                if (SLASH.size() > 80) SLASH.remove(0);
            }
        } else lastSwing = -1f;
        int n = SLASH.size();
        double w = m.num("w"), glow = m.num("glow") / 100.0;
        for (int i = 1; i < n; i++) {
            double[] a = SLASH.get(i - 1), b = SLASH.get(i);
            if (b[4] == 1) continue;
            double fa = 1 - (now - b[3]) / life;
            if (fa <= 0) continue;
            int col = accentColor(m, time, i * 0.03);
            int cg = Ui.withA(col, (int) (255 * fa * glow * 0.45)), cc = Ui.withA(col, (int) (255 * fa));
            G.line(a[0], a[1], a[2], b[0], b[1], b[2], w * 2.4, cg, cg);
            G.line(a[0], a[1], a[2], b[0], b[1], b[2], w * (0.4 + 0.6 * fa), cc, cc);
        }
    }

    // ================= Target Marker: формы =================
    private static float[] ngon(int n, double off) {
        float[] o = new float[n * 2];
        for (int i = 0; i < n; i++) { double a = off + Math.PI * 2 * i / n; o[i * 2] = (float) Math.cos(a); o[i * 2 + 1] = (float) Math.sin(a); }
        return o;
    }

    private static final float[] SQUARE = ngon(4, Math.PI / 4), DIAMOND = ngon(4, 0), TRI = ngon(3, Math.PI / 2),
            HEX = ngon(6, 0), STAR5 = star(5, 0.45f), HEART = heart(24), CIRC24 = circle(24),
            CRYSTAL = {0f, 1f, 0.55f, 0f, 0f, -1f, -0.55f, 0f};

    private static void polyFanR(double cx, double cy, double cz, Vector3f R, Vector3f U, float[] sh, double s, double ang, int c) {
        double ca = Math.cos(ang), sa = Math.sin(ang);
        int n = sh.length / 2;
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            double x1 = (sh[i * 2] * ca - sh[i * 2 + 1] * sa) * s, y1 = (sh[i * 2] * sa + sh[i * 2 + 1] * ca) * s;
            double x2 = (sh[j * 2] * ca - sh[j * 2 + 1] * sa) * s, y2 = (sh[j * 2] * sa + sh[j * 2 + 1] * ca) * s;
            G.tri(cx, cy, cz, c,
                    cx + R.x * x1 + U.x * y1, cy + R.y * x1 + U.y * y1, cz + R.z * x1 + U.z * y1, c,
                    cx + R.x * x2 + U.x * y2, cy + R.y * x2 + U.y * y2, cz + R.z * x2 + U.z * y2, c);
        }
    }

    private static void l2(double cx, double cy, double cz, Vector3f R, Vector3f U,
                           double x1, double y1, double x2, double y2, double w, int c) {
        G.line(cx + R.x * x1 + U.x * y1, cy + R.y * x1 + U.y * y1, cz + R.z * x1 + U.z * y1,
                cx + R.x * x2 + U.x * y2, cy + R.y * x2 + U.y * y2, cz + R.z * x2 + U.z * y2, w, c, c);
    }

    private static void outline(double cx, double cy, double cz, Vector3f R, Vector3f U, float[] sh,
                                double s, double ang, double w, int c, int cg) {
        double ca = Math.cos(ang), sa = Math.sin(ang);
        int n = sh.length / 2;
        for (int pass = 0; pass < 2; pass++) {
            int col = pass == 0 ? cg : c;
            double ww = pass == 0 ? w * 2.6 : w;
            if (pass == 0 && (cg >>> 24) == 0) continue;
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                double x1 = (sh[i * 2] * ca - sh[i * 2 + 1] * sa) * s, y1 = (sh[i * 2] * sa + sh[i * 2 + 1] * ca) * s;
                double x2 = (sh[j * 2] * ca - sh[j * 2 + 1] * sa) * s, y2 = (sh[j * 2] * sa + sh[j * 2 + 1] * ca) * s;
                l2(cx, cy, cz, R, U, x1, y1, x2, y2, ww, col);
            }
        }
    }

    private static void arc(double cx, double cy, double cz, Vector3f R, Vector3f U, double rad,
                            double a0, double span, int segs, double w, int c, int cg) {
        for (int pass = 0; pass < 2; pass++) {
            int col = pass == 0 ? cg : c;
            double ww = pass == 0 ? w * 2.6 : w;
            if (pass == 0 && (cg >>> 24) == 0) continue;
            for (int i = 0; i < segs; i++) {
                double a1 = a0 + span * i / segs, a2 = a0 + span * (i + 1) / segs;
                l2(cx, cy, cz, R, U, Math.cos(a1) * rad, Math.sin(a1) * rad, Math.cos(a2) * rad, Math.sin(a2) * rad, ww, col);
            }
        }
    }

    private static int markerColor(Module m, LivingEntity e, double time) {
        switch (m.mode("cm")) {
            case 0: return Theme.accent & 0xFFFFFF;
            case 1: return m.get("col").color;
            case 2: return Ui.hsv((float) (time * 0.2), 0.75f, 1f) & 0xFFFFFF;
            default: {
                float f = Math.max(0f, Math.min(1f, e.getHealth() / Math.max(1f, e.getMaxHealth())));
                return Ui.hsv(f * 0.33f, 0.9f, 1f) & 0xFFFFFF;
            }
        }
    }

    private static void marker(MinecraftClient mc, Camera cam, float td, double time, long now) {
        int lines = (int) Modules.MARKER.num("lines");
        for (int li = 0; li < lines; li++) markerOne(mc, cam, td, time, now, 1.0 - 0.16 * li, li == 0);
    }

    private static void markerOne(MinecraftClient mc, Camera cam, float td, double time, long now, double ls, boolean first) {
        Module m = Modules.MARKER;
        LivingEntity e = target(mc, m.mode("who"));
        if (e == null) return;
        Vec3d pos = e.getLerpedPos(td);
        double[] yf = {0.65, 0.95, 0.12, 0.5};
        double cx = pos.x, cy = pos.y + e.getHeight() * yf[m.mode("pos")], cz = pos.z;
        Quaternionf rq = cam.getRotation();
        Vector3f R = new Vector3f(1, 0, 0).rotate(rq), U = new Vector3f(0, 1, 0).rotate(rq);

        double r = m.num("size") * 0.5 * ls;
        if (m.bool("scale")) {
            double dx = cx - camX, dy = cy - camY, dz = cz - camZ;
            r *= Math.max(0.6, Math.min(2.0, Math.sqrt(dx * dx + dy * dy + dz * dz) / 6.0));
        }
        if (m.bool("pulse")) r *= 1 + 0.06 * Math.sin(time * 4);

        int col = markerColor(m, e, time);
        if (m.bool("hit") && e == lastTarget) {
            float k = (now - lastHitTime) / 300f;
            if (k < 1f) {
                float flash = 1f - k;
                r *= 1 - 0.25 * flash;
                col = Ui.mix(0xFF000000 | col, 0xFFFFFFFF, flash * 0.7f) & 0xFFFFFF;
            }
        }
        double am = 1;
        if (m.bool("breath")) am *= 0.7 + 0.3 * Math.sin(time * 2);
        if (m.bool("flick")) am *= 0.8 + 0.2 * Math.sin(time * 31);
        int op = (int) (m.num("op") * 2.55 * am);
        int fa = (int) (255 * (m.num("inner") / 100) * am);
        int ga = (int) (255 * m.num("glow") / 100.0 * 0.35 * am);
        double spd = m.num("spd");
        double ang = m.bool("rot") ? time * spd * 2 : 0;
        int c = Ui.withA(col, op), cg = Ui.withA(col, ga), cf = Ui.withA(col, fa);
        double w = r * 0.13 * m.num("thick");
        int shape = m.mode("shape");

        switch (shape) {
            case 0 -> { // скобки
                polyFanR(cx, cy, cz, R, U, CIRC24, r * 0.55, 0, cf);
                polyFanR(cx, cy, cz, R, U, CIRC24, r * 0.8, 0, Ui.withA(col, fa / 3));
                for (int k = 0; k < 4; k++)
                    arc(cx, cy, cz, R, U, r, ang + k * Math.PI / 2 + Math.PI / 4 - 0.5, 1.0, 8, w, c, cg);
            }
            case 1 -> { // двойное кольцо
                polyFanR(cx, cy, cz, R, U, CIRC24, r * 0.4, 0, cf);
                arc(cx, cy, cz, R, U, r, ang, Math.PI * 1.5, 24, w, c, cg);
                arc(cx, cy, cz, R, U, r * 0.68, -ang * 1.4, Math.PI * 1.5, 20, w * 0.8, c, cg);
            }
            case 2 -> { polyFanR(cx, cy, cz, R, U, SQUARE, r * 0.85, ang, cf); outline(cx, cy, cz, R, U, SQUARE, r, ang, w, c, cg); }
            case 3 -> { polyFanR(cx, cy, cz, R, U, DIAMOND, r * 0.85, ang, cf); outline(cx, cy, cz, R, U, DIAMOND, r, ang, w, c, cg); }
            case 4 -> { polyFanR(cx, cy, cz, R, U, STAR5, r * 0.95, ang, cf); outline(cx, cy, cz, R, U, STAR5, r * 1.1, ang, w, c, cg); }
            case 5 -> { // прицел
                arc(cx, cy, cz, R, U, r * 0.55, 0, Math.PI * 2, 28, w * 0.6, c, cg);
                for (int k = 0; k < 4; k++) {
                    double a = ang + k * Math.PI / 2;
                    l2(cx, cy, cz, R, U, Math.cos(a) * r * 0.7, Math.sin(a) * r * 0.7, Math.cos(a) * r * 1.1, Math.sin(a) * r * 1.1, w, c);
                }
                polyFanR(cx, cy, cz, R, U, CIRC24, r * 0.1, 0, c);
            }
            case 6 -> { // три треугольника по кругу
                for (int k = 0; k < 3; k++) {
                    double a = ang + k * Math.PI * 2 / 3;
                    double ox = Math.cos(a) * r * 0.7, oy = Math.sin(a) * r * 0.7;
                    double px = cx + R.x * ox + U.x * oy, py = cy + R.y * ox + U.y * oy, pz = cz + R.z * ox + U.z * oy;
                    polyFanR(px, py, pz, R, U, TRI, r * 0.3, -ang * 2, cf);
                    outline(px, py, pz, R, U, TRI, r * 0.38, -ang * 2, w * 0.8, c, cg);
                }
            }
            case 7 -> { polyFanR(cx, cy, cz, R, U, HEX, r * 0.85, ang, cf); outline(cx, cy, cz, R, U, HEX, r, ang, w, c, cg); }
            case 8 -> { polyFanR(cx, cy, cz, R, U, HEART, r * 0.85, 0, cf); outline(cx, cy, cz, R, U, HEART, r * 0.95, 0, w, c, cg); }
            case 9 -> { // расходящиеся волны
                for (int k = 0; k < 3; k++) {
                    double t = (time * Math.max(0.2, spd) * 0.6 + k / 3.0) % 1.0;
                    int ck = Ui.withA(col, (int) (op * (1 - t))), cgk = Ui.withA(col, (int) (ga * (1 - t)));
                    arc(cx, cy, cz, R, U, r * (0.2 + 0.9 * t), 0, Math.PI * 2, 32, w * (1 - t * 0.5), ck, cgk);
                }
            }
            case 10 -> polyFanR(cx, cy, cz, R, U, CIRC24, r * 0.25, 0, cf); // только кристаллы
            default -> { // орбита светящихся точек
                arc(cx, cy, cz, R, U, r, 0, Math.PI * 2, 32, w * 0.4, Ui.withA(col, op / 3), 0);
                for (int k = 0; k < 8; k++) {
                    double a = ang * 1.5 + k * Math.PI / 4;
                    double ox = Math.cos(a) * r, oy = Math.sin(a) * r;
                    double px = cx + R.x * ox + U.x * oy, py = cy + R.y * ox + U.y * oy, pz = cz + R.z * ox + U.z * oy;
                    polyFanR(px, py, pz, R, U, LOW, r * 0.09, 0, c);
                    polyFanR(px, py, pz, R, U, LOW, r * 0.2, 0, cg);
                }
            }
        }

        if (first && (m.bool("crystals") || shape == 10)) {
            int cn = (int) m.num("cn");
            double cs = m.num("cs"), ro = r * 1.35 + 0.15;
            for (int k = 0; k < cn; k++) {
                double a = time * 1.6 * Math.max(0.3, spd) + k * Math.PI * 2 / cn;
                double px = cx + Math.cos(a) * ro, pz = cz + Math.sin(a) * ro;
                double py = cy + Math.sin(time * 2 + k * 1.7) * 0.18;
                polyFanR(px, py, pz, R, U, CRYSTAL, cs * 2.0, 0, Ui.withA(col, ga / 2));
                polyFanR(px, py, pz, R, U, CRYSTAL, cs, 0, c);
                polyFanR(px, py, pz, R, U, CRYSTAL, cs * 0.45, 0, Ui.withA(0xFFFFFF, 170));
            }
        }
    }

    // ================= Shortcut: Zoom и Freelook =================
    private static boolean keyActive(net.minecraft.client.option.KeyBinding k, int mode, boolean[] toggled, int idx) {
        if (mode == 0) return k.isPressed();
        while (k.wasPressed()) toggled[idx] = !toggled[idx];
        return toggled[idx];
    }

    private static final boolean[] TG = new boolean[2];

    private static void tickShortcuts(MinecraftClient mc) {
        Module z = Modules.ZOOM, f = Modules.FREELOOK;
        boolean free = mc.currentScreen == null && mc.player != null;

        zoomActive = z.enabled && free && keyActive(UmearClient.ZOOM_KEY, z.mode("kmode"), TG, 0);
        if (zoomActive && z.bool("cine")) {
            if (!cineSet) { cinePrev = mc.options.smoothCameraEnabled; mc.options.smoothCameraEnabled = true; cineSet = true; }
        } else if (cineSet) { mc.options.smoothCameraEnabled = cinePrev; cineSet = false; }

        boolean want = f.enabled && free && keyActive(UmearClient.FREE_KEY, f.mode("kmode"), TG, 1);
        if (want && !flActive) {
            flYaw = mc.player.getYaw();
            flPitch = mc.player.getPitch();
            if (f.bool("third")) {
                flPrev = mc.options.getPerspective();
                mc.options.setPerspective(net.minecraft.client.option.Perspective.THIRD_PERSON_BACK);
                flPrevSet = true;
            }
        } else if (!want && flActive && flPrevSet) {
            mc.options.setPerspective(flPrev);
            flPrevSet = false;
        }
        flActive = want;
    }

    public static boolean freelookActive() { return flActive && Modules.FREELOOK != null && Modules.FREELOOK.enabled; }

    public static void freelookMove(double dx, double dy) {
        float k = 0.15f * (float) Modules.FREELOOK.num("sens");
        flYaw += (float) dx * k;
        flPitch = Math.max(-90f, Math.min(90f, flPitch + (float) dy * k));
    }

    /** Множитель приближения для проекции (1 = без зума). */
    public static float zoomFactor() {
        Module z = Modules.ZOOM;
        if (z == null) return 1f;
        long n = System.nanoTime();
        float dt = Math.min(0.1f, (n - zLast) / 1e9f);
        if (dt > 0.002f) {
            zLast = n;
            float tgt = z.enabled && zoomActive ? (float) z.num("lvl") : 1f;
            zoomCur += (tgt - zoomCur) * Math.min(1f, dt * (z.bool("smooth") ? 12f : 100f));
        }
        return zoomCur;
    }

    public static boolean zoomScroll(double v) {
        Module z = Modules.ZOOM;
        if (!z.enabled || !zoomActive || !z.bool("wheel") || v == 0) return false;
        Setting s = z.get("lvl");
        s.val = Math.max(s.min, Math.min(s.max, s.val + (v > 0 ? 0.5 : -0.5)));
        return true;
    }

    // ================= Full Bright =================
    private static boolean fbSet;

    private static void tickFullBright(ClientPlayerEntity p) {
        if (Modules.FULLBRIGHT.enabled) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
            fbSet = true;
        } else if (fbSet) {
            p.removeStatusEffect(StatusEffects.NIGHT_VISION);
            fbSet = false;
        }
    }

    // ================= Block Overlay =================
    private static void faceQuad(Box b, Direction d, int c) {
        double x1 = b.minX, y1 = b.minY, z1 = b.minZ, x2 = b.maxX, y2 = b.maxY, z2 = b.maxZ;
        switch (d) {
            case UP -> { G.v(x1, y2, z1, c); G.v(x1, y2, z2, c); G.v(x2, y2, z2, c); G.v(x2, y2, z1, c); }
            case DOWN -> { G.v(x1, y1, z1, c); G.v(x2, y1, z1, c); G.v(x2, y1, z2, c); G.v(x1, y1, z2, c); }
            case NORTH -> { G.v(x1, y1, z1, c); G.v(x1, y2, z1, c); G.v(x2, y2, z1, c); G.v(x2, y1, z1, c); }
            case SOUTH -> { G.v(x1, y1, z2, c); G.v(x2, y1, z2, c); G.v(x2, y2, z2, c); G.v(x1, y2, z2, c); }
            case WEST -> { G.v(x1, y1, z1, c); G.v(x1, y1, z2, c); G.v(x1, y2, z2, c); G.v(x1, y2, z1, c); }
            default -> { G.v(x2, y1, z1, c); G.v(x2, y2, z1, c); G.v(x2, y2, z2, c); G.v(x2, y1, z2, c); }
        }
    }

    private static void faceEdges(Box b, Direction d, double w, int c) {
        double x1 = b.minX, y1 = b.minY, z1 = b.minZ, x2 = b.maxX, y2 = b.maxY, z2 = b.maxZ;
        switch (d.getAxis()) {
            case Y -> {
                double y = d == Direction.UP ? y2 : y1;
                G.line(x1, y, z1, x2, y, z1, w, c, c); G.line(x2, y, z1, x2, y, z2, w, c, c);
                G.line(x2, y, z2, x1, y, z2, w, c, c); G.line(x1, y, z2, x1, y, z1, w, c, c);
            }
            case Z -> {
                double z = d == Direction.SOUTH ? z2 : z1;
                G.line(x1, y1, z, x2, y1, z, w, c, c); G.line(x2, y1, z, x2, y2, z, w, c, c);
                G.line(x2, y2, z, x1, y2, z, w, c, c); G.line(x1, y2, z, x1, y1, z, w, c, c);
            }
            default -> {
                double x = d == Direction.EAST ? x2 : x1;
                G.line(x, y1, z1, x, y1, z2, w, c, c); G.line(x, y1, z2, x, y2, z2, w, c, c);
                G.line(x, y2, z2, x, y2, z1, w, c, c); G.line(x, y2, z1, x, y1, z1, w, c, c);
            }
        }
    }

    private static void blockOverlay(MinecraftClient mc, double time) {
        Module m = Modules.BLOCKOV;
        HitResult hr = mc.crosshairTarget;
        if (!(hr instanceof net.minecraft.util.hit.BlockHitResult bh) || hr.getType() != HitResult.Type.BLOCK) return;
        BlockPos bp = bh.getBlockPos();
        var shape = mc.world.getBlockState(bp).getOutlineShape(mc.world, bp);
        Box box = (shape.isEmpty() ? new Box(bp) : shape.getBoundingBox().offset(bp)).expand(0.002);
        int col = accentColor(m, time, 0);
        double pm = m.bool("pulse") ? 0.7 + 0.3 * Math.sin(time * 4) : 1.0;
        int cf = Ui.withA(col, (int) (255 * m.num("fill") / 100.0 * pm));
        int co = Ui.withA(col, (int) (255 * m.num("op") / 100.0));
        double w = m.num("thick") * 0.006;
        switch (m.mode("mode")) {
            case 0 -> { faceQuad(box, bh.getSide(), cf); faceEdges(box, bh.getSide(), w, co); }
            case 1 -> { G.fillBox(box, cf); G.edges(box, w, co); }
            default -> G.edges(box, w, co);
        }
    }

    // ================= Музыка главного меню (у каждого фона своя) =================
    private static SoundInstance menuMusic;
    private static int menuTrack = -1;

    private static void tickMenuMusic(MinecraftClient mc) {
        Module t = Modules.TITLE;
        var sm = mc.getSoundManager();
        if (sm == null) return;
        boolean want = t != null && t.enabled && t.bool("music") && mc.world == null && mc.currentScreen != null;
        if (want) {
            int idx = UmearTitleScreen.currentBg();
            mc.getMusicTracker().stop();                       // ванильную музыку меню гасим
            if (menuMusic != null && idx != menuTrack) { sm.stop(menuMusic); menuMusic = null; }
            if (menuMusic == null || !sm.isPlaying(menuMusic)) {
                menuTrack = idx;
                menuMusic = PositionedSoundInstance.music(SoundEvent.of(Identifier.of("umear", "menu_music_" + idx)));
                sm.play(menuMusic);
            }
        } else if (menuMusic != null) {
            sm.stop(menuMusic);
            menuMusic = null;
        }
    }
}
