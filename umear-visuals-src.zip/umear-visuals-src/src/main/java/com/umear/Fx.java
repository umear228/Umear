package com.umear;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.*;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import com.umear.mixin.OverlayTextureAccessor;

import java.util.ArrayList;
import java.util.Random;

public final class Fx {
    private static final Random RND = new Random();
    private static LivingEntity lastTarget;
    private static long lastTargetTime;
    private static int prevHurt;
    private static int appliedHit = -1;
    private static final ArrayList<double[]> TRAIL = new ArrayList<>();
    private static final ArrayList<P> PARTS = new ArrayList<>();

    private static final class P {
        double x, y, z, vx, vy, vz;
        int life, max, color, shape;
        float size;
    }

    // ================= события =================
    public static ActionResult attack(PlayerEntity p, World w, Hand h, Entity e, EntityHitResult hit) {
        if (!w.isClient || !(e instanceof LivingEntity le)) return ActionResult.PASS;
        long now = System.currentTimeMillis();
        Vec3d eye = p.getEyePos();
        Box b = e.getBoundingBox();
        double dx = Math.max(Math.max(b.minX - eye.x, 0), eye.x - b.maxX);
        double dy = Math.max(Math.max(b.minY - eye.y, 0), eye.y - b.maxY);
        double dz = Math.max(Math.max(b.minZ - eye.z, 0), eye.z - b.maxZ);
        Modules.reach = Math.sqrt(dx * dx + dy * dy + dz * dz);
        Modules.combo++;
        Modules.lastHit = now;
        lastTarget = le;
        lastTargetTime = now;
        if (Modules.HITSOUND.enabled)
            play(Modules.HITSOUND.mode("snd"), (float) Modules.HITSOUND.num("vol") / 100f,
                    (float) Modules.HITSOUND.num("pitch") / 100f);
        return ActionResult.PASS;
    }

    public static void tick(MinecraftClient mc) {
        Modules.ticks++;
        while (UmearClient.OPEN.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new UmearScreen());
        }
        syncHitColor(mc);
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) { TRAIL.clear(); PARTS.clear(); return; }

        Module info = Modules.INFO;
        if (Modules.combo > 0) {
            if (System.currentTimeMillis() - Modules.lastHit > info.num("to") * 1000) Modules.combo = 0;
            if (info.bool("rst") && p.hurtTime > prevHurt) Modules.combo = 0;
        }
        prevHurt = p.hurtTime;

        tickTrail(p);
        tickParticles(mc, p);
    }

    // ================= звук =================
    public static void play(int idx, float vol, float pitch) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getSoundManager() == null) return;
        SoundInstance s = switch (idx) {
            case 1 -> PositionedSoundInstance.master(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, pitch, vol);
            case 2 -> PositionedSoundInstance.master(SoundEvents.BLOCK_NOTE_BLOCK_BELL, pitch, vol);
            case 3 -> PositionedSoundInstance.master(SoundEvents.ENTITY_ARROW_HIT_PLAYER, pitch, vol);
            default -> PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, pitch, vol);
        };
        mc.getSoundManager().play(s);
    }

    public static void uiClick() {
        Module c = Modules.CSOUND;
        if (c.enabled && c.bool("ui")) play(c.mode("snd"), (float) c.num("vol") / 100f, 1f);
    }

    // ================= Hit Color =================
    private static void syncHitColor(MinecraftClient mc) {
        if (mc.gameRenderer == null) return;
        Module m = Modules.HITCOLOR;
        int want = m.enabled ? (((int) (m.num("op") * 2.55) & 255) << 24) | m.get("col").color : 0;
        if (want == appliedHit) return;
        try {
            NativeImageBackedTexture tex = ((OverlayTextureAccessor) mc.gameRenderer.getOverlayTexture()).umear$getTexture();
            NativeImage img = tex.getImage();
            if (img == null) return;
            int argb = want == 0 ? 0xB2FF0000 : want;
            for (int y = 0; y < 8; y++) for (int x = 0; x < 16; x++) img.setColorArgb(x, y, argb);
            tex.upload();
            appliedHit = want;
        } catch (Throwable ignored) { appliedHit = want; }
    }

    // ================= цель =================
    private static boolean okWho(LivingEntity e, int who) {
        return who == 0 || (who == 1) == (e instanceof PlayerEntity);
    }

    /** Враг строго под прицелом (для Dynamic Crosshair). */
    public static boolean crossTarget(MinecraftClient mc, int who) {
        HitResult hr = mc.crosshairTarget;
        return hr instanceof EntityHitResult eh && eh.getEntity() instanceof LivingEntity le
                && le != mc.player && okWho(le, who);
    }

    /** Цель для ESP: под прицелом либо последняя атакованная (3 с). */
    private static LivingEntity espTarget(MinecraftClient mc, int who) {
        long now = System.currentTimeMillis();
        HitResult hr = mc.crosshairTarget;
        if (hr instanceof EntityHitResult eh && eh.getEntity() instanceof LivingEntity le
                && le != mc.player && okWho(le, who)) {
            lastTarget = le; lastTargetTime = now;
            return le;
        }
        if (lastTarget != null && lastTarget.isAlive() && !lastTarget.isRemoved()
                && now - lastTargetTime < 3000 && okWho(lastTarget, who)) return lastTarget;
        return null;
    }

    // ================= следы / частицы =================
    private static void tickTrail(ClientPlayerEntity p) {
        if (!Modules.TRAILS.enabled) { TRAIL.clear(); return; }
        int max = (int) Modules.TRAILS.num("len");
        double[] last = TRAIL.isEmpty() ? null : TRAIL.get(TRAIL.size() - 1);
        if (last == null || p.squaredDistanceTo(last[0], last[1], last[2]) > 0.0004)
            TRAIL.add(new double[]{p.getX(), p.getY(), p.getZ()});
        else if ((Modules.ticks & 1) == 0 && !TRAIL.isEmpty()) TRAIL.remove(0);
        while (TRAIL.size() > max) TRAIL.remove(0);
    }

    private static void tickParticles(MinecraftClient mc, ClientPlayerEntity p) {
        for (int i = PARTS.size() - 1; i >= 0; i--) {
            P q = PARTS.get(i);
            q.x += q.vx; q.y += q.vy; q.z += q.vz;
            if (--q.life <= 0) PARTS.remove(i);
        }
        Module m = Modules.PARTICLES;
        if (!m.enabled) { PARTS.clear(); return; }
        int n = (int) m.num("n");
        double r = m.num("r"), spd = m.num("spd");
        boolean custom = m.mode("src") == 1;
        ParticleEffect type = switch (m.mode("type")) {
            case 1 -> ParticleTypes.HEART;
            case 2 -> ParticleTypes.END_ROD;
            case 3 -> ParticleTypes.CRIT;
            case 4 -> ParticleTypes.SNOWFLAKE;
            default -> ParticleTypes.FLAME;
        };
        for (int i = 0; i < n; i++) {
            double a = RND.nextDouble() * Math.PI * 2, d = Math.sqrt(RND.nextDouble()) * r;
            double x = p.getX() + Math.cos(a) * d, y = p.getY() + RND.nextDouble() * p.getHeight(), z = p.getZ() + Math.sin(a) * d;
            if (custom) {
                if (PARTS.size() > 400) break;
                P q = new P();
                q.x = x; q.y = y; q.z = z;
                q.vx = (RND.nextDouble() - 0.5) * 0.02 * spd;
                q.vy = (0.01 + RND.nextDouble() * 0.02) * spd;
                q.vz = (RND.nextDouble() - 0.5) * 0.02 * spd;
                q.max = q.life = (int) m.num("life");
                q.size = (float) m.num("size");
                q.shape = m.mode("shape");
                q.color = m.bool("rb") ? Ui.hsv(RND.nextFloat(), 0.7f, 1f) & 0xFFFFFF : m.get("col").color;
                PARTS.add(q);
            } else {
                mc.world.addParticle(type, x, y, z, 0, 0.02 * spd, 0);
            }
        }
    }

    // ================= рендер в мире =================
    private static final class G {
        static BufferBuilder b;
        static Matrix4f m;
        static double cx, cy, cz;
        static int n;

        static void v(double x, double y, double z, int c) {
            if (b == null) {
                b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
                n = 0;
            }
            b.vertex(m, (float) (x - cx), (float) (y - cy), (float) (z - cz)).color(c);
            n++;
        }

        static void tri(double x1, double y1, double z1, int c1, double x2, double y2, double z2, int c2,
                        double x3, double y3, double z3, int c3) {
            v(x1, y1, z1, c1); v(x2, y2, z2, c2); v(x3, y3, z3, c3); v(x3, y3, z3, c3);
        }

        static void line(double x1, double y1, double z1, double x2, double y2, double z2, double w, int c1, int c2) {
            double dx = x2 - x1, dy = y2 - y1, dz = z2 - z1;
            double mx = (x1 + x2) / 2 - cx, my = (y1 + y2) / 2 - cy, mz = (z1 + z2) / 2 - cz;
            double sx = dy * mz - dz * my, sy = dz * mx - dx * mz, sz = dx * my - dy * mx;
            double l = Math.sqrt(sx * sx + sy * sy + sz * sz);
            if (l < 1e-9) return;
            double k = w / 2 / l;
            sx *= k; sy *= k; sz *= k;
            v(x1 + sx, y1 + sy, z1 + sz, c1); v(x1 - sx, y1 - sy, z1 - sz, c1);
            v(x2 - sx, y2 - sy, z2 - sz, c2); v(x2 + sx, y2 + sy, z2 + sz, c2);
        }

        static void flush() {
            if (b != null) {
                if (n > 0) BufferRenderer.drawWithGlobalProgram(b.end());
                b = null;
            }
        }

        static void fillBox(Box bb, int c) {
            double x1 = bb.minX, y1 = bb.minY, z1 = bb.minZ, x2 = bb.maxX, y2 = bb.maxY, z2 = bb.maxZ;
            v(x1, y1, z1, c); v(x2, y1, z1, c); v(x2, y1, z2, c); v(x1, y1, z2, c);
            v(x1, y2, z1, c); v(x1, y2, z2, c); v(x2, y2, z2, c); v(x2, y2, z1, c);
            v(x1, y1, z1, c); v(x1, y2, z1, c); v(x2, y2, z1, c); v(x2, y1, z1, c);
            v(x1, y1, z2, c); v(x2, y1, z2, c); v(x2, y2, z2, c); v(x1, y2, z2, c);
            v(x1, y1, z1, c); v(x1, y1, z2, c); v(x1, y2, z2, c); v(x1, y2, z1, c);
            v(x2, y1, z1, c); v(x2, y2, z1, c); v(x2, y2, z2, c); v(x2, y1, z2, c);
        }

        static void edges(Box bb, double w, int c) {
            double x1 = bb.minX, y1 = bb.minY, z1 = bb.minZ, x2 = bb.maxX, y2 = bb.maxY, z2 = bb.maxZ;
            line(x1, y1, z1, x2, y1, z1, w, c, c); line(x1, y1, z2, x2, y1, z2, w, c, c);
            line(x1, y2, z1, x2, y2, z1, w, c, c); line(x1, y2, z2, x2, y2, z2, w, c, c);
            line(x1, y1, z1, x1, y2, z1, w, c, c); line(x2, y1, z1, x2, y2, z1, w, c, c);
            line(x1, y1, z2, x1, y2, z2, w, c, c); line(x2, y1, z2, x2, y2, z2, w, c, c);
            line(x1, y1, z1, x1, y1, z2, w, c, c); line(x2, y1, z1, x2, y1, z2, w, c, c);
            line(x1, y2, z1, x1, y2, z2, w, c, c); line(x2, y2, z1, x2, y2, z2, w, c, c);
        }
    }

    private static final int SEG = 40;

    private static void ring(double x, double y, double z, double r, double w, int alpha, double time, boolean grad) {
        Module m = Modules.ESP;
        for (int i = 0; i < SEG; i++) {
            double a1 = Math.PI * 2 * i / SEG, a2 = Math.PI * 2 * (i + 1) / SEG;
            int c = Ui.withA(espColor(m, time, grad ? (float) i / SEG : 0f), alpha);
            G.line(x + Math.cos(a1) * r, y, z + Math.sin(a1) * r, x + Math.cos(a2) * r, y, z + Math.sin(a2) * r, w, c, c);
        }
    }

    private static void disk(double x, double y, double z, double r, int c) {
        for (int i = 0; i < SEG; i++) {
            double a1 = Math.PI * 2 * i / SEG, a2 = Math.PI * 2 * (i + 1) / SEG;
            G.tri(x, y, z, c, x + Math.cos(a1) * r, y, z + Math.sin(a1) * r, c,
                    x + Math.cos(a2) * r, y, z + Math.sin(a2) * r, c);
        }
    }

    private static int espColor(Module m, double time, float off) {
        int cm = m.mode("cm");
        if (cm == 0) return m.get("col").color;
        if (cm == 1) return Ui.hsv((float) ((time * 0.15 * m.num("spd") + off) % 1.0), 0.75f, 1f) & 0xFFFFFF;
        float k = (float) (0.5 + 0.5 * Math.sin(time * m.num("spd") * 2 + off * Math.PI * 2));
        return Ui.mix(0xFF000000 | m.get("col").color, 0xFF000000 | m.get("col2").color, k) & 0xFFFFFF;
    }

    private static final float[][] SHAPES = {circle(16), star(5, 0.45f), heart(24), star(6, 0.3f)};

    private static float[] circle(int n) {
        float[] o = new float[n * 2];
        for (int i = 0; i < n; i++) { double a = Math.PI * 2 * i / n; o[i * 2] = (float) Math.cos(a); o[i * 2 + 1] = (float) Math.sin(a); }
        return o;
    }

    private static float[] star(int pts, float inner) {
        int n = pts * 2;
        float[] o = new float[n * 2];
        for (int i = 0; i < n; i++) {
            double a = Math.PI / 2 + Math.PI * 2 * i / n;
            float r = (i & 1) == 0 ? 1f : inner;
            o[i * 2] = (float) (Math.cos(a) * r); o[i * 2 + 1] = (float) (Math.sin(a) * r);
        }
        return o;
    }

    private static float[] heart(int n) {
        float[] o = new float[n * 2];
        for (int i = 0; i < n; i++) {
            double t = Math.PI * 2 * i / n;
            o[i * 2] = (float) (16 * Math.pow(Math.sin(t), 3) / 17);
            o[i * 2 + 1] = (float) ((13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)) / 17);
        }
        return o;
    }

    public static void world(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;
        boolean any = Modules.HAT.enabled || Modules.TRAILS.enabled || Modules.ESP.enabled || !PARTS.isEmpty();
        if (!any) return;
        var ms = ctx.matrixStack();
        if (ms == null) return;
        Camera cam = ctx.camera();
        float td = ctx.tickCounter().getTickProgress(false);
        Vec3d cp = cam.getPos();
        G.m = ms.peek().getPositionMatrix();
        G.cx = cp.x; G.cy = cp.y; G.cz = cp.z;
        double time = (System.currentTimeMillis() % 1000000L) / 1000.0;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        Vec3d pos = p.getLerpedPos(td);

        if (Modules.HAT.enabled && cam.isThirdPerson()) hat(p, pos, time);
        G.flush();
        if (Modules.TRAILS.enabled) trail(p, pos, time);
        G.flush();
        if (!PARTS.isEmpty()) particles(cam, td);
        G.flush();

        if (Modules.ESP.enabled) {
            RenderSystem.disableDepthTest();
            esp(mc, td, time);
            G.flush();
        }

        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    private static void hat(ClientPlayerEntity p, Vec3d pos, double time) {
        Module m = Modules.HAT;
        double top = pos.y + p.getHeight() + 0.02, h = m.num("h"), r = m.num("r");
        int op = (int) (m.num("op") * 2.55);
        int segs = 36;
        for (int i = 0; i < segs; i++) {
            double a1 = Math.PI * 2 * i / segs, a2 = Math.PI * 2 * (i + 1) / segs;
            int col = m.bool("rb") ? Ui.hsv((float) ((double) i / segs + time * 0.2), 0.7f, 1f) & 0xFFFFFF : m.get("col").color;
            int c = Ui.withA(col, op), cs = Ui.withA(col, 255);
            double x1 = pos.x + Math.cos(a1) * r, z1 = pos.z + Math.sin(a1) * r;
            double x2 = pos.x + Math.cos(a2) * r, z2 = pos.z + Math.sin(a2) * r;
            G.tri(pos.x, top + h, pos.z, Ui.withA(col, Math.min(255, op + 60)), x1, top, z1, c, x2, top, z2, c);
            G.line(x1, top, z1, x2, top, z2, 0.025, cs, cs);
        }
    }

    private static void trail(ClientPlayerEntity p, Vec3d pos, double time) {
        Module m = Modules.TRAILS;
        int n = TRAIL.size();
        if (n < 1) return;
        int st = m.mode("st"), op = (int) (m.num("op") * 2.55);
        double h = st == 1 ? 0.6 : st == 2 ? p.getHeight() : 0;
        for (int i = 0; i < n; i++) {
            double[] a = TRAIL.get(i);
            double[] b = i + 1 < n ? TRAIL.get(i + 1) : new double[]{pos.x, pos.y, pos.z};
            int col = m.bool("rb") ? Ui.hsv((float) (i * 0.02 + time * 0.25), 0.7f, 1f) & 0xFFFFFF : m.get("col").color;
            int ca = Ui.withA(col, op * (i + 1) / (n + 1)), cb = Ui.withA(col, op * (i + 2) / (n + 1));
            if (st == 0) {
                G.line(a[0], a[1] + 0.1, a[2], b[0], b[1] + 0.1, b[2], 0.07, ca, cb);
            } else {
                G.v(a[0], a[1] + 0.1, a[2], ca); G.v(a[0], a[1] + 0.1 + h, a[2], ca);
                G.v(b[0], b[1] + 0.1 + h, b[2], cb); G.v(b[0], b[1] + 0.1, b[2], cb);
            }
        }
    }

    private static void particles(Camera cam, float td) {
        Quaternionf rot = cam.getRotation();
        Vector3f right = new Vector3f(1, 0, 0).rotate(rot), up = new Vector3f(0, 1, 0).rotate(rot);
        for (P q : PARTS) {
            float fade = Math.min(1f, q.life / (q.max * 0.4f));
            int c = Ui.withA(q.color, (int) (255 * fade));
            float[] sh = SHAPES[Math.min(q.shape, 3)];
            float s = q.size * (0.6f + 0.4f * fade);
            double cx = q.x + q.vx * td, cy = q.y + q.vy * td, cz = q.z + q.vz * td;
            int n = sh.length / 2;
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                double ax = (right.x * sh[i * 2] + up.x * sh[i * 2 + 1]) * s, ay = (right.y * sh[i * 2] + up.y * sh[i * 2 + 1]) * s, az = (right.z * sh[i * 2] + up.z * sh[i * 2 + 1]) * s;
                double bx = (right.x * sh[j * 2] + up.x * sh[j * 2 + 1]) * s, by = (right.y * sh[j * 2] + up.y * sh[j * 2 + 1]) * s, bz = (right.z * sh[j * 2] + up.z * sh[j * 2 + 1]) * s;
                G.tri(cx, cy, cz, c, cx + ax, cy + ay, cz + az, c, cx + bx, cy + by, cz + bz, c);
            }
        }
    }

    private static void esp(MinecraftClient mc, float td, double time) {
        Module m = Modules.ESP;
        LivingEntity e = espTarget(mc, m.mode("who"));
        if (e == null) return;
        Vec3d pos = e.getLerpedPos(td);
        Box bb = e.getBoundingBox().offset(pos.x - e.getX(), pos.y - e.getY(), pos.z - e.getZ());
        double w = m.num("thick") * 0.008;
        int op = (int) (m.num("op") * 2.55);
        int fa = (int) (255 * (m.num("fill") / 100) * (m.num("op") / 100));
        int base = espColor(m, time, 0f);
        double rad = e.getWidth() * 0.5 + 0.3;
        switch (m.mode("mode")) {
            case 0 -> { G.fillBox(bb, Ui.withA(base, fa)); G.edges(bb, w, Ui.withA(base, op)); }
            case 1 -> G.edges(bb, w, Ui.withA(base, op));
            case 2 -> {
                disk(pos.x, bb.minY + 0.03, pos.z, rad, Ui.withA(base, fa));
                ring(pos.x, bb.minY + 0.03, pos.z, rad, w * 2, op, time, true);
            }
            case 3 -> {
                double k = 0.5 + 0.5 * Math.sin(time * m.num("spd") * 2);
                double y = bb.minY + k * bb.getLengthY();
                ring(pos.x, y, pos.z, rad - 0.05, w * 2, op, time, true);
                ring(pos.x, y + (k > 0.5 ? -0.12 : 0.12), pos.z, rad - 0.05, w, op / 3, time, true);
            }
            default -> {
                double y = bb.maxY + 0.15;
                disk(pos.x, y, pos.z, 0.32, Ui.withA(base, fa));
                ring(pos.x, y, pos.z, 0.32, w * 2.5, op, time, true);
            }
        }
    }
}
