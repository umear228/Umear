package com.umear;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.*;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import com.umear.mixin.OverlayTextureAccessor;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

public final class Fx {
    private static final Random RND = new Random();
    private static LivingEntity lastTarget;
    private static long lastTargetTime;
    private static int prevHurt;
    private static int appliedHit = -1;
    private static final ArrayList<double[]> TRAIL = new ArrayList<>();
    private static final ArrayList<P> PARTS = new ArrayList<>();

    private static final class P {
        double x, y, z, vx, vy, vz;
        int life, max, color, color2 = -1, shape;
        float size, grav, drag = 1f;
        boolean glow;
    }

    public static final class Num {
        public double x, y, z;
        public String s;
        public long born;
        public boolean crit;
    }

    private static final ArrayList<P> GP = new ArrayList<>();              // Glow + Hit Burst
    public static final ArrayList<Num> NUMS = new ArrayList<>();           // Damage Numbers
    private static final ArrayList<double[]> SLASH = new ArrayList<>();    // x,y,z,born,start
    private static final ArrayList<double[]> RINGS = new ArrayList<>();    // x,y,z,born
    private static LivingEntity dmgTarget;
    private static float dmgHp;
    private static long dmgTick;
    private static float lastSwing = -1f;
    private static boolean slashFlip, sprintForced;
    public static boolean sprintToggled;
    private static final Matrix4f VP = new Matrix4f();
    private static double camX, camY, camZ;
    private static boolean vpValid;
    private static final float[] PROJ = new float[2];

    // ================= события =================
    public static ActionResult attack(PlayerEntity p, World w, Hand h, Entity e, EntityHitResult hit) {
        if (!w.isClient || !(e instanceof LivingEntity le)) return ActionResult.PASS;
        long now = System.currentTimeMillis();
        Vec3d eye = p.getEyePos();
        Box b = e.getBoundingBox();
        double dx = Math.max(Math.max(b.minX - eye.x, 0), eye.x - b.maxX);
        double dy = Math.max(Math.max(b.minY - eye.y, 0), eye.y - b.maxY);
        double dz = Math.max(Math.max(b.minZ - eye.z, 0), eye.z - b.maxZ);
        Modules.reach = Math.sqrt(dx * dx + dy * dy + dz * dz);
        Modules.combo++;
        Modules.lastHit = now;
        lastTarget = le;
        lastTargetTime = now;
        if (Modules.DMG.enabled) { dmgTarget = le; dmgHp = le.getHealth(); dmgTick = Modules.ticks; }
        if (Modules.BURST.enabled) burst(le);
        if (Modules.HITSOUND.enabled)
            play(Modules.HITSOUND.mode("snd"), (float) Modules.HITSOUND.num("vol") / 100f,
                    (float) Modules.HITSOUND.num("pitch") / 100f);
        return ActionResult.PASS;
    }

    public static void tick(MinecraftClient mc) {
        Modules.ticks++;
        while (UmearClient.OPEN.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new UmearScreen());
        }
        while (UmearClient.SPRINT_KEY.wasPressed()) sprintToggled = !sprintToggled;
        syncHitColor(mc);
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) {
            TRAIL.clear(); PARTS.clear(); GP.clear(); SLASH.clear(); RINGS.clear(); NUMS.clear();
            return;
        }

        Module info = Modules.INFO;
        if (Modules.combo > 0) {
            if (System.currentTimeMillis() - Modules.lastHit > info.num("to") * 1000) Modules.combo = 0;
            if (info.bool("rst") && p.hurtTime > prevHurt) Modules.combo = 0;
        }
        prevHurt = p.hurtTime;

        tickTrail(p);
        tickParticles(mc, p);
        tickGlow(p);
        tickDamage();
        tickSprint(mc);
    }

    // ================= звук =================
    public static void play(int idx, float vol, float pitch) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getSoundManager() == null) return;
        SoundInstance s = switch (idx) {
            case 1 -> PositionedSoundInstance.master(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, pitch, vol);
            case 2 -> PositionedSoundInstance.master(SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), pitch, vol);
            case 3 -> PositionedSoundInstance.master(SoundEvents.ENTITY_ARROW_HIT_PLAYER, pitch, vol);
            default -> PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK.value(), pitch, vol);
        };
        mc.getSoundManager().play(s);
    }

    public static void uiClick() {
        Module c = Modules.CSOUND;
        if (c.enabled && c.bool("ui")) play(c.mode("snd"), (float) c.num("vol") / 100f, 1f);
    }

    // ================= Hit Color =================
    private static void syncHitColor(MinecraftClient mc) {
        if (mc.gameRenderer == null) return;
        Module m = Modules.HITCOLOR;
        int want = m.enabled ? (((int) (m.num("op") * 2.55) & 255) << 24) | m.get("col").color : 0;
        if (want == appliedHit) return;
        try {
            NativeImageBackedTexture tex = ((OverlayTextureAccessor) mc.gameRenderer.getOverlayTexture()).umear$getTexture();
            NativeImage img = tex.getImage();
            if (img == null) return;
            int argb = want == 0 ? 0xB2FF0000 : want;
            for (int y = 0; y < 8; y++) for (int x = 0; x < 16; x++) img.setColorArgb(x, y, argb);
            tex.upload();
            appliedHit = want;
        } catch (Throwable ignored) { appliedHit = want; }
    }

    // ================= цель =================
    private static boolean okWho(LivingEntity e, int who) {
        return who == 0 || (who == 1) == (e instanceof PlayerEntity);
    }

    /** Враг строго под прицелом (для Dynamic Crosshair). */
    public static boolean crossTarget(MinecraftClient mc, int who) {
        HitResult hr = mc.crosshairTarget;
        return hr instanceof EntityHitResult eh && eh.getEntity() instanceof LivingEntity le
                && le != mc.player && okWho(le, who);
    }

    /** Цель для ESP: под прицелом либо последняя атакованная (3 с). */
    public static LivingEntity target(MinecraftClient mc, int who) {
        long now = System.currentTimeMillis();
        HitResult hr = mc.crosshairTarget;
        if (hr instanceof EntityHitResult eh && eh.getEntity() instanceof LivingEntity le
                && le != mc.player && okWho(le, who)) {
            lastTarget = le; lastTargetTime = now;
            return le;
        }
        if (lastTarget != null && lastTarget.isAlive() && !lastTarget.isRemoved()
                && now - lastTargetTime < 3000 && okWho(lastTarget, who)) return lastTarget;
        return null;
    }

    // ================= следы / частицы =================
    private static void tickTrail(ClientPlayerEntity p) {
        if (!Modules.TRAILS.enabled) { TRAIL.clear(); return; }
        int max = (int) Modules.TRAILS.num("len");
        double[] last = TRAIL.isEmpty() ? null : TRAIL.get(TRAIL.size() - 1);
        if (last == null || p.squaredDistanceTo(last[0], last[1], last[2]) > 0.0004)
            TRAIL.add(new double[]{p.getX(), p.getY(), p.getZ()});
        else if ((Modules.ticks & 1) == 0 && !TRAIL.isEmpty()) TRAIL.remove(0);
        while (TRAIL.size() > max) TRAIL.remove(0);
    }

    private static void tickParticles(MinecraftClient mc, ClientPlayerEntity p) {
        step(PARTS);
        step(GP);
        Module m = Modules.PARTICLES;
        if (!m.enabled) { PARTS.clear(); return; }
        int n = (int) m.num("n");
        double r = m.num("r"), spd = m.num("spd");
        boolean custom = m.mode("src") == 1;
        ParticleEffect type = switch (m.mode("type")) {
            case 1 -> ParticleTypes.HEART;
            case 2 -> ParticleTypes.END_ROD;
            case 3 -> ParticleTypes.CRIT;
            case 4 -> ParticleTypes.SNOWFLAKE;
            default -> ParticleTypes.FLAME;
        };
        for (int i = 0; i < n; i++) {
            double a = RND.nextDouble() * Math.PI * 2, d = Math.sqrt(RND.nextDouble()) * r;
            double x = p.getX() + Math.cos(a) * d, y = p.getY() + RND.nextDouble() * p.getHeight(), z = p.getZ() + Math.sin(a) * d;
            if (custom) {
                if (PARTS.size() > 400) break;
                P q = new P();
                q.x = x; q.y = y; q.z = z;
                q.vx = (RND.nextDouble() - 0.5) * 0.02 * spd;
                q.vy = (0.01 + RND.nextDouble() * 0.02) * spd;
                q.vz = (RND.nextDouble() - 0.5) * 0.02 * spd;
                q.max = q.life = (int) m.num("life");
                q.size = (float) m.num("size");
                q.shape = m.mode("shape");
                q.color = m.bool("rb") ? Ui.hsv(RND.nextFloat(), 0.7f, 1f) & 0xFFFFFF : m.get("col").color;
                PARTS.add(q);
            } else {
                mc.world.addParticle(type, x, y, z, 0, 0.02 * spd, 0);
            }
        }
    }

    // ================= рендер в мире =================
    private static final class G {
        static BufferBuilder b;
        static Matrix4f m;
        static double cx, cy, cz;
        static int n;

        static void v(double x, double y, double z, int c) {
            if (b == null) {
                b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
                n = 0;
            }
            b.vertex(m, (float) (x - cx), (float) (y - cy), (float) (z - cz)).color(c);
            n++;
        }

        static void tri(double x1, double y1, double z1, int c1, double x2, double y2, double z2, int c2,
                        double x3, double y3, double z3, int c3) {
            v(x1, y1, z1, c1); v(x2, y2, z2, c2); v(x3, y3, z3, c3); v(x3, y3, z3, c3);
        }

        static void line(double x1, double y1, double z1, double x2, double y2, double z2, double w, int c1, int c2) {
            double dx = x2 - x1, dy = y2 - y1, dz = z2 - z1;
            double mx = (x1 + x2) / 2 - cx, my = (y1 + y2) / 2 - cy, mz = (z1 + z2) / 2 - cz;
            double sx = dy * mz - dz * my, sy = dz * mx - dx * mz, sz = dx * my - dy * mx;
            double l = Math.sqrt(sx * sx + sy * sy + sz * sz);
            if (l < 1e-9) return;
            double k = w / 2 / l;
            sx *= k; sy *= k; sz *= k;
            v(x1 + sx, y1 + sy, z1 + sz, c1); v(x1 - sx, y1 - sy, z1 - sz, c1);
            v(x2 - sx, y2 - sy, z2 - sz, c2); v(x2 + sx, y2 + sy, z2 + sz, c2);
        }

        static void flush() {
            if (b != null) {
                if (n > 0) BufferRenderer.drawWithGlobalProgram(b.end());
                b = null;
            }
        }

        static void fillBox(Box bb, int c) {
            double x1 = bb.minX, y1 = bb.minY, z1 = bb.minZ, x2 = bb.maxX, y2 = bb.maxY, z2 = bb.maxZ;
            v(x1, y1, z1, c); v(x2, y1, z1, c); v(x2, y1, z2, c); v(x1, y1, z2, c);
            v(x1, y2, z1, c); v(x1, y2, z2, c); v(x2, y2, z2, c); v(x2, y2, z1, c);
            v(x1, y1, z1, c); v(x1, y2, z1, c); v(x2, y2, z1, c); v(x2, y1, z1, c);
            v(x1, y1, z2, c); v(x2, y1, z2, c); v(x2, y2, z2, c); v(x1, y2, z2, c);
            v(x1, y1, z1, c); v(x1, y1, z2, c); v(x1, y2, z2, c); v(x1, y2, z1, c);
            v(x2, y1, z1, c); v(x2, y2, z1, c); v(x2, y2, z2, c); v(x2, y1, z2, c);
        }

        static void edges(Box bb, double w, int c) {
            double x1 = bb.minX, y1 = bb.minY, z1 = bb.minZ, x2 = bb.maxX, y2 = bb.maxY, z2 = bb.maxZ;
            line(x1, y1, z1, x2, y1, z1, w, c, c); line(x1, y1, z2, x2, y1, z2, w, c, c);
            line(x1, y2, z1, x2, y2, z1, w, c, c); line(x1, y2, z2, x2, y2, z2, w, c, c);
            line(x1, y1, z1, x1, y2, z1, w, c, c); line(x2, y1, z1, x2, y2, z1, w, c, c);
            line(x1, y1, z2, x1, y2, z2, w, c, c); line(x2, y1, z2, x2, y2, z2, w, c, c);
            line(x1, y1, z1, x1, y1, z2, w, c, c); line(x2, y1, z1, x2, y1, z2, w, c, c);
            line(x1, y2, z1, x1, y2, z2, w, c, c); line(x2, y2, z1, x2, y2, z2, w, c, c);
        }
    }

    private static final int SEG = 40;

    private static void ring(double x, double y, double z, double r, double w, int alpha, double time, boolean grad) {
        Module m = Modules.ESP;
        for (int i = 0; i < SEG; i++) {
            double a1 = Math.PI * 2 * i / SEG, a2 = Math.PI * 2 * (i + 1) / SEG;
            int c = Ui.withA(espColor(m, time, grad ? (float) i / SEG : 0f), alpha);
            G.line(x + Math.cos(a1) * r, y, z + Math.sin(a1) * r, x + Math.cos(a2) * r, y, z + Math.sin(a2) * r, w, c, c);
        }
    }

    private static void disk(double x, double y, double z, double r, int c) {
        for (int i = 0; i < SEG; i++) {
            double a1 = Math.PI * 2 * i / SEG, a2 = Math.PI * 2 * (i + 1) / SEG;
            G.tri(x, y, z, c, x + Math.cos(a1) * r, y, z + Math.sin(a1) * r, c,
                    x + Math.cos(a2) * r, y, z + Math.sin(a2) * r, c);
        }
    }

    private static int espColor(Module m, double time, float off) {
        int cm = m.mode("cm");
        if (cm == 0) return m.get("col").color;
        if (cm == 1) return Ui.hsv((float) ((time * 0.15 * m.num("spd") + off) % 1.0), 0.75f, 1f) & 0xFFFFFF;
        float k = (float) (0.5 + 0.5 * Math.sin(time * m.num("spd") * 2 + off * Math.PI * 2));
        return Ui.mix(0xFF000000 | m.get("col").color, 0xFF000000 | m.get("col2").color, k) & 0xFFFFFF;
    }

    private static final float[][] SHAPES = {circle(16), star(5, 0.45f), heart(24), star(6, 0.3f)};

    private static float[] circle(int n) {
        float[] o = new float[n * 2];
        for (int i = 0; i < n; i++) { double a = Math.PI * 2 * i / n; o[i * 2] = (float) Math.cos(a); o[i * 2 + 1] = (float) Math.sin(a); }
        return o;
    }

    private static float[] star(int pts, float inner) {
        int n = pts * 2;
        float[] o = new float[n * 2];
        for (int i = 0; i < n; i++) {
            double a = Math.PI / 2 + Math.PI * 2 * i / n;
            float r = (i & 1) == 0 ? 1f : inner;
            o[i * 2] = (float) (Math.cos(a) * r); o[i * 2 + 1] = (float) (Math.sin(a) * r);
        }
        return o;
    }

    private static float[] heart(int n) {
        float[] o = new float[n * 2];
        for (int i = 0; i < n; i++) {
            double t = Math.PI * 2 * i / n;
            o[i * 2] = (float) (16 * Math.pow(Math.sin(t), 3) / 17);
            o[i * 2 + 1] = (float) ((13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)) / 17);
        }
        return o;
    }

    public static void world(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;
        boolean any = Modules.HAT.enabled || Modules.TRAILS.enabled || Modules.ESP.enabled || Modules.MARKER.enabled
                || Modules.SLASH.enabled || Modules.DMG.enabled || !PARTS.isEmpty() || !GP.isEmpty() || !RINGS.isEmpty();
        if (!any) return;
        var ms = ctx.matrixStack();
        if (ms == null) return;
        Camera cam = ctx.camera();
        float td = ctx.tickCounter().getTickDelta(false);
        Vec3d cp = cam.getPos();
        G.m = ms.peek().getPositionMatrix();
        G.cx = cp.x; G.cy = cp.y; G.cz = cp.z;
        camX = cp.x; camY = cp.y; camZ = cp.z;
        VP.set(ctx.projectionMatrix()).mul(G.m);
        vpValid = true;
        long now = System.currentTimeMillis();
        double time = (System.currentTimeMillis() % 1000000L) / 1000.0;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        Vec3d pos = p.getLerpedPos(td);

        if (Modules.HAT.enabled && cam.isThirdPerson()) hat(p, pos, time);
        G.flush();
        if (Modules.TRAILS.enabled) trail(p, pos, time);
        G.flush();
        drawParts(PARTS, cam, td, time);
        G.flush();
        drawParts(GP, cam, td, time);
        G.flush();
        if (Modules.SLASH.enabled) slash(p, td, now, time);
        else { SLASH.clear(); lastSwing = -1f; }
        G.flush();
        drawRings(now);
        G.flush();

        RenderSystem.disableDepthTest();
        if (Modules.ESP.enabled) {
            esp(mc, td, time);
            G.flush();
        }
        if (Modules.MARKER.enabled) {
            marker(mc, cam, td, time);
            G.flush();
        }

        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    private static void hat(ClientPlayerEntity p, Vec3d pos, double time) {
        Module m = Modules.HAT;
        double top = pos.y + p.getHeight() + 0.02, h = m.num("h"), r = m.num("r");
        int op = (int) (m.num("op") * 2.55);
        int segs = 36;
        for (int i = 0; i < segs; i++) {
            double a1 = Math.PI * 2 * i / segs, a2 = Math.PI * 2 * (i + 1) / segs;
            int col = m.bool("rb") ? Ui.hsv((float) ((double) i / segs + time * 0.2), 0.7f, 1f) & 0xFFFFFF : m.get("col").color;
            int c = Ui.withA(col, op), cs = Ui.withA(col, 255);
            double x1 = pos.x + Math.cos(a1) * r, z1 = pos.z + Math.sin(a1) * r;
            double x2 = pos.x + Math.cos(a2) * r, z2 = pos.z + Math.sin(a2) * r;
            G.tri(pos.x, top + h, pos.z, Ui.withA(col, Math.min(255, op + 60)), x1, top, z1, c, x2, top, z2, c);
            G.line(x1, top, z1, x2, top, z2, 0.025, cs, cs);
        }
    }

    private static void trail(ClientPlayerEntity p, Vec3d pos, double time) {
        Module m = Modules.TRAILS;
        int n = TRAIL.size();
        if (n < 1) return;
        int st = m.mode("st"), op = (int) (m.num("op") * 2.55);
        double h = st == 1 ? 0.6 : st == 2 ? p.getHeight() : 0;
        for (int i = 0; i < n; i++) {
            double[] a = TRAIL.get(i);
            double[] b = i + 1 < n ? TRAIL.get(i + 1) : new double[]{pos.x, pos.y, pos.z};
            int col = m.bool("rb") ? Ui.hsv((float) (i * 0.02 + time * 0.25), 0.7f, 1f) & 0xFFFFFF : m.get("col").color;
            int ca = Ui.withA(col, op * (i + 1) / (n + 1)), cb = Ui.withA(col, op * (i + 2) / (n + 1));
            if (st == 0) {
                G.line(a[0], a[1] + 0.1, a[2], b[0], b[1] + 0.1, b[2], 0.07, ca, cb);
            } else {
                G.v(a[0], a[1] + 0.1, a[2], ca); G.v(a[0], a[1] + 0.1 + h, a[2], ca);
                G.v(b[0], b[1] + 0.1 + h, b[2], cb); G.v(b[0], b[1] + 0.1, b[2], cb);
            }
        }
    }


    // ================= новые эффекты =================
    private static void step(ArrayList<P> list) {
        for (int i = list.size() - 1; i >= 0; i--) {
            P q = list.get(i);
            q.x += q.vx; q.y += q.vy; q.z += q.vz;
            q.vy -= q.grav;
            q.vx *= q.drag; q.vy *= q.drag; q.vz *= q.drag;
            if (--q.life <= 0) list.remove(i);
        }
    }

    private static void tickGlow(ClientPlayerEntity p) {
        Module m = Modules.GLOW;
        if (!m.enabled) return;
        int n = (int) m.num("n"), mode = m.mode("mode");
        double r = m.num("r");
        for (int i = 0; i < n && GP.size() < 300; i++) {
            P q = new P();
            switch (mode) {
                case 0 -> {
                    double a = Modules.ticks * 0.15 + i * Math.PI * 2 / n;
                    q.x = p.getX() + Math.cos(a) * r;
                    q.y = p.getY() + p.getHeight() * 0.5 + Math.sin(Modules.ticks * 0.07 + i) * 0.6;
                    q.z = p.getZ() + Math.sin(a) * r;
                }
                case 1 -> {
                    double a = RND.nextDouble() * Math.PI * 2, d = Math.sqrt(RND.nextDouble()) * r;
                    q.x = p.getX() + Math.cos(a) * d;
                    q.y = p.getY() + RND.nextDouble() * 0.3;
                    q.z = p.getZ() + Math.sin(a) * d;
                    q.vy = 0.03 + RND.nextDouble() * 0.03;
                }
                case 2 -> {
                    double a = Modules.ticks * 0.25 + i * Math.PI * 2 / n;
                    q.x = p.getX() + Math.cos(a) * r * 0.6;
                    q.y = p.getY() + (Modules.ticks % 40) / 40.0 * p.getHeight();
                    q.z = p.getZ() + Math.sin(a) * r * 0.6;
                    q.vy = 0.02;
                }
                default -> {
                    double a = RND.nextDouble() * Math.PI * 2, sp = 0.03 + RND.nextDouble() * 0.04;
                    q.x = p.getX(); q.y = p.getY() + p.getHeight() * 0.5; q.z = p.getZ();
                    q.vx = Math.cos(a) * sp; q.vz = Math.sin(a) * sp;
                    q.vy = (RND.nextDouble() - 0.3) * 0.04;
                }
            }
            q.max = q.life = (int) m.num("life");
            q.color = m.get("col").color;
            q.color2 = m.get("col2").color;
            q.size = (float) m.num("size");
            q.glow = true;
            GP.add(q);
        }
    }

    private static void burst(LivingEntity e) {
        Module m = Modules.BURST;
        int type = m.mode("type"), n = (int) m.num("n");
        double cx = e.getX(), cy = e.getY() + e.getHeight() * 0.6, cz = e.getZ();
        if (type == 2) {
            RINGS.add(new double[]{cx, e.getY() + 0.05, cz, System.currentTimeMillis()});
            if (RINGS.size() > 6) RINGS.remove(0);
            return;
        }
        for (int i = 0; i < n && GP.size() < 300; i++) {
            double a = RND.nextDouble() * Math.PI * 2, sp = 0.05 + RND.nextDouble() * 0.1;
            P q = new P();
            q.x = cx; q.y = cy; q.z = cz;
            q.vx = Math.cos(a) * sp; q.vz = Math.sin(a) * sp;
            q.vy = (RND.nextDouble() * 0.8 - 0.1) * 0.12;
            q.max = q.life = 14 + RND.nextInt(8);
            q.color = m.get("col").color;
            q.color2 = m.get("col2").color;
            q.size = (float) m.num("size");
            q.glow = type == 0;
            q.shape = type == 1 ? 1 : 0;
            q.grav = 0.004f;
            q.drag = 0.92f;
            GP.add(q);
        }
    }

    private static void tickDamage() {
        if (dmgTarget == null) return;
        long dt = Modules.ticks - dmgTick;
        if (dt < 1) return;
        float hp = dmgTarget.getHealth();
        if (hp < dmgHp - 0.01f) {
            double d = dmgHp - hp;
            Num n = new Num();
            n.x = dmgTarget.getX() + (RND.nextDouble() - 0.5) * 0.5;
            n.y = dmgTarget.getY() + dmgTarget.getHeight() + 0.1;
            n.z = dmgTarget.getZ() + (RND.nextDouble() - 0.5) * 0.5;
            n.s = d >= 10 ? String.format(Locale.ROOT, "%.0f", d) : String.format(Locale.ROOT, "%.1f", d);
            n.crit = d >= Modules.DMG.num("crit");
            n.born = System.currentTimeMillis();
            NUMS.add(n);
            if (NUMS.size() > 12) NUMS.remove(0);
            dmgTarget = null;
        } else if (dt > 12) dmgTarget = null;
    }

    private static void tickSprint(MinecraftClient mc) {
        Module m = Modules.SPRINT;
        if (!m.enabled) {
            if (sprintForced) { mc.options.sprintKey.setPressed(false); sprintForced = false; }
            return;
        }
        boolean want = m.mode("mode") == 0 || sprintToggled;
        boolean fwd = mc.options.forwardKey.isPressed();
        if (want && fwd && mc.currentScreen == null) {
            mc.options.sprintKey.setPressed(true);
            sprintForced = true;
        } else if (sprintForced) {
            mc.options.sprintKey.setPressed(false);
            sprintForced = false;
        }
    }

    /** Проекция мировой точки на экран (для Damage Numbers). */
    private static boolean project(double x, double y, double z, int sw, int sh) {
        if (!vpValid) return false;
        org.joml.Vector4f v = new org.joml.Vector4f((float) (x - camX), (float) (y - camY), (float) (z - camZ), 1f);
        VP.transform(v);
        if (v.w <= 0.05f) return false;
        PROJ[0] = (v.x / v.w * 0.5f + 0.5f) * sw;
        PROJ[1] = (1f - (v.y / v.w * 0.5f + 0.5f)) * sh;
        return true;
    }

    public static void drawNums(net.minecraft.client.gui.DrawContext g) {
        if (NUMS.isEmpty()) return;
        Module m = Modules.DMG;
        long now = System.currentTimeMillis();
        float life = (float) m.num("life") * 1000f;
        int sw = g.getScaledWindowWidth(), sh = g.getScaledWindowHeight();
        var ms = g.getMatrices();
        for (int i = NUMS.size() - 1; i >= 0; i--) {
            Num n = NUMS.get(i);
            float age = now - n.born;
            if (age > life) { NUMS.remove(i); continue; }
            float t = age / life;
            if (!project(n.x, n.y + t * 0.9, n.z, sw, sh)) continue;
            float pop = Ui.back(Math.min(1f, age / 180f));
            float sc = (float) m.num("size") * (n.crit ? 1.4f : 1f) * Math.max(0.2f, pop);
            Ui.alpha = 1f - t * t;
            int col = n.crit ? m.col("colc") : m.col("col");
            ms.push();
            ms.translate(PROJ[0], PROJ[1], 0);
            ms.scale(sc, sc, 1f);
            Ui.text(g, n.s, -Ui.tw(n.s) / 2, -4, col);
            ms.pop();
        }
        Ui.alpha = 1f;
    }

    private static final float[] LOW = circle(10);

    private static void polyFan(double cx, double cy, double cz, Vector3f right, Vector3f up, float[] sh, float s, int c) {
        int n = sh.length / 2;
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            double ax = (right.x * sh[i * 2] + up.x * sh[i * 2 + 1]) * s, ay = (right.y * sh[i * 2] + up.y * sh[i * 2 + 1]) * s, az = (right.z * sh[i * 2] + up.z * sh[i * 2 + 1]) * s;
            double bx = (right.x * sh[j * 2] + up.x * sh[j * 2 + 1]) * s, by = (right.y * sh[j * 2] + up.y * sh[j * 2 + 1]) * s, bz = (right.z * sh[j * 2] + up.z * sh[j * 2 + 1]) * s;
            G.tri(cx, cy, cz, c, cx + ax, cy + ay, cz + az, c, cx + bx, cy + by, cz + bz, c);
        }
    }

    private static void drawParts(ArrayList<P> list, Camera cam, float td, double time) {
        if (list.isEmpty()) return;
        Quaternionf rot = cam.getRotation();
        Vector3f right = new Vector3f(1, 0, 0).rotate(rot), up = new Vector3f(0, 1, 0).rotate(rot);
        for (P q : list) {
            float lf = q.life / (float) q.max;
            float fade = Math.min(1f, lf / 0.4f);
            int col = q.color2 >= 0 ? Ui.mix(0xFF000000 | q.color, 0xFF000000 | q.color2, 1f - lf) & 0xFFFFFF : q.color;
            float s = q.size * (0.6f + 0.4f * fade);
            double cx = q.x + q.vx * td, cy = q.y + q.vy * td, cz = q.z + q.vz * td;
            if (q.glow) {
                float fl = fade * (0.85f + 0.15f * (float) Math.sin(time * 18 + q.x * 13));
                polyFan(cx, cy, cz, right, up, LOW, s * 0.55f, Ui.withA(col, (int) (255 * fl)));
                polyFan(cx, cy, cz, right, up, LOW, s * 1.1f, Ui.withA(col, (int) (90 * fl)));
                polyFan(cx, cy, cz, right, up, LOW, s * 2.0f, Ui.withA(col, (int) (34 * fl)));
            } else {
                polyFan(cx, cy, cz, right, up, SHAPES[Math.min(q.shape, 3)], s, Ui.withA(col, (int) (255 * fade)));
            }
        }
    }

    private static void drawRings(long now) {
        RINGS.removeIf(d -> now - (long) d[3] > 600);
        if (RINGS.isEmpty()) return;
        Module m = Modules.BURST;
        for (double[] d : RINGS) {
            double t = (now - d[3]) / 600.0;
            double rad = 0.2 + t * 1.6, w = 0.02 + 0.07 * (1 - t);
            int c1 = Ui.withA(m.get("col").color, (int) (255 * (1 - t)));
            int c2 = Ui.withA(m.get("col2").color, (int) (255 * (1 - t)));
            for (int i = 0; i < SEG; i++) {
                double a1 = Math.PI * 2 * i / SEG, a2 = Math.PI * 2 * (i + 1) / SEG;
                G.line(d[0] + Math.cos(a1) * rad, d[1], d[2] + Math.sin(a1) * rad,
                        d[0] + Math.cos(a2) * rad, d[1], d[2] + Math.sin(a2) * rad, w, i % 2 == 0 ? c1 : c2, i % 2 == 0 ? c2 : c1);
            }
        }
    }

    private static int accentColor(Module m, double time, double off) {
        int cm = m.mode("cm");
        if (cm == 0) return Theme.accent & 0xFFFFFF;
        if (cm == 1) return m.get("col").color;
        return Ui.hsv((float) (time * 0.25 + off), 0.75f, 1f) & 0xFFFFFF;
    }

    private static void slash(ClientPlayerEntity p, float td, long now, double time) {
        Module m = Modules.SLASH;
        final double life = m.num("life");
        SLASH.removeIf(d -> now - (long) d[3] > life);
        if (p.handSwinging) {
            float s = p.getHandSwingProgress(td);
            if (s > 0f && s != lastSwing) {
                boolean start = lastSwing < 0f || s < lastSwing;
                if (start) slashFlip = !slashFlip;
                lastSwing = s;
                Vec3d eye = p.getCameraPosVec(td), f = p.getRotationVec(td);
                Vec3d right = new Vec3d(-f.z, 0, f.x).normalize();
                Vec3d up = right.crossProduct(f);
                double sg = slashFlip ? 1 : -1;
                double a = (-0.95 + 1.9 * s) * sg, tilt = 0.5 * sg;
                double x = Math.sin(a) * 1.1, y = Math.cos(a) * 0.45 - 0.35;
                double xr = x * Math.cos(tilt) - y * Math.sin(tilt), yr = x * Math.sin(tilt) + y * Math.cos(tilt);
                Vec3d pt = eye.add(f.multiply(1.7)).add(right.multiply(xr)).add(up.multiply(yr));
                SLASH.add(new double[]{pt.x, pt.y, pt.z, now, start ? 1 : 0});
                if (SLASH.size() > 80) SLASH.remove(0);
            }
        } else lastSwing = -1f;
        int n = SLASH.size();
        double w = m.num("w"), glow = m.num("glow") / 100.0;
        for (int i = 1; i < n; i++) {
            double[] a = SLASH.get(i - 1), b = SLASH.get(i);
            if (b[4] == 1) continue;
            double fa = 1 - (now - b[3]) / life;
            if (fa <= 0) continue;
            int col = accentColor(m, time, i * 0.03);
            int cg = Ui.withA(col, (int) (255 * fa * glow * 0.45)), cc = Ui.withA(col, (int) (255 * fa));
            G.line(a[0], a[1], a[2], b[0], b[1], b[2], w * 2.4, cg, cg);
            G.line(a[0], a[1], a[2], b[0], b[1], b[2], w * (0.4 + 0.6 * fa), cc, cc);
        }
    }

    private static void marker(MinecraftClient mc, Camera cam, float td, double time) {
        Module m = Modules.MARKER;
        LivingEntity e = target(mc, m.mode("who"));
        if (e == null) return;
        Vec3d pos = e.getLerpedPos(td);
        double cx = pos.x, cy = pos.y + e.getHeight() * 0.55, cz = pos.z;
        Quaternionf rot = cam.getRotation();
        Vector3f right = new Vector3f(1, 0, 0).rotate(rot), up = new Vector3f(0, 1, 0).rotate(rot);
        double r = m.num("size") * 0.5 * (m.bool("pulse") ? 1 + 0.06 * Math.sin(time * 4) : 1);
        int col = accentColor(m, time, 0);
        int op = (int) (m.num("op") * 2.55);
        int fa = (int) (255 * (m.num("fill") / 100) * (m.num("op") / 100));
        float[] disk = circle(24);
        polyFan(cx, cy, cz, right, up, disk, (float) (r * 0.55), Ui.withA(col, fa));
        polyFan(cx, cy, cz, right, up, disk, (float) (r * 0.8), Ui.withA(col, fa / 3));
        double rot0 = time * m.num("spd") * 2;
        int c = Ui.withA(col, op);
        int segs = 8;
        for (int k = 0; k < 4; k++) {
            double base = rot0 + k * Math.PI / 2 + Math.PI / 4;
            for (int i = 0; i < segs; i++) {
                double a1 = base - 0.5 + (double) i / segs, a2 = base - 0.5 + (double) (i + 1) / segs;
                double c1 = Math.cos(a1) * r, s1 = Math.sin(a1) * r, c2 = Math.cos(a2) * r, s2 = Math.sin(a2) * r;
                G.line(cx + right.x * c1 + up.x * s1, cy + right.y * c1 + up.y * s1, cz + right.z * c1 + up.z * s1,
                        cx + right.x * c2 + up.x * s2, cy + right.y * c2 + up.y * s2, cz + right.z * c2 + up.z * s2,
                        r * 0.13, c, c);
            }
        }
    }
    private static void esp(MinecraftClient mc, float td, double time) {
        Module m = Modules.ESP;
        LivingEntity e = target(mc, m.mode("who"));
        if (e == null) return;
        Vec3d pos = e.getLerpedPos(td);
        Box bb = e.getBoundingBox().offset(pos.x - e.getX(), pos.y - e.getY(), pos.z - e.getZ());
        double w = m.num("thick") * 0.008;
        int op = (int) (m.num("op") * 2.55);
        int fa = (int) (255 * (m.num("fill") / 100) * (m.num("op") / 100));
        int base = espColor(m, time, 0f);
        double rad = e.getWidth() * 0.5 + 0.3;
        switch (m.mode("mode")) {
            case 0 -> { G.fillBox(bb, Ui.withA(base, fa)); G.edges(bb, w, Ui.withA(base, op)); }
            case 1 -> G.edges(bb, w, Ui.withA(base, op));
            case 2 -> {
                disk(pos.x, bb.minY + 0.03, pos.z, rad, Ui.withA(base, fa));
                ring(pos.x, bb.minY + 0.03, pos.z, rad, w * 2, op, time, true);
            }
            case 3 -> {
                double k = 0.5 + 0.5 * Math.sin(time * m.num("spd") * 2);
                double y = bb.minY + k * bb.getLengthY();
                ring(pos.x, y, pos.z, rad - 0.05, w * 2, op, time, true);
                ring(pos.x, y + (k > 0.5 ? -0.12 : 0.12), pos.z, rad - 0.05, w, op / 3, time, true);
            }
            default -> {
                double y = bb.maxY + 0.15;
                disk(pos.x, y, pos.z, 0.32, Ui.withA(base, fa));
                ring(pos.x, y, pos.z, 0.32, w * 2.5, op, time, true);
            }
        }
    }
}
