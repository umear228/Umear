package com.umear;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class UmearClient implements ClientModInitializer {
    public static KeyBinding OPEN, SPRINT_KEY;

    @Override
    public void onInitializeClient() {
        Modules.init();
        OPEN = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.umear.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.umear"));
        SPRINT_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.umear.sprint", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "key.categories.umear"));
        ClientTickEvents.END_CLIENT_TICK.register(Fx::tick);
        HudRenderCallback.EVENT.register(Hud::render);
        WorldRenderEvents.AFTER_ENTITIES.register(Fx::world);
        AttackEntityCallback.EVENT.register(Fx::attack);
    }
}
