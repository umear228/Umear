package com.umear;

import net.minecraft.client.gui.DrawContext;

/**
 * Чибик главного меню: свой образ под каждый фон
 * (0 Сумерки, 1 Закат, 2 Ночь, 3 Синтвейв, 4 День, 5 Аврора, 6 Сакура).
 * Спрайт 16x16 как в UmearTitleScreen.SPR. Рисуется горизонтальными полосами.
 * Покачивание (смещение по Y) делает вызывающий код, моргание тут.
 */
public final class ChibiSkins {
    private static final String[] SPR = {
            "....OOOOOOOO....", "..OOHHHHHHHHOO..", ".OHHHHHHHHHHHHO.", "OHHHHHHHHHHHHHHO",
            "OHHHSSSSSSSSHHHO", "OHHSSSSSSSSSSHHO", "OHHSSSSSSSSSSHHO", "OHHSEESSSSEESHHO",
            "OHHSEWSSSSEWSHHO", "OHHSEESSSSEESHHO", "OHHSBBSSSSBBSHHO", ".OHSSSSMMSSSSHO.",
            ".OHHSSSSSSSSHHO.", "..OHHHSSSSHHHO..", "...OOOHHHHOOO...", ".....OOOOOO....."};

    private static final int INK = 0xFF2B2147, SKIN = 0xFFFFE0C8, WHITE = 0xFFFFFFFF,
            BLUSH = 0xFFFF9FB0, MOUTH = 0xFFC0506E, BLACK = 0xFF0A0A14;

    // на каждый фон: волосы, глаза, акцент A, акцент a
    private static final int[][] PAL = {
            {0xFF9B7BE8, 0xFF3B2A7A, 0xFFFFE066, 0xFFFFA94D},   // Сумерки
            {0xFFFF8A4C, 0xFF8A2D10, 0xFFFF5A7A, 0xFFFFB347},   // Закат
            {0xFF3F55C8, 0xFF8FD0FF, 0xFFF5E6A0, 0xFFC9B458},   // Ночь
            {0xFFFF4FD8, 0xFF00E5FF, 0xFF00E5FF, 0xFFFF2BD6},   // Синтвейв
            {0xFF9A6A3A, 0xFF2A6FB5, 0xFFFFD23F, 0xFFFF8A1F},   // День
            {0xFF2ED6A3, 0xFF0B7A5A, 0xFFB8FFF0, 0xFF7DFFC9},   // Аврора
            {0xFFFF8FC7, 0xFFB03A6E, 0xFFFFE9F6, 0xFFE0497F},   // Сакура
    };

    // аксессуары "x,y,цвет;..." (A, a = акценты, w = белый, k = чёрный)
    private static final String[] ACC = {
            "10,1,w;9,2,w;10,2,A;11,2,w;10,3,w",                                  // Сумерки: звезда
            "2,-1,A;3,-1,A;4,-1,a;5,-1,A;6,-1,A;3,0,A;4,0,a;5,0,A",               // Закат: бант
            "11,1,A;12,1,A;10,2,A;10,3,A;12,3,A",                                 // Ночь: месяц
            "3,7,A;4,7,A;5,7,A;6,7,A;7,7,k;8,7,k;9,7,A;10,7,A;11,7,A;12,7,A;"
                    + "3,8,a;4,8,a;5,8,a;6,8,a;9,8,a;10,8,a;11,8,a;12,8,a",        // Синтвейв: очки
            "10,-1,A;9,0,A;10,0,A;11,0,A;10,1,A",                                 // День: солнышко
            "2,-2,A;13,-1,a;0,0,A;15,0,A;0,13,a;15,12,A",                         // Аврора: искры
            "3,-1,A;2,0,A;3,0,a;4,0,A;3,1,A;15,11,A;0,12,A",                      // Сакура: цветок
    };

    private ChibiSkins() {}

    /** @param x,y левый верхний угол  @param px размер «пикселя»  @param bg номер фона  @param ms время, мс */
    public static void draw(DrawContext c, int x, int y, int px, int bg, long ms) {
        bg = Math.floorMod(bg, PAL.length);
        int[] p = PAL[bg];
        boolean blink = ms % 3200 < 140;

        for (int r = 0; r < SPR.length; r++) {
            int s = 0;
            while (s < 16) {
                char ch = at(r, s, blink);
                int e = s + 1;
                while (e < 16 && at(r, e, blink) == ch) e++;
                int col = color(ch, p);
                if (col != 0) c.fill(x + s * px, y + r * px, x + e * px, y + (r + 1) * px, col);
                s = e;
            }
        }
        for (String t : ACC[bg].split(";")) {
            String[] a = t.split(",");
            int ax = Integer.parseInt(a[0]), ay = Integer.parseInt(a[1]);
            int col = switch (a[2].charAt(0)) {
                case 'A' -> p[2];
                case 'a' -> p[3];
                case 'w' -> WHITE;
                default -> BLACK;
            };
            c.fill(x + ax * px, y + ay * px, x + (ax + 1) * px, y + (ay + 1) * px, col);
        }
    }

    private static char at(int r, int col, boolean blink) {
        char ch = SPR[r].charAt(col);
        if (blink && (r == 7 || r == 9) && ch == 'E') return 'S';
        if (blink && r == 8 && (ch == 'E' || ch == 'W')) return 'O';
        return ch;
    }

    private static int color(char ch, int[] p) {
        return switch (ch) {
            case 'O' -> INK;
            case 'H' -> p[0];
            case 'S' -> SKIN;
            case 'E' -> p[1];
            case 'W' -> WHITE;
            case 'B' -> BLUSH;
            case 'M' -> MOUTH;
            default -> 0;
        };
    }
}
