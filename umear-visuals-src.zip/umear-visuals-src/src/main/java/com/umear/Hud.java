package com.umear;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import java.time.LocalTime;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

public final class Hud {
    public static final String[] IDS = {"watermark", "clock", "info", "keys", "sprint", "target", "notif"};
    public static final String[] TITLES = {"Watermark", "Clock Bar", "Info HUD", "Keystrokes", "Toggle Sprint", "Target HUD", "Notifications"};
    private static final float[][] DEF = {{0.5f, 0.01f, 1f}, {0.5f, 0.075f, 1f}, {0.01f, 0.25f, 1f},
            {0.01f, 0.6f, 1f}, {0.01f, 0.93f, 1f}, {1f, 0.8f, 1f}, {1f, 1f, 1f}};
    private static final HashMap<String, float[]> POS = new HashMap<>();
    private static final HashMap<String, int[]> SIZE = new HashMap<>();   // w, h в пикселях (с учётом масштаба)
    private static final Identifier LOGO = Identifier.of("umear", "textures/gui/logo.png");
    private static final HashMap<String, int[]> UN = new HashMap<>();     // размер без масштаба

    static { reset(); }

    public static void reset() {
        for (int i = 0; i < IDS.length; i++) POS.put(IDS[i], DEF[i].clone());
    }

    /** nx, ny — доля свободного места (0..1), sc — масштаб. */
    public static float[] pos(String id) { return POS.get(id); }

    public static JsonObject toJson() {
        JsonObject o = new JsonObject();
        for (String id : IDS) {
            float[] p = POS.get(id);
            JsonArray a = new JsonArray();
            a.add(p[0]); a.add(p[1]); a.add(p[2]);
            o.add(id, a);
        }
        return o;
    }

    public static void fromJson(JsonObject o) {
        for (String id : IDS) {
            try {
                if (!o.has(id)) continue;
                JsonArray a = o.getAsJsonArray(id);
                POS.put(id, new float[]{a.get(0).getAsFloat(), a.get(1).getAsFloat(), Math.max(0.5f, Math.min(2.5f, a.get(2).getAsFloat()))});
            } catch (Exception ignored) { }
        }
    }

    // ---------- главный рендер ----------
    public static void render(DrawContext g, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null) return;
        if (mc.currentScreen instanceof UmearScreen || mc.currentScreen instanceof HudEditorScreen) return;
        Ui.frame();
        Theme.update();
        Ui.alpha = 1f;
        Ui.menuFont = false;
        for (String id : IDS) draw(g, id, false);
        if (Modules.CROSS.enabled && mc.currentScreen == null && mc.options.getPerspective().isFirstPerson())
            crosshair(g, mc);
        if (Modules.DMG.enabled) Fx.drawNums(g);
        Ui.alpha = 1f;
    }

    public static int[] size(String id) {
        layout(id);
        return SIZE.get(id);
    }

    public static int px(String id, int sw, int w) {
        float[] p = POS.get(id);
        return 4 + Math.round(p[0] * Math.max(0, sw - w - 8));
    }

    public static int py(String id, int sh, int h) {
        float[] p = POS.get(id);
        return 4 + Math.round(p[1] * Math.max(0, sh - h - 8));
    }

    public static boolean visible(String id) {
        return switch (id) {
            case "watermark" -> Modules.THEME.enabled && Modules.THEME.bool("wm");
            case "clock" -> Modules.CLOCK.enabled;
            case "info" -> Modules.INFO.enabled;
            case "keys" -> Modules.KEYS.enabled;
            case "sprint" -> Modules.SPRINT.enabled && Modules.SPRINT.bool("hud");
            case "target" -> Modules.TARGETHUD.enabled;
            default -> Modules.NOTIF.enabled;
        };
    }

    public static void draw(DrawContext g, String id, boolean preview) {
        if (!preview && !visible(id)) return;
        int sw = g.getScaledWindowWidth(), sh = g.getScaledWindowHeight();
        int[] s = size(id);
        int x = px(id, sw, s[0]), y = py(id, sh, s[1]);
        float sc = POS.get(id)[2];
        int[] u = UN.get(id);
        var ms = g.getMatrices();
        switch (id) {
            case "info" -> drawInfo(g, x, y, sc);
            case "notif" -> drawNotifs(g, x, y, sc, preview, sw);
            default -> {
                ms.push();
                ms.translate(x, y, 0);
                ms.scale(sc, sc, 1f);
                switch (id) {
                    case "watermark" -> drawWatermark(g, u[0], u[1]);
                    case "clock" -> drawClock(g, u[0], u[1]);
                    case "keys" -> drawKeys(g, preview);
                    case "sprint" -> drawSprint(g, u[0], u[1]);
                    default -> drawTarget(g, preview);
                }
                ms.pop();
            }
        }
    }

    private static void layout(String id) {
        int[] u = UN.computeIfAbsent(id, k -> new int[2]);
        switch (id) {
            case "watermark" -> { u[0] = 6 + 17 + 5 + Ui.tw("UMEAR VISUALS") + 9; u[1] = 18; }
            case "clock" -> { clockData(); u[0] = clW; u[1] = 18; }
            case "info" -> { infoData(); u[0] = iw; u[1] = ih; }
            case "keys" -> { u[0] = 64; u[1] = keysH(); }
            case "sprint" -> { u[0] = Ui.tw("Sprint: " + sprintVal()) + 16; u[1] = 18; }
            case "target" -> { u[0] = 134; u[1] = 34; }
            default -> { u[0] = 130; u[1] = 26; }
        }
        int[] s = SIZE.computeIfAbsent(id, k -> new int[2]);
        float sc = POS.get(id)[2];
        s[0] = Math.round(u[0] * sc);
        s[1] = Math.round(u[1] * sc);
    }

    // ---------- watermark (плашка: иконка + название) ----------
    private static void drawWatermark(DrawContext g, int w, int h) {
        Ui.round(g, 0, 0, w, h, h / 2, 0xD00C0A14);
        Ui.tex(g, LOGO, 6, 3, 17, 12);
        int x = 6 + 17 + 5;
        Ui.text(g, "UMEAR ", x, 5, 0xFFFFFFFF);
        Ui.text(g, "VISUALS", x + Ui.tw("UMEAR "), 5, Theme.accent);
    }

    // ---------- Clock Bar ----------
    private static final ArrayList<String> SEG = new ArrayList<>();
    private static long clSec = -1;
    private static int clW = 60;
    private static String timeS = "00:00:00";

    private static int ping(MinecraftClient mc) {
        var h = mc.getNetworkHandler();
        if (h == null || mc.player == null) return 0;
        var e = h.getPlayerListEntry(mc.player.getUuid());
        return e == null ? 0 : e.getLatency();
    }

    private static void clockData() {
        MinecraftClient mc = MinecraftClient.getInstance();
        Module m = Modules.CLOCK;
        long sec = System.currentTimeMillis() / 1000;
        if (sec != clSec) {
            clSec = sec;
            LocalTime t = LocalTime.now();
            timeS = String.format(Locale.ROOT, "%02d:%02d:%02d", t.getHour(), t.getMinute(), t.getSecond());
        }
        SEG.clear();
        if (m.bool("time")) SEG.add(timeS);
        if (m.bool("ping")) SEG.add(ping(mc) + " ms");
        if (m.bool("xyz") && mc.player != null)
            SEG.add((int) mc.player.getX() + " " + (int) mc.player.getY() + " " + (int) mc.player.getZ());
        if (SEG.isEmpty()) SEG.add(timeS);
        int w = 16;
        for (String x : SEG) w += Ui.tw(x);
        w += (SEG.size() - 1) * (Ui.tw("/") + 8);
        clW = w;
    }

    private static void drawClock(DrawContext g, int w, int h) {
        Ui.round(g, 0, 0, w, h, h / 2, Ui.withA(0x0C0A14, (int) (Modules.CLOCK.num("bgop") * 2.55)));
        int x = 8;
        for (int i = 0; i < SEG.size(); i++) {
            if (i > 0) {
                Ui.text(g, "/", x + 4, 5, Theme.sub, false);
                x += Ui.tw("/") + 8;
            }
            Ui.text(g, SEG.get(i), x, 5, 0xFFFFFFFF);
            x += Ui.tw(SEG.get(i));
        }
    }

    // ---------- Toggle Sprint ----------
    private static String sprintVal() {
        return Modules.SPRINT.mode("mode") == 0 ? "Always" : (Fx.sprintToggled ? "Toggled" : "Off");
    }

    private static void drawSprint(DrawContext g, int w, int h) {
        Ui.round(g, 0, 0, w, h, h / 2, 0xB00C0A14);
        Ui.text(g, "Sprint: ", 8, 5, 0xFFFFFFFF);
        Ui.text(g, sprintVal(), 8 + Ui.tw("Sprint: "), 5, Theme.accent);
    }

    // ---------- Keystrokes ----------
    private static final float[] PR = new float[7];

    private static int keysH() {
        Module m = Modules.KEYS;
        int h = 42;
        if (m.bool("mouse")) h += 22;
        if (m.bool("space")) h += 12;
        return h;
    }

    private static void key(DrawContext g, int i, int x, int y, int w, int h, String label, boolean down, String sub) {
        PR[i] += ((down ? 1f : 0f) - PR[i]) * Math.min(1f, Ui.dt * 18f);
        int bg = Ui.mix(Ui.withA(0x000000, (int) (Modules.KEYS.num("bgop") * 2.55)), Ui.withA(Theme.accent & 0xFFFFFF, 210), PR[i]);
        Ui.round(g, x, y, w, h, Theme.round, bg);
        if (sub == null) {
            Ui.ctext(g, label, x + w / 2, y + (h - 8) / 2, 0xFFFFFFFF);
        } else {
            Ui.ctext(g, label, x + w / 2, y + 3, 0xFFFFFFFF);
            Ui.textS(g, sub, x + w / 2 - (int) (Ui.tw(sub) * 0.375f), y + 13, 0xFFDDDDDD, 0.75f);
        }
    }

    private static void drawKeys(DrawContext g, boolean preview) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Module m = Modules.KEYS;
        boolean live = !preview && mc.currentScreen == null;
        var o = mc.options;
        key(g, 0, 22, 0, 20, 20, "W", live && o.forwardKey.isPressed(), null);
        key(g, 1, 0, 22, 20, 20, "A", live && o.leftKey.isPressed(), null);
        key(g, 2, 22, 22, 20, 20, "S", live && o.backKey.isPressed(), null);
        key(g, 3, 44, 22, 20, 20, "D", live && o.rightKey.isPressed(), null);
        int y = 44;
        if (m.bool("mouse")) {
            key(g, 4, 0, y, 31, 20, "LMB", live && o.attackKey.isPressed(), Integer.toString(Modules.cps()));
            key(g, 5, 33, y, 31, 20, "RMB", live && o.useKey.isPressed(), null);
            y += 22;
        }
        if (m.bool("space")) key(g, 6, 0, y, 64, 10, "", live && o.jumpKey.isPressed(), null);
    }

    // ---------- Target HUD ----------
    private static float tA, tShown, tHp = 20f, tMax = 20f;
    private static int tId = -1;
    private static String tName = "Target", tHpS = "20.0";
    private static int tHpTenths = -1;

    private static void drawTarget(DrawContext g, boolean preview) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Module m = Modules.TARGETHUD;
        LivingEntity e = preview ? null : Fx.target(mc, 0);
        if (e != null) {
            tName = e.getName().getString();
            if (tName.length() > 20) tName = tName.substring(0, 20);
            tHp = e.getHealth();
            tMax = Math.max(1f, e.getMaxHealth());
            if (e.getId() != tId) { tId = e.getId(); tShown = tHp; }
        } else if (preview) {
            tName = "Target"; tHp = 20f; tMax = 20f; tShown = 20f;
        }
        tA += ((e != null || preview ? 1f : 0f) - tA) * Math.min(1f, Ui.dt * 10f);
        if (tA < 0.02f) return;
        tShown += (tHp - tShown) * Math.min(1f, Ui.dt * 8f);
        int tenths = Math.round(tHp * 10f);
        if (tenths != tHpTenths) { tHpTenths = tenths; tHpS = String.format(Locale.ROOT, "HP: %.1f", tHp); }
        Ui.alpha = tA;
        Ui.round(g, 0, 0, 134, 34, Theme.round + 2, Ui.withA(0x0C0A14, (int) (m.num("bgop") * 2.55)));
        Ui.text(g, tName, 7, 5, 0xFFFFFFFF);
        Ui.textS(g, tHpS, 7, 16, Theme.sub, 0.85f);
        Ui.round(g, 7, 26, 120, 4, 2, Theme.track);
        int fw = (int) (120 * Math.max(0f, Math.min(1f, tShown / tMax)));
        if (fw >= 2) Ui.round(g, 7, 26, fw, 4, 2, m.bool("theme") ? Theme.accent : m.col("col"));
        Ui.alpha = 1f;
    }

    // ---------- Info HUD ----------
    private static final String[] LAB = {"FPS", "CPS", "Reach", "Combo"};
    private static final String[] VAL = new String[4];
    private static final int[] IDX = new int[4];
    private static int n, iw = 60, ih = 20;
    private static int lastFps = -1, lastCombo = -1;
    private static double lastReach = -1;
    private static String fpsS = "0", reachS = "0.00", comboS = "0";

    private static void infoData() {
        MinecraftClient mc = MinecraftClient.getInstance();
        Module m = Modules.INFO;
        int fps = mc.getCurrentFps();
        if (fps != lastFps) { lastFps = fps; fpsS = Integer.toString(fps); }
        if (Modules.reach != lastReach) { lastReach = Modules.reach; reachS = String.format(Locale.ROOT, "%.2f", lastReach); }
        if (Modules.combo != lastCombo) { lastCombo = Modules.combo; comboS = Integer.toString(lastCombo); }
        n = 0;
        if (m.bool("fps")) { IDX[n] = 0; VAL[n++] = fpsS; }
        if (m.bool("cps")) { IDX[n] = 1; VAL[n++] = Integer.toString(Modules.cps()); }
        if (m.bool("reach")) { IDX[n] = 2; VAL[n++] = reachS; }
        if (m.bool("combo")) { IDX[n] = 3; VAL[n++] = comboS; }
        if (n == 0) { IDX[0] = 0; VAL[0] = fpsS; n = 1; }
        int pad = 5;
        if (m.mode("layout") == 0) {
            int mw = 0;
            for (int i = 0; i < n; i++) mw = Math.max(mw, Ui.tw(LAB[IDX[i]]) + 10 + Ui.tw(VAL[i]));
            iw = mw + pad * 2;
            ih = n * 11 + pad * 2 - 2;
        } else {
            int tw = 0;
            for (int i = 0; i < n; i++) tw += Ui.tw(LAB[IDX[i]]) + 4 + Ui.tw(VAL[i]);
            iw = tw + (n - 1) * 12 + pad * 2;
            ih = 9 + pad * 2;
        }
    }

    private static void drawInfo(DrawContext g, int x, int y, float sc) {
        Module m = Modules.INFO;
        var ms = g.getMatrices();
        ms.push();
        ms.translate(x, y, 0);
        ms.scale(sc, sc, 1f);
        int bg = Ui.withA(0x000000, (int) (m.num("bgop") * 2.55));
        Ui.round(g, 0, 0, iw, ih, Theme.round, bg);
        Ui.fill(g, 0, 2, 2, ih - 2, Theme.accent);
        int vc = m.col("col"), pad = 5;
        if (m.mode("layout") == 0) {
            for (int i = 0; i < n; i++) {
                int yy = pad + i * 11;
                Ui.text(g, LAB[IDX[i]], pad + 2, yy, Theme.accent);
                Ui.text(g, VAL[i], iw - pad - Ui.tw(VAL[i]), yy, vc);
            }
        } else {
            int xx = pad + 2;
            for (int i = 0; i < n; i++) {
                Ui.text(g, LAB[IDX[i]], xx, pad, Theme.accent);
                xx += Ui.tw(LAB[IDX[i]]) + 4;
                Ui.text(g, VAL[i], xx, pad, vc);
                xx += Ui.tw(VAL[i]) + 12;
            }
        }
        ms.pop();
    }

    // ---------- уведомления ----------
    private static final class N { String name; boolean on; long born; }
    private static final ArrayList<N> NS = new ArrayList<>();

    public static void notify(String name, boolean on) {
        Module nm = Modules.NOTIF;
        if (nm == null || !nm.enabled || !nm.bool("mods")) return;
        N x = new N();
        x.name = name; x.on = on; x.born = System.currentTimeMillis();
        NS.add(x);
        if (NS.size() > 6) NS.remove(0);
        if (nm.bool("snd")) Fx.play(Modules.CSOUND.mode("snd"), (float) Modules.CSOUND.num("vol") / 100f, on ? 1.2f : 0.8f);
    }

    private static void drawNotifs(DrawContext g, int x, int y, float sc, boolean preview, int sw) {
        Module nm = Modules.NOTIF;
        float[] p = POS.get("notif");
        boolean fromRight = p[0] > 0.5f, growUp = p[1] > 0.5f;
        float life = (float) nm.num("dur");
        int style = nm.mode("style");
        long now = System.currentTimeMillis();
        if (preview) { panel(g, x, y, sc, "Module", true, 0f, style, 1f); return; }
        int slot = 0;
        for (int i = NS.size() - 1; i >= 0; i--) {
            N q = NS.get(i);
            float age = (now - q.born) / 1000f;
            if (age > life + 0.35f) { NS.remove(i); continue; }
            float in = Ui.ease(age / 0.25f);
            float out = age > life ? Ui.ease((age - life) / 0.3f) : 0f;
            float vis = in * (1 - out);
            int h = Math.round((style == 0 ? 26 : style == 1 ? 16 : 20) * sc);
            int yy = y + (growUp ? -1 : 1) * slot * (h + 3);
            int off = Math.round((1 - vis) * 40 * (fromRight ? 1 : -1));
            Ui.alpha = vis;
            panel(g, x + off, yy, sc, q.name, q.on, Math.min(1f, age / life), style, vis);
            Ui.alpha = 1f;
            slot++;
        }
    }

    private static void panel(DrawContext g, int x, int y, float sc, String name, boolean on, float prog, int style, float vis) {
        String st = on ? "Включён" : "Выключен";
        int col = on ? Theme.accent : 0xFFFF5566;
        var ms = g.getMatrices();
        ms.push();
        ms.translate(x, y, 0);
        ms.scale(sc, sc, 1f);
        if (style == 0) {
            int w = Math.max(110, Ui.tw(name) + 34);
            Ui.round(g, 0, 0, w, 26, Theme.round, Theme.card);
            Ui.round(g, 0, 3, 3, 20, 1, col);
            Ui.text(g, name, 10, 4, Theme.text);
            Ui.text(g, st, 10, 14, col, false);
            Ui.fill(g, 6, 24, 6 + (int) ((w - 12) * (1 - prog)), 25, Ui.withA(col & 0xFFFFFF, 160));
        } else if (style == 1) {
            int w = Ui.tw(name) + Ui.tw(st) + 24;
            Ui.round(g, 0, 0, w, 16, Theme.round, 0xB0000000);
            Ui.fill(g, 5, 6, 9, 10, col);
            Ui.text(g, name, 14, 4, 0xFFFFFFFF);
            Ui.text(g, st, w - Ui.tw(st) - 6, 4, col, false);
        } else {
            int w = Ui.tw(name) + Ui.tw(st) + 30;
            Ui.round(g, 0, 0, w, 20, Theme.round + 6, on ? Theme.accent : 0xFFB03A48);
            Ui.text(g, name, 10, 6, 0xFFFFFFFF);
            Ui.text(g, st, w - Ui.tw(st) - 10, 6, 0xDDFFFFFF, false);
        }
        ms.pop();
    }

    // ---------- Dynamic Crosshair ----------
    private static float crossT;

    private static void rect(DrawContext g, int x, int y, int w, int h, int c, boolean ol) {
        if (ol) g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF000000);
        g.fill(x, y, x + w, y + h, c);
    }

    private static void crosshair(DrawContext g, MinecraftClient mc) {
        Module m = Modules.CROSS;
        boolean hit = Fx.crossTarget(mc, m.mode("who"));
        crossT += ((hit ? 1f : 0f) - crossT) * Math.min(1f, Ui.dt * 14f);
        int cx = g.getScaledWindowWidth() / 2, cy = g.getScaledWindowHeight() / 2;
        int c = Ui.mix(m.col("col"), m.col("colt"), crossT);
        int size = Math.round((float) m.num("size") * (1f + (float) m.num("grow") / 100f * crossT));
        int gap = (int) m.num("gap"), th = (int) m.num("thick");
        boolean ol = m.bool("outline");
        int h0 = th / 2;
        switch (m.mode("style")) {
            case 0 -> {
                rect(g, cx - gap - size, cy - h0, size, th, c, ol);
                rect(g, cx + gap + 1, cy - h0, size, th, c, ol);
                rect(g, cx - h0, cy - gap - size, th, size, c, ol);
                rect(g, cx - h0, cy + gap + 1, th, size, c, ol);
            }
            case 1 -> rect(g, cx - th, cy - th, th * 2 + 1, th * 2 + 1, c, ol);
            case 2 -> {
                int r = size + gap;
                for (int i = 0; i < 32; i++) {
                    double a = Math.PI * 2 * i / 32;
                    rect(g, cx + (int) Math.round(Math.cos(a) * r), cy + (int) Math.round(Math.sin(a) * r), th, th, c, false);
                }
            }
            case 3 -> {
                for (int i = gap; i <= gap + size; i++) {
                    rect(g, cx + i, cy + i, th, th, c, false); rect(g, cx - i, cy + i, th, th, c, false);
                    rect(g, cx + i, cy - i, th, th, c, false); rect(g, cx - i, cy - i, th, th, c, false);
                }
            }
            default -> {
                int r = size + gap, l = Math.max(2, size / 2 + 1);
                for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2) {
                    int bx = cx + sx * r, by = cy + sy * r;
                    rect(g, sx < 0 ? bx : bx - l, by - (sy < 0 ? 0 : th - 1), l + (sx < 0 ? 0 : 1), th, c, false);
                    rect(g, bx - (sx < 0 ? 0 : th - 1), sy < 0 ? by : by - l, th, l + (sy < 0 ? 0 : 1), c, false);
                }
            }
        }
    }
}
