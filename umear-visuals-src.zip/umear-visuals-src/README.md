# Umear Visuals (Fabric 1.21.4)

Исходники восстановлены по вашему jar (структура Module / Setting / Modules сохранена, конфиг `config/umear_visuals.json` совместим) + всё из «Дня 2».

## Сборка
Локально: `gradle build` (JDK 21) → `build/libs/umear-visuals-1.1.0.jar`.
С телефона: залей папку в GitHub-репозиторий, вкладка Actions → build → скачай артефакт `umear-visuals-jar`.

## ВАЖНО
Код написан без компиляции (в моей среде нет JDK и библиотек Minecraft). Если сборка упадёт — пришли лог ошибки, поправлю.
Самые рискованные места (имена Yarn 1.21.4): `GameRenderer.renderBlur`, `BackgroundRenderer.applyFog`/`Fog`,
`HeldItemRenderer.renderFirstPersonItem` (MixinExtras `@WrapMethod`), `DrawContext.drawTexture(... color)`.
Миксины в `umear.mixins.json` помечены `required:false`, поэтому сбой одного не роняет игру.

## Что нового
Исправлено: watermark — непрозрачная подложка + текстура с явным ARGB (раньше PNG был почти весь полупрозрачным);
FPS/CPS/Reach/Combo — один модуль **Info HUD**; все цвета теперь всегда с альфой 255.

Visuals: View Model, Target ESP (Box/Outline/Circle/Ring/Halo; цвет Статичный/Радуга/Градиент), Fog Changer,
Aspect Ratio (слайдер + пресеты), Swing Animation (режимы + скорость + длительность), Particles (Ванильные / Свои: круг, звезда, сердце, снежинка).
Combat: Hit Color, Dynamic Crosshair (Плюс/Точка/Круг/X/Скобки), Info HUD.
Misc: Client Sounds, Custom Font (Default/Uniform/Runic), GUI Blur, GUI Animation (Fade/Scale/Slide/Bounce, открытие и закрытие),
HUD Editor (перетаскивание, колёсико = размер, привязка), Notifications (3 стиля), Custom Theme (6 пресетов + Custom).

Не сделано: Chams (заменён на Box с заливкой); собственный TTF-шрифт (нужен файл шрифта в ресурсах).

## 1.2.0
Новый watermark (иконка + «UMEAR VISUALS», рисуется кодом, без FPS/пинга).
Visuals: Target Marker, Slash Trail, Glow Particles. Combat: Target HUD, Damage Numbers, Hit Burst.
Misc: Clock Bar, Keystrokes, Toggle Sprint (режим «По кнопке»: назначьте клавишу в Управление → Umear).
Все HUD-элементы двигаются в HUD Editor.

## Обновление: Shortcut и Marker
- Target ESP удалён. Target Marker: 12 форм (скобки, двойное кольцо, квадрат, ромб, звезда, прицел, треугольники, шестиугольник, сердце, волна, кристаллы, орбита), позиция, цвет по HP, анимации, реакция на удар, кристаллы вокруг цели.
- Swing Animation: +Spin, Chop, Punch, Slide, Wave, Swank, Exhibition; амплитуда и кривая.
- Темы: Neon Cyan, Neon Pink.
- Новый раздел Shortcut: Zoom (по умолчанию C) и Freelook (по умолчанию V). Клавиши меняются в Управление → Umear.

## Target Marker: контур
Внутри теперь пусто (прозрачность внутри 0–50%, по умолчанию 0), настраиваются толщина и количество контуров (1–3).

## Главное меню «чибик»
Новое пиксельное главное меню (Одиночная игра, Мультиплеер, Настройки, Umear Menu, Выход). Отключается модулем Main Menu (Misc).
Тема «Chibi Pixel» (Misc → Custom Theme) делает пиксельным и меню мода.
