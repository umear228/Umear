package dev.umear.module;

import dev.umear.setting.Setting;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public final String description;
    public final Category category;
    public final List<Setting> settings = new ArrayList<>();
    /** Показывать ли модуль в списке включённых функций (ModuleList). */
    public boolean showInList = true;

    private boolean enabled;

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    protected <T extends Setting> T add(T setting) {
        settings.add(setting);
        return setting;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean value) {
        if (enabled == value) {
            return;
        }
        enabled = value;
        if (value) {
            onEnable();
        } else {
            onDisable();
        }
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    /** Для загрузки конфига и значений по умолчанию: без вызова onEnable/onDisable. */
    public void restoreEnabled(boolean value) {
        enabled = value;
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public void onTick(MinecraftClient mc) {
    }
}
