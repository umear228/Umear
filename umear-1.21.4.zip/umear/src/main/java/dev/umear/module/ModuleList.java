package dev.umear.module;

public class ModuleList extends Module {
    public ModuleList() {
        super("ModuleList", "Список включённых функций справа вверху", Category.VISUAL);
        showInList = false;
        restoreEnabled(true);
    }
}
