package dev.umear.module;

import dev.umear.setting.BoolSetting;
import dev.umear.setting.NumSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

public class Hitboxes extends Module {
    public final NumSetting size = add(new NumSetting("Expand", 0.3, 0.0, 1.0, 0.05));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));

    public Hitboxes() {
        super("Hitboxes", "Увеличивает хитбоксы других существ при прицеливании", Category.COMBAT);
    }

    public boolean applies(Entity entity) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null || entity == mc.player) {
            return false;
        }
        if (entity.getWorld() != mc.world || !(entity instanceof LivingEntity)) {
            return false;
        }
        return !playersOnly.get() || entity instanceof PlayerEntity;
    }
}
