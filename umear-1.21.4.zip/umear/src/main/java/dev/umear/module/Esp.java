package dev.umear.module;

import dev.umear.setting.BoolSetting;
import dev.umear.util.Targets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;

/** ESP через ванильную обводку (glow): видно сквозь стены. */
public class Esp extends Module {
    public final BoolSetting players = add(new BoolSetting("Players", true));
    public final BoolSetting hostile = add(new BoolSetting("Hostile", true));
    public final BoolSetting passive = add(new BoolSetting("Passive", false));

    public Esp() {
        super("ESP", "Подсвечивает существ сквозь стены", Category.VISUAL);
    }

    public boolean applies(Entity entity) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null || entity.getWorld() != mc.world) {
            return false;
        }
        return Targets.valid(entity, mc.player, players.get(), hostile.get(), passive.get());
    }

    public int colorFor(Entity entity) {
        if (entity instanceof PlayerEntity) {
            return 0xFF5555;
        }
        if (entity instanceof Monster) {
            return 0xFFAA00;
        }
        return 0x55FF55;
    }
}
