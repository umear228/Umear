package dev.umear.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public class Fullbright extends Module {
    public Fullbright() {
        super("Fullbright", "Полная яркость (клиентский ночной взгляд)", Category.VISUAL);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) {
            return;
        }
        if (!p.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
            // -1 = бесконечная длительность
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, -1, 0, false, false));
        }
    }

    @Override
    public void onDisable() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p == null) {
            return;
        }
        StatusEffectInstance current = p.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (current != null && current.getDuration() == -1) {
            p.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }
}
