package dev.umear.module;

import dev.umear.setting.BoolSetting;
import dev.umear.setting.NumSetting;
import dev.umear.util.Targets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

public class AutoAttack extends Module {
    public final NumSetting range = add(new NumSetting("Range", 3.0, 1.0, 6.0, 0.1));
    public final BoolSetting players = add(new BoolSetting("Players", true));
    public final BoolSetting hostile = add(new BoolSetting("Hostile", true));
    public final BoolSetting passive = add(new BoolSetting("Passive", false));
    public final BoolSetting rotate = add(new BoolSetting("Rotate", false));
    public final BoolSetting walls = add(new BoolSetting("Through walls", false));

    public AutoAttack() {
        super("AutoAttack", "Автоматически бьёт ближайшую цель в радиусе", Category.COMBAT);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null || mc.interactionManager == null) {
            return;
        }
        if (mc.currentScreen != null || !player.isAlive() || player.isSpectator()) {
            return;
        }

        Vec3d eye = player.getEyePos();
        double maxSq = range.get() * range.get();
        Entity best = null;
        double bestSq = Double.MAX_VALUE;

        for (Entity e : mc.world.getEntities()) {
            if (!Targets.valid(e, player, players.get(), hostile.get(), passive.get())) {
                continue;
            }
            double d = Targets.distanceSq(eye, e.getBoundingBox());
            if (d > maxSq || d >= bestSq) {
                continue;
            }
            if (!walls.get() && !player.canSee(e)) {
                continue;
            }
            best = e;
            bestSq = d;
        }

        if (best == null) {
            return;
        }

        if (rotate.get()) {
            Vec3d t = best.getBoundingBox().getCenter();
            double dx = t.x - eye.x;
            double dy = t.y - eye.y;
            double dz = t.z - eye.z;
            double horizontal = Math.sqrt(dx * dx + dz * dz);
            player.setYaw((float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F);
            player.setPitch((float) -Math.toDegrees(Math.atan2(dy, horizontal)));
        }

        if (player.getAttackCooldownProgress(0.5F) < 1.0F) {
            return;
        }

        mc.interactionManager.attackEntity(player, best);
        player.swingHand(Hand.MAIN_HAND);
    }
}
