package dev.umear.module;

import dev.umear.setting.NumSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

public class Fly extends Module {
    public final NumSetting speed = add(new NumSetting("Speed", 0.1, 0.05, 1.0, 0.05));

    public Fly() {
        super("Fly", "Полёт как в творческом режиме (двойной прыжок)", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p != null && !p.isOnGround()) {
            p.getAbilities().flying = true;
        }
    }

    @Override
    public void onDisable() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p == null) {
            return;
        }
        var abilities = p.getAbilities();
        if (!p.isCreative() && !p.isSpectator()) {
            abilities.allowFlying = false;
            abilities.flying = false;
        }
        abilities.setFlySpeed(0.05F);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) {
            return;
        }
        var abilities = p.getAbilities();
        abilities.allowFlying = true;
        abilities.setFlySpeed((float) speed.get());
    }
}
