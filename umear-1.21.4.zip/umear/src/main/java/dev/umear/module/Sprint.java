package dev.umear.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

public class Sprint extends Module {
    public Sprint() {
        super("Sprint", "Автоматический спринт при движении вперёд", Category.MOVEMENT);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) {
            return;
        }
        boolean forward = mc.options.forwardKey.isPressed();
        if (forward && !p.isSneaking() && !p.horizontalCollision && !p.isUsingItem()
                && p.getHungerManager().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }
}
