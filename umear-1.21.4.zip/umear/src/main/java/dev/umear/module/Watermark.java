package dev.umear.module;

import dev.umear.setting.BoolSetting;

public class Watermark extends Module {
    public final BoolSetting fps = add(new BoolSetting("FPS", true));

    public Watermark() {
        super("Watermark", "Ватермарк umear в углу экрана", Category.VISUAL);
        showInList = false;
        restoreEnabled(true);
    }
}
