package dev.umear.module;

import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // Combat
        modules.add(new AutoAttack());
        modules.add(new Hitboxes());
        // Movement
        modules.add(new Sprint());
        modules.add(new Fly());
        // Visual
        modules.add(new Esp());
        modules.add(new Fullbright());
        modules.add(new Watermark());
        modules.add(new ModuleList());
    }

    public List<Module> all() {
        return modules;
    }

    public List<Module> byCategory(Category category) {
        List<Module> result = new ArrayList<>();
        for (Module m : modules) {
            if (m.category == category) {
                result.add(m);
            }
        }
        return result;
    }

    public <T extends Module> T get(Class<T> type) {
        for (Module m : modules) {
            if (type.isInstance(m)) {
                return type.cast(m);
            }
        }
        return null;
    }

    public void tick(MinecraftClient mc) {
        for (Module m : modules) {
            if (m.isEnabled()) {
                m.onTick(mc);
            }
        }
    }
}
