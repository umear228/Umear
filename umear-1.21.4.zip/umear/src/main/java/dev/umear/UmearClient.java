package dev.umear;

import dev.umear.gui.ClickGuiScreen;
import dev.umear.module.ModuleManager;
import dev.umear.util.Config;
import dev.umear.util.Hud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class UmearClient implements ClientModInitializer {
    public static final String NAME = "umear";

    /** Клавиша меню. Меняется в самом меню или в Настройки -> Управление. */
    public static KeyBinding menuKey;
    public static ModuleManager modules;

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.umear.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.umear"
        ));

        modules = new ModuleManager();
        Config.load();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ClickGuiScreen());
                }
            }
            if (client.player == null || client.world == null) {
                return;
            }
            modules.tick(client);
        });

        HudRenderCallback.EVENT.register(Hud::render);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Config.save());
    }
}
