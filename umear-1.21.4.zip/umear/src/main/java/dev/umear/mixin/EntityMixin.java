package dev.umear.mixin;

import dev.umear.UmearClient;
import dev.umear.module.Esp;
import dev.umear.module.Hitboxes;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {

    /** Hitboxes: увеличиваем область прицеливания (используется при поиске цели под курсором). */
    @Inject(method = "getTargetingMargin", at = @At("HEAD"), cancellable = true)
    private void umear$targetingMargin(CallbackInfoReturnable<Float> cir) {
        if (UmearClient.modules == null) {
            return;
        }
        Hitboxes hitboxes = UmearClient.modules.get(Hitboxes.class);
        if (hitboxes != null && hitboxes.isEnabled() && hitboxes.applies((Entity) (Object) this)) {
            cir.setReturnValue((float) hitboxes.size.get());
        }
    }

    /** ESP: включаем ванильную обводку (видно сквозь стены). */
    @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true)
    private void umear$glowing(CallbackInfoReturnable<Boolean> cir) {
        if (UmearClient.modules == null) {
            return;
        }
        Esp esp = UmearClient.modules.get(Esp.class);
        if (esp != null && esp.isEnabled() && esp.applies((Entity) (Object) this)) {
            cir.setReturnValue(true);
        }
    }

    /** ESP: цвет обводки. */
    @Inject(method = "getTeamColorValue", at = @At("HEAD"), cancellable = true)
    private void umear$teamColor(CallbackInfoReturnable<Integer> cir) {
        if (UmearClient.modules == null) {
            return;
        }
        Esp esp = UmearClient.modules.get(Esp.class);
        Entity self = (Entity) (Object) this;
        if (esp != null && esp.isEnabled() && esp.applies(self)) {
            cir.setReturnValue(esp.colorFor(self));
        }
    }
}
