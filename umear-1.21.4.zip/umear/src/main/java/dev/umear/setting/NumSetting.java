package dev.umear.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.Locale;

public class NumSetting extends Setting {
    public final double min;
    public final double max;
    public final double step;
    private double value;

    public NumSetting(String name, double defaultValue, double min, double max, double step) {
        super(name);
        this.min = min;
        this.max = max;
        this.step = step;
        set(defaultValue);
    }

    public double get() {
        return value;
    }

    public void set(double v) {
        v = Math.round(v / step) * step;
        v = Math.round(v * 1000.0) / 1000.0;
        value = Math.max(min, Math.min(max, v));
    }

    public String display() {
        if (step >= 1.0) {
            return String.valueOf((int) value);
        }
        return String.format(Locale.ROOT, "%.2f", value);
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(value);
    }

    @Override
    public void fromJson(JsonElement element) {
        if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) {
            set(element.getAsDouble());
        }
    }
}
