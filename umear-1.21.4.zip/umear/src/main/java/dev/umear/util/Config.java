package dev.umear.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.umear.UmearClient;
import dev.umear.module.Module;
import dev.umear.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private Config() {
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("umear.json");
    }

    public static void save() {
        if (UmearClient.modules == null) {
            return;
        }
        try {
            JsonObject root = new JsonObject();
            for (Module m : UmearClient.modules.all()) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.isEnabled());
                JsonObject settings = new JsonObject();
                for (Setting s : m.settings) {
                    settings.add(s.name, s.toJson());
                }
                o.add("settings", settings);
                root.add(m.name, o);
            }
            Files.writeString(file(), GSON.toJson(root));
        } catch (IOException | RuntimeException e) {
            System.err.println("[umear] failed to save config: " + e);
        }
    }

    public static void load() {
        Path f = file();
        if (UmearClient.modules == null || !Files.exists(f)) {
            return;
        }
        try {
            JsonObject root = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            for (Module m : UmearClient.modules.all()) {
                JsonElement el = root.get(m.name);
                if (el == null || !el.isJsonObject()) {
                    continue;
                }
                JsonObject o = el.getAsJsonObject();
                JsonElement en = o.get("enabled");
                if (en != null && en.isJsonPrimitive() && en.getAsJsonPrimitive().isBoolean()) {
                    m.restoreEnabled(en.getAsBoolean());
                }
                JsonElement se = o.get("settings");
                if (se != null && se.isJsonObject()) {
                    JsonObject settings = se.getAsJsonObject();
                    for (Setting s : m.settings) {
                        s.fromJson(settings.get(s.name));
                    }
                }
            }
        } catch (IOException | RuntimeException e) {
            System.err.println("[umear] failed to load config: " + e);
        }
    }
}
