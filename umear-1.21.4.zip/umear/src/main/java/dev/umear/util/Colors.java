package dev.umear.util;

public final class Colors {
    public static final int ACCENT = 0xFFB388FF;

    private Colors() {
    }

    /** Плавный фиолетово-голубой градиент, index сдвигает фазу. */
    public static int wave(int index) {
        double t = System.currentTimeMillis() / 600.0;
        float hue = 0.74F + 0.11F * (float) Math.sin(t + index * 0.45);
        return hsv(hue, 0.55F, 1.0F);
    }

    public static int hsv(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        float scaled = h * 6.0F;
        int i = (int) scaled;
        float f = scaled - i;
        float p = v * (1.0F - s);
        float q = v * (1.0F - f * s);
        float t = v * (1.0F - (1.0F - f) * s);
        float r;
        float g;
        float b;
        switch (i % 6) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return 0xFF000000 | ((int) (r * 255.0F) << 16) | ((int) (g * 255.0F) << 8) | (int) (b * 255.0F);
    }
}
