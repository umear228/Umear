package dev.umear.util;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Targets {
    private Targets() {
    }

    public static boolean valid(Entity entity, Entity self, boolean players, boolean hostile, boolean passive) {
        if (entity == self || !(entity instanceof LivingEntity)) {
            return false;
        }
        LivingEntity living = (LivingEntity) entity;
        if (!living.isAlive() || living.isSpectator() || living instanceof ArmorStandEntity) {
            return false;
        }
        if (living instanceof PlayerEntity) {
            return players;
        }
        if (living instanceof Monster) {
            return hostile;
        }
        return passive;
    }

    /** Квадрат расстояния от точки до ближайшей точки бокса. */
    public static double distanceSq(Vec3d point, Box box) {
        double dx = point.x - MathHelper.clamp(point.x, box.minX, box.maxX);
        double dy = point.y - MathHelper.clamp(point.y, box.minY, box.maxY);
        double dz = point.z - MathHelper.clamp(point.z, box.minZ, box.maxZ);
        return dx * dx + dy * dy + dz * dz;
    }
}
