package dev.umear.util;

import dev.umear.UmearClient;
import dev.umear.module.Module;
import dev.umear.module.ModuleList;
import dev.umear.module.Watermark;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class Hud {
    private Hud() {
    }

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (UmearClient.modules == null || mc.options.hudHidden) {
            return;
        }
        TextRenderer tr = mc.textRenderer;

        Watermark watermark = UmearClient.modules.get(Watermark.class);
        if (watermark != null && watermark.isEnabled()) {
            drawWatermark(ctx, tr, mc, watermark);
        }

        ModuleList list = UmearClient.modules.get(ModuleList.class);
        if (list != null && list.isEnabled()) {
            drawModuleList(ctx, tr, mc);
        }
    }

    private static void drawWatermark(DrawContext ctx, TextRenderer tr, MinecraftClient mc, Watermark watermark) {
        String name = UmearClient.NAME;
        String extra = watermark.fps.get() ? "  |  " + mc.getCurrentFps() + " fps" : "";
        int x = 4;
        int y = 4;
        int width = 5 + tr.getWidth(name) + tr.getWidth(extra) + 5;

        ctx.fill(x, y, x + width, y + 14, 0xA0101014);
        ctx.fill(x, y, x + width, y + 1, Colors.wave(0));

        int cx = x + 5;
        for (int i = 0; i < name.length(); i++) {
            String ch = String.valueOf(name.charAt(i));
            ctx.drawTextWithShadow(tr, ch, cx, y + 3, Colors.wave(i));
            cx += tr.getWidth(ch);
        }
        if (!extra.isEmpty()) {
            ctx.drawTextWithShadow(tr, extra, cx, y + 3, 0xFFAAAAAA);
        }
    }

    private static void drawModuleList(DrawContext ctx, TextRenderer tr, MinecraftClient mc) {
        List<Module> active = new ArrayList<>();
        for (Module m : UmearClient.modules.all()) {
            if (m.isEnabled() && m.showInList) {
                active.add(m);
            }
        }
        active.sort(Comparator.comparingInt((Module m) -> -tr.getWidth(m.name)));

        int screenWidth = mc.getWindow().getScaledWidth();
        int y = 4;
        int i = 0;
        for (Module m : active) {
            int w = tr.getWidth(m.name);
            int x = screenWidth - w - 8;
            int color = Colors.wave(i);
            ctx.fill(x - 3, y, screenWidth, y + 11, 0x90101014);
            ctx.fill(screenWidth - 2, y, screenWidth, y + 11, color);
            ctx.drawTextWithShadow(tr, m.name, x, y + 2, color);
            y += 11;
            i++;
        }
    }
}
