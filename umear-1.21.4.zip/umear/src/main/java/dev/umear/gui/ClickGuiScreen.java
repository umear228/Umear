package dev.umear.gui;

import dev.umear.UmearClient;
import dev.umear.module.Category;
import dev.umear.module.Module;
import dev.umear.setting.BoolSetting;
import dev.umear.setting.NumSetting;
import dev.umear.setting.Setting;
import dev.umear.util.Colors;
import dev.umear.util.Config;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ClickGuiScreen extends Screen {
    private static final int PW = 118;
    private static final int HEADER = 16;
    private static final int ROW = 14;
    private static final int SROW = 12;
    private static final int GAP = 8;
    private static final int TOP = 14;

    private static final String MENU_KEY_TARGET = "menu_key";
    private static final Set<Module> EXPANDED = new HashSet<>();

    private final List<Hit> hits = new ArrayList<>();
    private boolean rebinding;
    private NumSetting dragging;
    private Hit dragHit;
    private Module hovered;

    private record Hit(int x, int y, int w, int h, Object target) {
        boolean contains(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    public ClickGuiScreen() {
        super(Text.literal("umear"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        Config.save();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        hits.clear();
        hovered = null;

        ctx.fill(0, 0, width, height, 0x88000000);

        Category[] categories = Category.values();
        int panels = categories.length + 1;
        int total = panels * PW + (panels - 1) * GAP;
        int x = (width - total) / 2;

        for (Category category : categories) {
            int y = TOP;
            drawHeader(ctx, x, y, category.label);
            y += HEADER;

            for (Module m : UmearClient.modules.byCategory(category)) {
                boolean over = mouseX >= x && mouseX < x + PW && mouseY >= y && mouseY < y + ROW;
                if (over) {
                    hovered = m;
                }
                int bg;
                if (m.isEnabled()) {
                    bg = over ? 0xE0604A9E : 0xE04B3A80;
                } else {
                    bg = over ? 0xE02C2C36 : 0xE01C1C22;
                }
                ctx.fill(x, y, x + PW, y + ROW, bg);
                ctx.drawTextWithShadow(textRenderer, m.name, x + 5, y + 3,
                        m.isEnabled() ? 0xFFFFFFFF : 0xFFBBBBBB);
                if (!m.settings.isEmpty()) {
                    ctx.drawTextWithShadow(textRenderer, EXPANDED.contains(m) ? "-" : "+", x + PW - 10, y + 3, 0xFF888888);
                }
                hits.add(new Hit(x, y, PW, ROW, m));
                y += ROW;

                if (EXPANDED.contains(m)) {
                    for (Setting s : m.settings) {
                        drawSetting(ctx, s, x, y);
                        y += SROW;
                    }
                }
            }
            ctx.fill(x, y, x + PW, y + 2, Colors.ACCENT);
            x += PW + GAP;
        }

        // Панель "Menu" с настройкой клавиши
        int y = TOP;
        drawHeader(ctx, x, y, "Menu");
        y += HEADER;
        boolean over = mouseX >= x && mouseX < x + PW && mouseY >= y && mouseY < y + ROW;
        ctx.fill(x, y, x + PW, y + ROW, over ? 0xE02C2C36 : 0xE01C1C22);
        String keyText = rebinding
                ? "Key: press a key..."
                : "Key: " + UmearClient.menuKey.getBoundKeyLocalizedText().getString();
        ctx.drawTextWithShadow(textRenderer, keyText, x + 5, y + 3, rebinding ? Colors.ACCENT : 0xFFFFFFFF);
        hits.add(new Hit(x, y, PW, ROW, MENU_KEY_TARGET));
        y += ROW;
        ctx.fill(x, y, x + PW, y + 24, 0xE00F0F13);
        ctx.drawTextWithShadow(textRenderer, "LMB: on/off", x + 5, y + 2, 0xFF888888);
        ctx.drawTextWithShadow(textRenderer, "RMB: settings", x + 5, y + 13, 0xFF888888);
        y += 24;
        ctx.fill(x, y, x + PW, y + 2, Colors.ACCENT);

        if (hovered != null) {
            int tw = textRenderer.getWidth(hovered.description);
            ctx.drawTextWithShadow(textRenderer, hovered.description, (width - tw) / 2, height - 14, 0xFFCCCCCC);
        }
    }

    private void drawHeader(DrawContext ctx, int x, int y, String label) {
        ctx.fill(x, y, x + PW, y + HEADER, 0xF0141418);
        ctx.fill(x, y, x + PW, y + 1, Colors.ACCENT);
        ctx.drawTextWithShadow(textRenderer, label, x + 5, y + 4, Colors.ACCENT);
    }

    private void drawSetting(DrawContext ctx, Setting s, int x, int y) {
        ctx.fill(x, y, x + PW, y + SROW, 0xE00F0F13);
        if (s instanceof BoolSetting b) {
            ctx.drawTextWithShadow(textRenderer, b.name, x + 8, y + 2, 0xFFCCCCCC);
            int bx = x + PW - 14;
            ctx.fill(bx, y + 2, bx + 8, y + SROW - 2, b.get() ? Colors.ACCENT : 0xFF3A3A44);
            hits.add(new Hit(x, y, PW, SROW, b));
        } else if (s instanceof NumSetting n) {
            int sx = x + 3;
            int sw = PW - 6;
            double frac = (n.get() - n.min) / (n.max - n.min);
            ctx.fill(sx, y + 1, sx + sw, y + SROW - 1, 0xFF1D1D24);
            ctx.fill(sx, y + 1, sx + (int) (sw * frac), y + SROW - 1, 0xA0B388FF);
            ctx.drawTextWithShadow(textRenderer, n.name + ": " + n.display(), sx + 4, y + 2, 0xFFFFFFFF);
            hits.add(new Hit(sx, y, sw, SROW, n));
        }
    }

    private void slide(double mouseX) {
        if (dragging == null || dragHit == null) {
            return;
        }
        double f = (mouseX - dragHit.x()) / (double) dragHit.w();
        f = Math.max(0.0, Math.min(1.0, f));
        dragging.set(dragging.min + f * (dragging.max - dragging.min));
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (rebinding) {
            rebinding = false;
            return true;
        }
        for (Hit h : hits) {
            if (!h.contains(mouseX, mouseY)) {
                continue;
            }
            Object t = h.target();
            if (t instanceof Module m) {
                if (button == 0) {
                    m.toggle();
                } else if (button == 1 && !m.settings.isEmpty()) {
                    if (!EXPANDED.remove(m)) {
                        EXPANDED.add(m);
                    }
                }
            } else if (t instanceof BoolSetting b) {
                if (button == 0) {
                    b.toggle();
                }
            } else if (t instanceof NumSetting n) {
                if (button == 0) {
                    dragging = n;
                    dragHit = h;
                    slide(mouseX);
                }
            } else if (MENU_KEY_TARGET.equals(t)) {
                if (button == 0) {
                    rebinding = true;
                }
            }
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging != null && button == 0) {
            slide(mouseX);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = null;
        dragHit = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (rebinding) {
            if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                KeyBinding key = UmearClient.menuKey;
                key.setBoundKey(InputUtil.fromKeyCode(keyCode, scanCode));
                KeyBinding.updateKeysByCode();
                client.options.write();
            }
            rebinding = false;
            return true;
        }
        if (UmearClient.menuKey.matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
