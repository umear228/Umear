# umear client (Fabric, Minecraft Java 1.21.4)

Функции:
- Combat: AutoAttack (авто-атака), Hitboxes (увеличение хитбоксов)
- Movement: Sprint, Fly
- Visual: ESP (подсветка сквозь стены), Fullbright, Watermark "umear", ModuleList

Меню: клавиша по умолчанию Right Shift. Поменять можно в самом меню (панель "Menu" -> Key)
или в Настройки -> Управление -> umear.
ЛКМ по функции = вкл/выкл, ПКМ = настройки.
Конфиг: .minecraft/config/umear.json

Сборка (нужны JDK 21 и Gradle 8.12+):
    gradle wrapper --gradle-version 8.12   (один раз)
    ./gradlew build                        (Windows: gradlew.bat build)
Готовый мод: build/libs/umear-1.0.0.jar -> в папку mods вместе с Fabric Loader и Fabric API для 1.21.4.
