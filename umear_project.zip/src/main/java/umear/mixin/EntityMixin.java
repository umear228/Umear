package umear.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import umear.modules.Hitbox;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "getTargetingMargin", at = @At("HEAD"), cancellable = true)
    private void umear$targetingMargin(CallbackInfoReturnable<Float> cir) {
        Hitbox h = Hitbox.INSTANCE;
        if (h != null && h.enabled && (Object) this instanceof PlayerEntity pe
                && pe != MinecraftClient.getInstance().player) {
            cir.setReturnValue((float) h.expand.value);
        }
    }
}
