package umear.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;
import umear.UmearClient;
import umear.module.Category;
import umear.module.Module;
import umear.module.ModuleManager;
import umear.module.Setting;
import umear.util.Theme;

import java.util.ArrayList;
import java.util.List;

public class ClickGui extends Screen {
    private static final int PW = 400, PH = 260;
    private static final int TAB_W = 88;

    private Category tab = Category.COMBAT;
    private int scroll;
    private Module expanded;
    private Setting.Num dragging;
    private int dragX0, dragW;
    private boolean waitingKey;
    private final long openedAt = System.currentTimeMillis();

    private record Row(int y, int h, Module m, Setting s, boolean key) {
    }

    public ClickGui() {
        super(Text.literal("umear"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private int x0() {
        return (width - PW) / 2;
    }

    private int y0() {
        return (height - PH) / 2;
    }

    private static Identifier icon(Category c) {
        return Identifier.of("umear", "textures/gui/tab_" + c.name().toLowerCase() + ".png");
    }

    private List<Row> rows() {
        List<Row> out = new ArrayList<>();
        int y = y0() + 50 - scroll;
        for (Module m : ModuleManager.byCategory(tab)) {
            out.add(new Row(y, 20, m, null, false));
            y += 22;
            if (m == expanded || m.alwaysOn) {
                for (Setting s : m.settings) {
                    out.add(new Row(y, 16, m, s, false));
                    y += 18;
                }
                y += 2;
            }
        }
        if (tab == Category.SETTINGS) {
            out.add(new Row(y, 20, null, null, true));
        }
        return out;
    }

    private int contentHeight() {
        List<Row> r = rows();
        if (r.isEmpty()) return 0;
        Row last = r.get(r.size() - 1);
        return last.y + last.h + scroll - (y0() + 50);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int x = x0(), y = y0(), acc = Theme.accent();
        ctx.fill(0, 0, width, height, 0x80000000);
        ctx.fill(x, y, x + PW, y + PH, 0xF00E0C18);
        ctx.fill(x, y, x + PW, y + 2, acc);
        ctx.drawTextWithShadow(textRenderer, "umear", x + 10, y + 8, acc);
        ctx.drawTextWithShadow(textRenderer, "client", x + 10 + textRenderer.getWidth("umear "), y + 8, 0xFFAAAAAA);

        int tx = x + 10;
        for (Category c : Category.values()) {
            boolean sel = c == tab;
            ctx.fill(tx, y + 22, tx + TAB_W, y + 44, sel ? 0xFF241E3A : 0xFF15121F);
            if (sel) ctx.fill(tx, y + 42, tx + TAB_W, y + 44, acc);
            ctx.drawTexture(RenderLayer::getGuiTextured, icon(c), tx + 4, y + 25, 0f, 0f, 16, 16, 16, 16);
            ctx.drawTextWithShadow(textRenderer, c.label, tx + 24, y + 29, sel ? 0xFFFFFFFF : 0xFFAAAAAA);
            tx += TAB_W + 4;
        }

        ctx.enableScissor(x + 6, y + 48, x + PW - 6, y + PH - 6);
        for (Row r : rows()) drawRow(ctx, r, x, acc);
        ctx.disableScissor();
    }

    private void drawRow(DrawContext ctx, Row r, int x, int acc) {
        int left = x + 10, right = x + PW - 10;
        if (r.key) {
            ctx.fill(left, r.y, right, r.y + r.h, 0xFF1B1830);
            String txt = waitingKey ? "Menu key: press a key..." : "Menu key: " + UmearClient.menuKey.getBoundKeyLocalizedText().getString();
            ctx.drawTextWithShadow(textRenderer, txt, left + 6, r.y + 6, 0xFFFFFFFF);
            return;
        }
        if (r.s == null) {
            ctx.fill(left, r.y, right, r.y + r.h, r.m.enabled && !r.m.alwaysOn ? Theme.alpha(acc, 110) : 0xFF1B1830);
            ctx.drawTextWithShadow(textRenderer, r.m.name, left + 6, r.y + 6, 0xFFFFFFFF);
            if (!r.m.alwaysOn) {
                String st = r.m.enabled ? "ON" : "OFF";
                ctx.drawTextWithShadow(textRenderer, st, right - 6 - textRenderer.getWidth(st), r.y + 6,
                        r.m.enabled ? 0xFFFFFFFF : 0xFF888888);
                if (!r.m.settings.isEmpty()) {
                    String arrow = r.m == expanded ? "v" : ">";
                    ctx.drawTextWithShadow(textRenderer, arrow, right - 40, r.y + 6, 0xFF888888);
                }
            }
            return;
        }
        int l = left + 12;
        ctx.fill(l, r.y, right, r.y + r.h, 0xFF15121F);
        Setting s = r.s;
        if (s instanceof Setting.Bool b) {
            ctx.drawTextWithShadow(textRenderer, b.name, l + 6, r.y + 4, 0xFFDDDDDD);
            String st = b.value ? "ON" : "OFF";
            ctx.drawTextWithShadow(textRenderer, st, right - 6 - textRenderer.getWidth(st), r.y + 4, b.value ? acc : 0xFF888888);
        } else if (s instanceof Setting.Mode md) {
            ctx.drawTextWithShadow(textRenderer, md.name, l + 6, r.y + 4, 0xFFDDDDDD);
            String st = "< " + md.value + " >";
            ctx.drawTextWithShadow(textRenderer, st, right - 6 - textRenderer.getWidth(st), r.y + 4, acc);
        } else if (s instanceof Setting.Num n) {
            double frac = (n.value - n.min) / (n.max - n.min);
            ctx.fill(l, r.y, l + (int) ((right - l) * frac), r.y + r.h, Theme.alpha(acc, 90));
            ctx.drawTextWithShadow(textRenderer, n.name, l + 6, r.y + 4, 0xFFDDDDDD);
            String v = n.step >= 1 ? String.valueOf(n.i()) : String.format("%.2f", n.value);
            ctx.drawTextWithShadow(textRenderer, v, right - 6 - textRenderer.getWidth(v), r.y + 4, 0xFFFFFFFF);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        int x = x0(), y = y0();
        if (my >= y + 22 && my < y + 44) {
            int tx = x + 10;
            for (Category c : Category.values()) {
                if (mx >= tx && mx < tx + TAB_W) {
                    tab = c;
                    scroll = 0;
                    expanded = null;
                    return true;
                }
                tx += TAB_W + 4;
            }
        }
        if (my < y + 48 || my > y + PH - 6) return super.mouseClicked(mx, my, btn);
        for (Row r : rows()) {
            if (my < r.y || my >= r.y + r.h || mx < x + 10 || mx >= x + PW - 10) continue;
            if (r.key) {
                waitingKey = true;
            } else if (r.s == null) {
                if (btn == 0) r.m.toggle();
                else if (btn == 1 && !r.m.alwaysOn && !r.m.settings.isEmpty()) expanded = expanded == r.m ? null : r.m;
            } else if (r.s instanceof Setting.Bool b) {
                b.value = !b.value;
            } else if (r.s instanceof Setting.Mode md) {
                md.cycle(btn == 1 ? -1 : 1);
            } else if (r.s instanceof Setting.Num n) {
                dragging = n;
                dragX0 = x + 22;
                dragW = PW - 44;
                setFromMouse(mx);
            }
            return true;
        }
        return super.mouseClicked(mx, my, btn);
    }

    private void setFromMouse(double mx) {
        if (dragging == null) return;
        double frac = MathHelper.clamp((mx - dragX0) / dragW, 0.0, 1.0);
        dragging.set(dragging.min + (dragging.max - dragging.min) * frac);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (dragging != null) {
            setFromMouse(mx);
            return true;
        }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        if (dragging != null) {
            dragging = null;
            ModuleManager.save();
        }
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        int maxScroll = Math.max(0, contentHeight() - (PH - 60));
        scroll = MathHelper.clamp(scroll - (int) (vertical * 16), 0, maxScroll);
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (waitingKey) {
            if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                UmearClient.menuKey.setBoundKey(InputUtil.fromKeyCode(keyCode, scanCode));
                KeyBinding.updateKeysByCode();
                client.options.write();
            }
            waitingKey = false;
            return true;
        }
        if (System.currentTimeMillis() - openedAt > 200 && UmearClient.menuKey.matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        ModuleManager.save();
        super.removed();
    }
}
