package umear.modules;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import umear.module.Category;
import umear.module.Module;
import umear.module.Setting;
import umear.util.CombatUtil;
import umear.util.Targets;

public class KillAura extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 3.5, 2.0, 6.0, 0.1));
    private final Setting.Mode priority = add(new Setting.Mode("Priority", "Distance", "Distance", "Health"));
    private final Setting.Bool silent = add(new Setting.Bool("Silent rotation", true));
    private final Setting.Bool playersOnly = add(new Setting.Bool("Players only", true));
    private final Setting.Bool onlyCrits = add(new Setting.Bool("Only crits", false));
    private final Setting.Num minCooldown = add(new Setting.Num("Min cooldown", 0.92, 0.5, 1.0, 0.01));
    private float jitter;

    public KillAura() {
        super("KillAura", Category.COMBAT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null || p.isUsingItem() || !p.isAlive()) return;
        if (p.getAttackCooldownProgress(0.5f) < Math.min(1.0f, minCooldown.f() + jitter)) return;
        if (onlyCrits.value && !CombatUtil.critFalling(p)) return;

        Vec3d eye = p.getEyePos();
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        Iterable<? extends Entity> list = playersOnly.value ? mc.world.getPlayers() : mc.world.getEntities();
        for (Entity e : list) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le instanceof ArmorStandEntity) continue;
            if (e.isSpectator()) continue;
            if (playersOnly.value && !(e instanceof PlayerEntity)) continue;
            double d = eye.distanceTo(CombatUtil.nearestPoint(eye, e.getBoundingBox()));
            if (d > range.value) continue;
            double score = priority.is("Health") ? le.getHealth() : d;
            if (score < bestScore) {
                bestScore = score;
                best = le;
            }
        }
        if (best == null) return;

        Vec3d point = CombatUtil.nearestPoint(eye, best.getBoundingBox());
        // aim at the middle of the closest point to avoid edge misses
        Vec3d aim = new Vec3d(point.x, Math.min(Math.max(point.y, best.getY() + 0.2), best.getY() + best.getHeight() - 0.2), point.z);
        float[] rot = CombatUtil.rotations(eye, aim);

        if (silent.value) {
            boolean ground = p.isOnGround();
            boolean hc = p.horizontalCollision;
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(rot[0], rot[1], ground, hc));
            mc.interactionManager.attackEntity(p, best);
            p.swingHand(Hand.MAIN_HAND);
            // restore the real rotation on the server
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(p.getYaw(), p.getPitch(), ground, hc));
        } else {
            p.setYaw(rot[0]);
            p.setPitch(rot[1]);
            mc.interactionManager.attackEntity(p, best);
            p.swingHand(Hand.MAIN_HAND);
        }
        Targets.set(best);
        jitter = (float) (Math.random() * 0.06);
    }
}
