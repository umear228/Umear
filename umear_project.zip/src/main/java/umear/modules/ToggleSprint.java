package umear.modules;

import net.minecraft.client.network.ClientPlayerEntity;
import umear.module.Category;
import umear.module.Module;

public class ToggleSprint extends Module {
    public ToggleSprint() {
        super("ToggleSprint", Category.MISC);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (mc.options.forwardKey.isPressed() && !p.isSneaking() && !p.horizontalCollision
                && !p.isUsingItem() && p.getHungerManager().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }
}
