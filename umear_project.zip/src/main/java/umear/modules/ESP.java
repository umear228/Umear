package umear.modules;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import umear.module.Category;
import umear.module.Module;
import umear.module.Setting;
import umear.util.LineBatch;
import umear.util.RenderData;
import umear.util.Theme;

public class ESP extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 64, 16, 128, 4));
    private final Setting.Bool walls = add(new Setting.Bool("Through walls", true));
    private final Setting.Bool mobs = add(new Setting.Bool("Mobs", false));
    private final Setting.Bool healthColor = add(new Setting.Bool("Health color", true));

    public ESP() {
        super("ESP", Category.VISUAL);
    }

    @Override
    public void onWorld(RenderData rd) {
        double r2 = range.value * range.value;
        LineBatch b = walls.value ? rd.over : rd.depth;
        for (AbstractClientPlayerEntity pl : mc.world.getPlayers()) {
            draw(pl, rd, b, r2);
        }
        if (mobs.value) {
            for (Entity e : mc.world.getEntities()) {
                if (e instanceof LivingEntity le && !(e instanceof PlayerEntity) && !(e instanceof ArmorStandEntity)) {
                    draw(le, rd, b, r2);
                }
            }
        }
    }

    private void draw(LivingEntity e, RenderData rd, LineBatch b, double r2) {
        if (e == mc.player || !e.isAlive() || e.isSpectator()) return;
        if (mc.player.squaredDistanceTo(e) > r2) return;
        Vec3d lp = e.getLerpedPos(rd.tickDelta);
        Box bb = e.getBoundingBox().offset(lp.x - e.getX(), lp.y - e.getY(), lp.z - e.getZ());
        if (!rd.frustum.isVisible(bb)) return;
        int color;
        if (healthColor.value) {
            float ratio = MathHelper.clamp(e.getHealth() / e.getMaxHealth(), 0f, 1f);
            color = 0xFF000000 | ((int) (255 * (1 - ratio)) << 16) | ((int) (255 * ratio) << 8) | 60;
        } else {
            color = Theme.accent();
        }
        b.box(bb, color);
    }
}
