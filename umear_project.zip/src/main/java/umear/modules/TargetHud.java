package umear.modules;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import umear.module.Category;
import umear.module.Module;
import umear.util.Targets;
import umear.util.Theme;

public class TargetHud extends Module {
    private float shown = 1f;

    public TargetHud() {
        super("TargetHUD", Category.VISUAL);
    }

    @Override
    public void onTick() {
        if (mc.targetedEntity != null) Targets.set(mc.targetedEntity);
    }

    @Override
    public void onHud(DrawContext ctx) {
        LivingEntity t = Targets.get();
        if (t == null) return;
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        int w = 150, h = 46;
        int x = sw / 2 + 24, y = sh / 2 + 16;
        int acc = Theme.accent();

        float ratio = MathHelper.clamp(t.getHealth() / t.getMaxHealth(), 0f, 1f);
        shown += (ratio - shown) * 0.15f;

        ctx.fill(x, y, x + w, y + h, 0xC00E0C18);
        ctx.fill(x, y, x + 2, y + h, acc);
        ctx.drawTextWithShadow(mc.textRenderer, t.getName().getString(), x + 8, y + 6, 0xFFFFFFFF);

        int barX = x + 8, barY = y + 20, barW = w - 16;
        ctx.fill(barX, barY, barX + barW, barY + 6, 0xFF241E3A);
        ctx.fill(barX, barY, barX + (int) (barW * shown), barY + 6, acc);

        String hp = String.format("%.1f / %.0f", t.getHealth(), t.getMaxHealth());
        ctx.drawTextWithShadow(mc.textRenderer, hp, x + 8, y + 31, 0xFFCCCCCC);
        String info = String.format("%.1fm  A:%d", mc.player.distanceTo(t), t.getArmor());
        ctx.drawTextWithShadow(mc.textRenderer, info, x + w - 8 - mc.textRenderer.getWidth(info), y + 31, 0xFFAAAAAA);
    }
}
