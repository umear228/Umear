package umear.modules;

import umear.module.Category;
import umear.module.Module;
import umear.module.Setting;

public class ClientSettings extends Module {
    public static ClientSettings INSTANCE;
    public final Setting.Bool watermark = add(new Setting.Bool("Watermark", true));
    public final Setting.Mode accent = add(new Setting.Mode("Accent color", "Purple", "Purple", "Cyan", "Red", "Green"));

    public ClientSettings() {
        super("Client", Category.SETTINGS);
        alwaysOn = true;
        enabled = true;
        INSTANCE = this;
    }
}
