package umear.modules;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import umear.module.Category;
import umear.module.Module;
import umear.module.Setting;
import umear.util.CombatUtil;
import umear.util.Targets;

public class AutoAttack extends Module {
    private final Setting.Mode mode = add(new Setting.Mode("Mode", "Normal", "Normal", "Shift", "Crit"));
    private final Setting.Bool playersOnly = add(new Setting.Bool("Players only", true));
    private final Setting.Num minCooldown = add(new Setting.Num("Min cooldown", 0.92, 0.5, 1.0, 0.01));
    private final Setting.Num critGap = add(new Setting.Num("Crit ground gap", 1.4, 0.3, 2.5, 0.1));
    private float jitter;

    public AutoAttack() {
        super("AutoAttack", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.currentScreen != null) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
        Entity e = hit.getEntity();
        ClientPlayerEntity p = mc.player;
        if (!(e instanceof LivingEntity) || !e.isAlive() || e == p) return;
        if (playersOnly.value && !(e instanceof PlayerEntity)) return;
        if (p.isUsingItem()) return;
        if (p.getAttackCooldownProgress(0.5f) < Math.min(1.0f, minCooldown.f() + jitter)) return;

        if (mode.is("Shift")) {
            if (!p.isSneaking()) return;
        } else if (mode.is("Crit")) {
            if (!CombatUtil.critReady(p, critGap.value)) return;
        }

        mc.interactionManager.attackEntity(p, e);
        p.swingHand(Hand.MAIN_HAND);
        Targets.set(e);
        jitter = (float) (Math.random() * 0.06);
    }
}
