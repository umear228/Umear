package umear.modules;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import umear.module.Category;
import umear.module.Module;
import umear.module.Setting;
import umear.util.LineBatch;
import umear.util.RenderData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

/**
 * Ore X-Ray: highlights ores through walls using only the data the server sends.
 * Optimized: chunk sections without ores are skipped in O(1), scanning is spread over ticks,
 * and everything is drawn in one batch.
 */
public class XRay extends Module {
    private static final Map<Block, Integer> ORES = new HashMap<>();

    static {
        put(0xFF3CF0E6, Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE);
        put(0xFF22C55E, Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE);
        put(0xFFFACC15, Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.NETHER_GOLD_ORE);
        put(0xFFE5C0A0, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE);
        put(0xFF3B6BFF, Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE);
        put(0xFFFF3030, Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE);
        put(0xFFFF9A3C, Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE);
        put(0xFF8B5A3C, Blocks.ANCIENT_DEBRIS);
        put(0xFFF5F5F5, Blocks.NETHER_QUARTZ_ORE);
        put(0xFF555555, Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE);
    }

    private static void put(int color, Block... blocks) {
        for (Block b : blocks) ORES.put(b, color);
    }

    private static final Predicate<BlockState> IS_ORE = s -> ORES.containsKey(s.getBlock());

    private record Hit(int x, int y, int z, int color) {
    }

    private final Setting.Num chunks = add(new Setting.Num("Range (chunks)", 3, 1, 6, 1));
    private final Setting.Num maxBoxes = add(new Setting.Num("Max boxes", 1200, 200, 4000, 100));
    private final Setting.Bool skipCoal = add(new Setting.Bool("Hide coal", true));

    private final Map<Long, List<Hit>> cache = new HashMap<>();
    private final List<long[]> queue = new ArrayList<>();
    private int cursor;
    private int ticks;

    public XRay() {
        super("X-Ray", Category.VISUAL);
    }

    @Override
    public void onDisable() {
        cache.clear();
        queue.clear();
    }

    @Override
    public void onTick() {
        if (ticks++ % 40 == 0) rebuildQueue();
        // spread the work: a few chunks per tick
        for (int i = 0; i < 4 && !queue.isEmpty(); i++) {
            if (cursor >= queue.size()) cursor = 0;
            long[] c = queue.get(cursor++);
            scanChunk((int) c[0], (int) c[1]);
        }
    }

    private void rebuildQueue() {
        queue.clear();
        int pcx = mc.player.getChunkPos().x, pcz = mc.player.getChunkPos().z;
        int r = chunks.i();
        java.util.Set<Long> keep = new java.util.HashSet<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                queue.add(new long[]{pcx + dx, pcz + dz, (long) dx * dx + (long) dz * dz});
                keep.add(key(pcx + dx, pcz + dz));
            }
        }
        queue.sort((a, b) -> Long.compare(a[2], b[2]));
        cache.keySet().removeIf(k -> !keep.contains(k));
        cursor = 0;
    }

    private static long key(int cx, int cz) {
        return ((long) cx << 32) | (cz & 0xFFFFFFFFL);
    }

    private void scanChunk(int cx, int cz) {
        WorldChunk ch = mc.world.getChunkManager().getWorldChunk(cx, cz);
        if (ch == null) {
            cache.remove(key(cx, cz));
            return;
        }
        List<Hit> out = new ArrayList<>();
        ChunkSection[] secs = ch.getSectionArray();
        for (int i = 0; i < secs.length; i++) {
            ChunkSection s = secs[i];
            if (s == null || !s.hasAny(IS_ORE)) continue;
            int baseY = (ch.getBottomSectionCoord() + i) << 4;
            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        Block blk = s.getBlockState(x, y, z).getBlock();
                        Integer c = ORES.get(blk);
                        if (c == null) continue;
                        if (skipCoal.value && (blk == Blocks.COAL_ORE || blk == Blocks.DEEPSLATE_COAL_ORE)) continue;
                        out.add(new Hit((cx << 4) + x, baseY + y, (cz << 4) + z, c));
                    }
                }
            }
        }
        cache.put(key(cx, cz), out);
    }

    @Override
    public void onWorld(RenderData rd) {
        LineBatch b = rd.over;
        Vec3d look = mc.player.getRotationVec(1.0f);
        double px = rd.cam.x, py = rd.cam.y, pz = rd.cam.z;
        double maxDist = chunks.value * 16 + 16;
        double maxDist2 = maxDist * maxDist;
        int limit = maxBoxes.i();
        int drawn = 0;
        for (List<Hit> list : cache.values()) {
            for (Hit h : list) {
                if (drawn >= limit) return;
                double dx = h.x + 0.5 - px, dy = h.y + 0.5 - py, dz = h.z + 0.5 - pz;
                if (dx * dx + dy * dy + dz * dz > maxDist2) continue;
                // skip blocks behind the camera
                if (dx * look.x + dy * look.y + dz * look.z < -2.0) continue;
                b.box(h.x, h.y, h.z, h.x + 1, h.y + 1, h.z + 1, h.color);
                drawn++;
            }
        }
    }
}
