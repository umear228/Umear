package umear.modules;

import umear.module.Category;
import umear.module.Module;
import umear.module.Setting;

public class Hitbox extends Module {
    public static Hitbox INSTANCE;
    public final Setting.Num expand = add(new Setting.Num("Expand", 0.15, 0.0, 0.6, 0.01));

    public Hitbox() {
        super("Hitbox", Category.COMBAT);
        INSTANCE = this;
    }
}
