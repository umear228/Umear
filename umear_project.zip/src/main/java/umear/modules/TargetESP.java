package umear.modules;

import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import umear.module.Category;
import umear.module.Module;
import umear.module.Setting;
import umear.util.RenderData;
import umear.util.Targets;
import umear.util.Theme;

public class TargetESP extends Module {
    private final Setting.Mode style = add(new Setting.Mode("Style", "Ring", "Ring", "Box", "Both"));

    public TargetESP() {
        super("TargetESP", Category.VISUAL);
    }

    @Override
    public void onWorld(RenderData rd) {
        LivingEntity t = Targets.get();
        if (t == null) return;
        Vec3d lp = t.getLerpedPos(rd.tickDelta);
        int acc = Theme.accent();
        if (!style.is("Box")) {
            double time = System.currentTimeMillis() / 900.0;
            double h = t.getHeight();
            double r = t.getWidth() * 0.8 + 0.15;
            double y1 = lp.y + (Math.sin(time * Math.PI * 2) * 0.5 + 0.5) * h;
            double y2 = lp.y + (Math.sin((time - 0.06) * Math.PI * 2) * 0.5 + 0.5) * h;
            double y3 = lp.y + (Math.sin((time - 0.12) * Math.PI * 2) * 0.5 + 0.5) * h;
            rd.over.ring(lp.x, y1, lp.z, r, acc);
            rd.over.ring(lp.x, y2, lp.z, r, Theme.alpha(acc, 150));
            rd.over.ring(lp.x, y3, lp.z, r, Theme.alpha(acc, 70));
        }
        if (!style.is("Ring")) {
            var bb = t.getBoundingBox().offset(lp.x - t.getX(), lp.y - t.getY(), lp.z - t.getZ()).expand(0.03);
            rd.over.box(bb, acc);
        }
    }
}
