package umear.modules;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;
import umear.module.Category;
import umear.module.Module;
import umear.module.Setting;
import umear.util.RenderData;
import umear.util.Theme;

import java.util.ArrayList;
import java.util.List;

public class JumpCircles extends Module {
    private final Setting.Mode mode = add(new Setting.Mode("Mode", "Open", "Open", "Close"));
    private final Setting.Num radius = add(new Setting.Num("Radius", 1.6, 0.5, 4.0, 0.1));
    private final Setting.Num duration = add(new Setting.Num("Duration (ms)", 900, 300, 2000, 50));

    private record Circle(Vec3d pos, long start) {
    }

    private final List<Circle> circles = new ArrayList<>();
    private boolean wasOnGround = true;

    public JumpCircles() {
        super("JumpCircles", Category.VISUAL);
    }

    @Override
    public void onDisable() {
        circles.clear();
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (wasOnGround && !p.isOnGround() && p.getVelocity().y > 0.1) {
            circles.add(new Circle(p.getPos(), System.currentTimeMillis()));
        }
        wasOnGround = p.isOnGround();
    }

    @Override
    public void onWorld(RenderData rd) {
        long now = System.currentTimeMillis();
        int acc = Theme.accent();
        for (int i = circles.size() - 1; i >= 0; i--) {
            Circle c = circles.get(i);
            double t = (now - c.start) / duration.value;
            if (t >= 1.0) {
                circles.remove(i);
                continue;
            }
            double ease = 1.0 - Math.pow(1.0 - t, 3);
            double r = mode.is("Open") ? radius.value * ease : radius.value * (1.0 - ease);
            int alpha = (int) (255 * (1.0 - t));
            double y = c.pos.y + 0.02;
            rd.depth.ring(c.pos.x, y, c.pos.z, Math.max(0.05, r), Theme.alpha(acc, alpha));
            rd.depth.ring(c.pos.x, y, c.pos.z, Math.max(0.05, r * 0.85), Theme.alpha(acc, alpha / 2));
        }
    }
}
