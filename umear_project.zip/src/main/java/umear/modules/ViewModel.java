package umear.modules;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import umear.module.Category;
import umear.module.Module;
import umear.module.Setting;

public class ViewModel extends Module {
    public static ViewModel INSTANCE;

    private final Setting.Mode swing = add(new Setting.Mode("Swing anim", "Vanilla", "Vanilla", "Slash", "Smooth", "Spin", "Punch"));
    private final Setting.Num x = add(new Setting.Num("X", 0, -1, 1, 0.05));
    private final Setting.Num y = add(new Setting.Num("Y", 0, -1, 1, 0.05));
    private final Setting.Num z = add(new Setting.Num("Z", 0, -1, 1, 0.05));
    private final Setting.Num scale = add(new Setting.Num("Scale", 1.0, 0.3, 1.5, 0.05));
    private final Setting.Num rotX = add(new Setting.Num("Rotate X", 0, -90, 90, 5));
    private final Setting.Num rotY = add(new Setting.Num("Rotate Y", 0, -90, 90, 5));
    private final Setting.Num rotZ = add(new Setting.Num("Rotate Z", 0, -90, 90, 5));

    public ViewModel() {
        super("ViewModel", Category.VISUAL);
        INSTANCE = this;
    }

    public void apply(MatrixStack m, Hand hand, float swingProgress) {
        float side = hand == Hand.MAIN_HAND ? 1f : -1f;
        m.translate(x.f() * side, y.f(), z.f());
        float s = scale.f();
        m.scale(s, s, s);
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(rotX.f()));
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(rotY.f() * side));
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rotZ.f() * side));

        if (swingProgress > 0f) {
            float s1 = MathHelper.sin(swingProgress * (float) Math.PI);
            float s2 = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
            switch (swing.value) {
                case "Slash" -> {
                    m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-s2 * 40f));
                    m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(s1 * 30f * side));
                }
                case "Smooth" -> m.translate(0.0f, -s1 * 0.12f, -s1 * 0.25f);
                case "Spin" -> m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(swingProgress * 360f * side));
                case "Punch" -> m.translate(0.0f, 0.0f, -s2 * 0.6f);
                default -> {
                }
            }
        }
    }
}
