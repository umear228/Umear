package umear.modules;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import umear.module.Category;
import umear.module.Module;
import umear.module.Setting;

import java.util.concurrent.ThreadLocalRandom;

public class HitParticles extends Module {
    public static HitParticles INSTANCE;
    private final Setting.Mode type = add(new Setting.Mode("Type", "Crit", "Crit", "Magic", "Flame", "Heart", "Totem"));
    private final Setting.Num count = add(new Setting.Num("Count", 12, 1, 40, 1));

    public HitParticles() {
        super("HitParticles", Category.VISUAL);
        INSTANCE = this;
    }

    public void spawn(Entity e) {
        if (!enabled || !(e instanceof LivingEntity) || mc.world == null) return;
        ParticleEffect effect = switch (type.value) {
            case "Magic" -> ParticleTypes.ENCHANTED_HIT;
            case "Flame" -> ParticleTypes.FLAME;
            case "Heart" -> ParticleTypes.HEART;
            case "Totem" -> ParticleTypes.TOTEM_OF_UNDYING;
            default -> ParticleTypes.CRIT;
        };
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double w = e.getWidth(), h = e.getHeight();
        for (int i = 0; i < count.i(); i++) {
            double x = e.getX() + (r.nextDouble() - 0.5) * w;
            double y = e.getY() + r.nextDouble() * h;
            double z = e.getZ() + (r.nextDouble() - 0.5) * w;
            mc.world.addParticle(effect, x, y, z,
                    (r.nextDouble() - 0.5) * 0.4, r.nextDouble() * 0.3, (r.nextDouble() - 0.5) * 0.4);
        }
    }
}
