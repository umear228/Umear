package umear.util;

import umear.modules.ClientSettings;

public final class Theme {
    private Theme() {
    }

    public static int accent() {
        ClientSettings cs = ClientSettings.INSTANCE;
        if (cs == null) return 0xFFA855F7;
        return switch (cs.accent.value) {
            case "Cyan" -> 0xFF22D3EE;
            case "Red" -> 0xFFEF4444;
            case "Green" -> 0xFF22C55E;
            default -> 0xFFA855F7;
        };
    }

    public static int alpha(int argb, int a) {
        return (Math.max(0, Math.min(255, a)) << 24) | (argb & 0xFFFFFF);
    }
}
