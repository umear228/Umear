package umear.util;

import net.minecraft.client.render.Frustum;
import net.minecraft.util.math.Vec3d;

public final class RenderData {
    public Vec3d cam;
    public float tickDelta;
    public Frustum frustum;
    /** lines drawn WITHOUT depth test (visible through walls) */
    public final LineBatch over = new LineBatch();
    /** lines drawn WITH depth test */
    public final LineBatch depth = new LineBatch();
}
