package umear.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class CombatUtil {
    private CombatUtil() {
    }

    /** true when the player is falling and a hit will be a critical hit */
    public static boolean critFalling(ClientPlayerEntity p) {
        return !p.isOnGround()
                && p.fallDistance > 0.0
                && p.getVelocity().y < -0.05
                && !p.isClimbing()
                && !p.isTouchingWater()
                && !p.isInLava()
                && !p.hasVehicle()
                && !p.hasStatusEffect(StatusEffects.BLINDNESS)
                && !p.hasStatusEffect(StatusEffects.LEVITATION);
    }

    /** true when there is a block closer than {@code gap} blocks below the player */
    public static boolean nearGround(ClientPlayerEntity p, double gap) {
        MinecraftClient mc = MinecraftClient.getInstance();
        return !mc.world.isSpaceEmpty(p, p.getBoundingBox().stretch(0, -gap, 0));
    }

    public static boolean critReady(ClientPlayerEntity p, double gap) {
        return critFalling(p) && nearGround(p, gap);
    }

    public static Vec3d nearestPoint(Vec3d from, Box b) {
        return new Vec3d(
                MathHelper.clamp(from.x, b.minX, b.maxX),
                MathHelper.clamp(from.y, b.minY, b.maxY),
                MathHelper.clamp(from.z, b.minZ, b.maxZ));
    }

    public static float[] rotations(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        return new float[]{MathHelper.wrapDegrees(yaw), MathHelper.clamp(pitch, -90f, 90f)};
    }
}
