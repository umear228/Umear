package umear.util;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * Collects all lines of a frame in primitive arrays and draws them with ONE draw call.
 * Arrays are reused between frames, so there is no per-frame allocation.
 */
public final class LineBatch {
    private static final int SEGS = 32;
    private static final double[] COS = new double[SEGS + 1];
    private static final double[] SIN = new double[SEGS + 1];

    static {
        for (int i = 0; i <= SEGS; i++) {
            COS[i] = Math.cos(i * Math.PI * 2 / SEGS);
            SIN[i] = Math.sin(i * Math.PI * 2 / SEGS);
        }
    }

    private float[] pos = new float[3 * 2048];
    private int[] col = new int[2048];
    private int n;
    private double cx, cy, cz;

    public void reset(Vec3d cam) {
        n = 0;
        cx = cam.x;
        cy = cam.y;
        cz = cam.z;
    }

    private void ensure(int extra) {
        if (n + extra > col.length) {
            int size = Math.max(col.length * 2, n + extra);
            pos = java.util.Arrays.copyOf(pos, size * 3);
            col = java.util.Arrays.copyOf(col, size);
        }
    }

    private void put(double x, double y, double z, int c) {
        int i = n * 3;
        pos[i] = (float) (x - cx);
        pos[i + 1] = (float) (y - cy);
        pos[i + 2] = (float) (z - cz);
        col[n] = c;
        n++;
    }

    public void line(double x1, double y1, double z1, double x2, double y2, double z2, int c) {
        ensure(2);
        put(x1, y1, z1, c);
        put(x2, y2, z2, c);
    }

    public void box(Box b, int c) {
        box(b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, c);
    }

    public void box(double x0, double y0, double z0, double x1, double y1, double z1, int c) {
        ensure(24);
        // bottom
        put(x0, y0, z0, c); put(x1, y0, z0, c);
        put(x1, y0, z0, c); put(x1, y0, z1, c);
        put(x1, y0, z1, c); put(x0, y0, z1, c);
        put(x0, y0, z1, c); put(x0, y0, z0, c);
        // top
        put(x0, y1, z0, c); put(x1, y1, z0, c);
        put(x1, y1, z0, c); put(x1, y1, z1, c);
        put(x1, y1, z1, c); put(x0, y1, z1, c);
        put(x0, y1, z1, c); put(x0, y1, z0, c);
        // pillars
        put(x0, y0, z0, c); put(x0, y1, z0, c);
        put(x1, y0, z0, c); put(x1, y1, z0, c);
        put(x1, y0, z1, c); put(x1, y1, z1, c);
        put(x0, y0, z1, c); put(x0, y1, z1, c);
    }

    public void ring(double x, double y, double z, double r, int c) {
        ensure(SEGS * 2);
        for (int i = 0; i < SEGS; i++) {
            put(x + COS[i] * r, y, z + SIN[i] * r, c);
            put(x + COS[i + 1] * r, y, z + SIN[i + 1] * r, c);
        }
    }

    public void draw(Matrix4f m, boolean depthTest) {
        if (n == 0) return;
        BufferBuilder bb = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < n; i++) {
            bb.vertex(m, pos[i * 3], pos[i * 3 + 1], pos[i * 3 + 2]).color(col[i]);
        }
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        if (depthTest) RenderSystem.enableDepthTest();
        else RenderSystem.disableDepthTest();
        RenderSystem.lineWidth(2.0f);
        BufferRenderer.drawWithGlobalProgram(bb.end());
        RenderSystem.lineWidth(1.0f);
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }
}
