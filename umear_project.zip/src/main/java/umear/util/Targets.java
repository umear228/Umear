package umear.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

public final class Targets {
    private static LivingEntity current;
    private static long time;

    private Targets() {
    }

    public static void set(Entity e) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (e instanceof LivingEntity le && e != mc.player) {
            current = le;
            time = System.currentTimeMillis();
        }
    }

    public static LivingEntity get() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (current == null || mc.player == null) return null;
        if (!current.isAlive() || current.isRemoved()
                || System.currentTimeMillis() - time > 3000
                || mc.player.distanceTo(current) > 16) {
            current = null;
            return null;
        }
        return current;
    }
}
