package umear;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import umear.gui.ClickGui;
import umear.module.Module;
import umear.module.ModuleManager;
import umear.modules.ClientSettings;
import umear.modules.HitParticles;
import umear.util.RenderData;
import umear.util.Targets;

public class UmearClient implements ClientModInitializer {
    public static KeyBinding menuKey;
    private static final Identifier WATERMARK = Identifier.of("umear", "textures/gui/watermark.png");
    private static final RenderData RD = new RenderData();

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.umear.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.umear"));
        ModuleManager.init();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new ClickGui());
            }
            if (client.player == null || client.world == null) return;
            for (Module m : ModuleManager.all()) {
                if (m.enabled) m.onTick();
            }
        });

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options.hudHidden) return;
            ClientSettings cs = ClientSettings.INSTANCE;
            if (cs != null && cs.watermark.value) {
                int x = mc.getWindow().getScaledWidth() / 2 - 80;
                ctx.drawTexture(RenderLayer::getGuiTextured, WATERMARK, x, 3, 0f, 0f, 160, 28, 160, 28);
            }
            if (mc.player == null || mc.world == null) return;
            for (Module m : ModuleManager.all()) {
                if (m.enabled) m.onHud(ctx);
            }
        });

        WorldRenderEvents.AFTER_TRANSLUCENT.register(ctx -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;
            Vec3d cam = ctx.camera().getPos();
            RD.cam = cam;
            RD.tickDelta = ctx.tickCounter().getTickDelta(true);
            RD.frustum = ctx.frustum();
            RD.over.reset(cam);
            RD.depth.reset(cam);
            for (Module m : ModuleManager.all()) {
                if (m.enabled) m.onWorld(RD);
            }
            var matrix = ctx.matrixStack().peek().getPositionMatrix();
            RD.depth.draw(matrix, true);
            RD.over.draw(matrix, false);
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient) {
                Targets.set(entity);
                if (HitParticles.INSTANCE != null) HitParticles.INSTANCE.spawn(entity);
            }
            return ActionResult.PASS;
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> ModuleManager.save());
    }
}
