package umear.module;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import umear.modules.*;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("umear.json");

    private ModuleManager() {
    }

    public static void init() {
        // Combat
        MODULES.add(new AutoAttack());
        MODULES.add(new KillAura());
        MODULES.add(new Hitbox());
        // Visual
        MODULES.add(new ESP());
        MODULES.add(new XRay());
        MODULES.add(new TargetESP());
        MODULES.add(new TargetHud());
        MODULES.add(new JumpCircles());
        MODULES.add(new HitParticles());
        MODULES.add(new ViewModel());
        // Misc
        MODULES.add(new ToggleSprint());
        // Settings
        MODULES.add(new ClientSettings());
        load();
    }

    public static List<Module> all() {
        return MODULES;
    }

    public static List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) {
            if (m.category == c) out.add(m);
        }
        return out;
    }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : MODULES) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.enabled);
                JsonObject s = new JsonObject();
                for (Setting st : m.settings) s.add(st.name, st.save());
                o.add("settings", s);
                root.add(m.name, o);
            }
            Files.writeString(FILE, new GsonBuilder().setPrettyPrinting().create().toJson(root));
        } catch (Exception ignored) {
        }
    }

    private static void load() {
        try {
            if (!Files.exists(FILE)) return;
            JsonObject root = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
            for (Module m : MODULES) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("settings")) {
                    JsonObject s = o.getAsJsonObject("settings");
                    for (Setting st : m.settings) {
                        if (!s.has(st.name)) continue;
                        try {
                            JsonElement e = s.get(st.name);
                            st.load(e);
                        } catch (Exception ignored) {
                        }
                    }
                }
                if (o.has("enabled") && o.get("enabled").getAsBoolean()) m.setEnabled(true);
            }
        } catch (Exception ignored) {
        }
    }
}
