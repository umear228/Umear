package umear.module;

public enum Category {
    COMBAT("Combat"), VISUAL("Visual"), MISC("Misc"), SETTINGS("Settings");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
