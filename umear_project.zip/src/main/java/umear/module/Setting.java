package umear.module;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public abstract class Setting {
    public final String name;

    protected Setting(String name) {
        this.name = name;
    }

    public abstract JsonElement save();

    public abstract void load(JsonElement e);

    public static class Bool extends Setting {
        public boolean value;

        public Bool(String name, boolean def) {
            super(name);
            this.value = def;
        }

        @Override
        public JsonElement save() {
            return new JsonPrimitive(value);
        }

        @Override
        public void load(JsonElement e) {
            value = e.getAsBoolean();
        }
    }

    public static class Num extends Setting {
        public double value;
        public final double min, max, step;

        public Num(String name, double def, double min, double max, double step) {
            super(name);
            this.value = def;
            this.min = min;
            this.max = max;
            this.step = step;
        }

        public float f() {
            return (float) value;
        }

        public int i() {
            return (int) Math.round(value);
        }

        public void set(double v) {
            v = Math.round(v / step) * step;
            value = Math.max(min, Math.min(max, v));
        }

        @Override
        public JsonElement save() {
            return new JsonPrimitive(value);
        }

        @Override
        public void load(JsonElement e) {
            set(e.getAsDouble());
        }
    }

    public static class Mode extends Setting {
        public String value;
        public final String[] modes;

        public Mode(String name, String def, String... modes) {
            super(name);
            this.value = def;
            this.modes = modes;
        }

        public void cycle(int dir) {
            int idx = 0;
            for (int i = 0; i < modes.length; i++) {
                if (modes[i].equals(value)) idx = i;
            }
            idx = (idx + dir + modes.length) % modes.length;
            value = modes[idx];
        }

        public boolean is(String m) {
            return value.equals(m);
        }

        @Override
        public JsonElement save() {
            return new JsonPrimitive(value);
        }

        @Override
        public void load(JsonElement e) {
            String s = e.getAsString();
            for (String m : modes) {
                if (m.equals(s)) {
                    value = s;
                    return;
                }
            }
        }
    }
}
