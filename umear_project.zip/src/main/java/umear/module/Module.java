package umear.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import umear.util.RenderData;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    public final String name;
    public final Category category;
    public boolean enabled;
    public boolean alwaysOn;
    public final List<Setting> settings = new ArrayList<>();

    protected Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    protected <T extends Setting> T add(T s) {
        settings.add(s);
        return s;
    }

    public void setEnabled(boolean e) {
        if (alwaysOn || enabled == e) return;
        enabled = e;
        if (e) onEnable();
        else onDisable();
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public void onTick() {
    }

    public void onHud(DrawContext ctx) {
    }

    public void onWorld(RenderData rd) {
    }
}
