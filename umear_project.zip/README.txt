umear client 1.0.0 (Fabric, Minecraft 1.21.4)

BUILD ON GITHUB (from phone):
1) Put umear_project.zip in the repo root (repo "Umear").
2) Create file .github/workflows/build.yml with the content of build.yml.
3) Open Actions -> build -> Artifacts -> umear-jar. Put the jar in .minecraft/mods
   together with Fabric API 0.119.2+1.21.4.
Menu key: Right Shift (change it in the Settings tab of the menu or in Controls).
